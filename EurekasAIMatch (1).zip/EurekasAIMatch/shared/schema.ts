import { pgTable, text, serial, integer, jsonb, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define all tables first to avoid circular references
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  bio: text("bio").notNull(),
  location: text("location").notNull(),
  image: text("image").notNull(),
  type: text("type"),
  genderIdentityValue: integer("gender_identity_value").notNull().default(5),
  gender_identity: text("gender_identity").notNull(),  // Added this line to ensure non-null
  spiritualColor: text("spiritual_color"),
  metaphysicalScores: jsonb("metaphysical_scores"),
  // Add new fields for political and kink ratings
  politicalScores: jsonb("political_scores"),
  kinkScores: jsonb("kink_scores"),
  quizResults: jsonb("quiz_results"),
  quizTimestamp: timestamp("quiz_timestamp"),
  // Add subscription related fields
  subscriptionStatus: text("subscription_status").default("free").notNull(),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  stripeCustomerId: text("stripe_customer_id"),
  // Keep existing contact fields
  email: text("email"),
  phoneNumber: text("phone_number"),
  physicalAddress: text("physical_address"),
});

// New payments table for subscription tracking
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("usd").notNull(),
  status: text("status").notNull(), // succeeded, failed, pending
  stripePaymentId: text("stripe_payment_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  // Add new fields
  attemptStatus: text("attempt_status").notNull(), // initiated, processing, completed, failed
  failureMessage: text("failure_message"),
  paymentMethodType: text("payment_method_type"),
  stripeMetadata: jsonb("stripe_metadata"),
});

// Add after the payments table definition and before the premiumPreferences table
export const failedPaymentsStripeReporting = pgTable("failed_payments_stripe_reporting", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  stripePaymentId: text("stripe_payment_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  failureMessage: text("failure_message").notNull(),
  failureCode: text("failure_code"),
  failureType: text("failure_type"),
  paymentMethodDetails: jsonb("payment_method_details"),
  rawStripeError: jsonb("raw_stripe_error"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// New premium preferences table
export const premiumPreferences = pgTable("premium_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Premium questionnaire responses
  relationshipGoals: text("relationship_goals").notNull(),
  communicationStyle: text("communication_style").notNull(),
  emotionalIntelligence: integer("emotional_intelligence").notNull(),
  spiritualPractices: jsonb("spiritual_practices").notNull(),
  lifestyleCompatibility: jsonb("lifestyle_compatibility").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Keep existing tables
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Lifestyle preferences
  petPreference: text("pet_preference").notNull(),
  smokingPreference: text("smoking_preference").notNull(),
  cohabitationPreference: text("cohabitation_preference").notNull(),
  longDistancePreference: text("long_distance_preference").notNull(),
  physicalPreferences: jsonb("physical_preferences"),
  intimacyPreferences: jsonb("intimacy_preferences"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const userSelections = pgTable("user_selections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  targetUserId: integer("target_user_id").notNull(),
  liked: boolean("liked").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Add date nights table
export const dateNights = pgTable("date_nights", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull(),
  guestId: integer("guest_id").notNull(),
  scheduledFor: timestamp("scheduled_for").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, declined, completed
  notes: text("notes"),
  // Add new fields for calendar sync
  calendarEventId: text("calendar_event_id"),
  calendarProvider: text("calendar_provider"), // google, apple
  calendarSyncStatus: text("calendar_sync_status").default("not_synced"), // not_synced, synced, failed
  // Add new fields for ratings and feedback
  hostRating: integer("host_rating"),
  guestRating: integer("guest_rating"),
  hostFeedback: text("host_feedback"),
  guestFeedback: text("guest_feedback"),
  ratingSubmittedAt: timestamp("rating_submitted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Add notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // match, message, datenight, system
  title: text("title").notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false).notNull(),
  actionUrl: text("action_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  readAt: timestamp("read_at"),
  expiresAt: timestamp("expires_at"),
});

// New disputes table for tracking payment disputes
export const disputes = pgTable("disputes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  stripeDisputeId: text("stripe_dispute_id").notNull().unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("usd").notNull(),
  status: text("status").notNull(), // needs_response, under_review, won, lost
  reason: text("reason").notNull(),
  evidence: jsonb("evidence"),
  chargeId: text("charge_id").notNull(),
  created: timestamp("created_at").notNull(),
  updated: timestamp("updated_at").notNull(),
});

// Add after the notifications table definition, before the schemas section
export const quizProgress = pgTable("quiz_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currentQuestionId: integer("current_question_id").notNull(),
  answers: jsonb("answers").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  isCompleted: boolean("is_completed").default(false).notNull(),
});

// Define schemas after table definitions
export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    name: true,
    age: true,
    bio: true,
    location: true,
    image: true,
    genderIdentityValue: true,
    gender_identity: true, //added this line
  })
  .extend({
    password: z.string().min(6, "Password must be at least 6 characters"),
    username: z.string().min(3, "Username must be at least 3 characters"),
    bio: z.string().default(""),
    image: z.string().default("/default-avatar.png"),
    genderIdentityValue: z.number().min(0).max(10).default(5),
    gender_identity: z.string().min(1, "Gender identity is required"), //added this line
    // Add new fields validation
    politicalScores: z.object({
      ideologicalSpectrum: z.number().min(0).max(100).optional(),
      activismEngagement: z.number().min(1).max(10).optional(),
      tacticsPreference: z.number().min(0).max(100).optional(),
      publicVisibility: z.number().min(0).max(100).optional(),
      riskOfExtremism: z.number().min(0).max(100).optional(),
      echoChamberIndex: z.number().min(0).max(100).optional(),
      financialCommitment: z.number().min(0).max(100).optional(),
      mobilizationAbility: z.number().min(0).max(100).optional(),
    }).optional().nullable(),
    kinkScores: z.object({
      riskTolerance: z.number().min(0).max(100).optional(),
      explorationIndex: z.number().min(1).max(10).optional(),
      powerPlayPreference: z.number().min(0).max(100).optional(),
      publicPrivate: z.number().min(0).max(100).optional(),
      edgePlayScale: z.number().min(0).max(100).optional(),
      vanillaToExtreme: z.number().min(1).max(10).optional(),
      consentAwareness: z.number().min(0).max(100).optional(),
      sensoryThreshold: z.number().min(0).max(100).optional(),
    }).optional().nullable(),
    email: z.string().email("Invalid email address").optional(),
    phoneNumber: z.string().optional(),
    physicalAddress: z.string().optional(),
    type: z.string().optional().default(""),
    spiritualColor: z.string().nullable().optional(),
    metaphysicalScores: z.record(z.string(), z.number()).nullable().optional(),
    quizResults: z.record(z.string(), z.unknown()).nullable().optional(),
    quizTimestamp: z.date().nullable().optional(),
    subscriptionStatus: z.string().default("free"),
    subscriptionExpiresAt: z.date().nullable().optional(),
    stripeCustomerId: z.string().nullable().optional(),
  });

// New schema for payments
export const insertPaymentSchema = createInsertSchema(payments)
  .pick({
    userId: true,
    amount: true,
    currency: true,
    status: true,
    stripePaymentId: true,
    attemptStatus: true,
    failureMessage: true,
    paymentMethodType: true,
    stripeMetadata: true
  })
  .extend({
    status: z.enum(["succeeded", "failed", "pending"]),
    attemptStatus: z.enum(["initiated", "processing", "completed", "failed"]),
    failureMessage: z.string().optional(),
    paymentMethodType: z.string().optional(),
    stripeMetadata: z.record(z.string(), z.unknown()).optional()
  });

// New schema for premium preferences
export const insertPremiumPreferencesSchema = createInsertSchema(premiumPreferences)
  .pick({
    userId: true,
    relationshipGoals: true,
    communicationStyle: true,
    emotionalIntelligence: true,
    spiritualPractices: true,
    lifestyleCompatibility: true,
  })
  .extend({
    relationshipGoals: z.enum([
      "Long-term Partnership",
      "Spiritual Connection",
      "Personal Growth",
      "Community Building",
    ]),
    communicationStyle: z.enum([
      "Direct",
      "Empathetic",
      "Analytical",
      "Expressive",
    ]),
    emotionalIntelligence: z.number().min(1).max(10),
    spiritualPractices: z.record(z.string(), z.boolean()),
    lifestyleCompatibility: z.record(z.string(), z.unknown()),
  });

// Keep existing schemas
export const insertUserPreferencesSchema = createInsertSchema(userPreferences)
  .pick({
    userId: true,
    petPreference: true,
    smokingPreference: true,
    cohabitationPreference: true,
    longDistancePreference: true,
    physicalPreferences: true,
    intimacyPreferences: true,
  })
  .extend({
    petPreference: z.enum(["Loves Pets", "Has Pets", "No Pets", "Allergic"]),
    smokingPreference: z.enum(["Non-smoker", "Social Smoker", "Regular Smoker", "No Preference"]),
    cohabitationPreference: z.enum(["Wants to Live Together", "Prefers Living Apart", "Open to Both"]),
    longDistancePreference: z.enum(["Open to Long Distance", "Local Only", "Willing to Relocate"]),
    physicalPreferences: z.record(z.string(), z.unknown()),
    intimacyPreferences: z.record(z.string(), z.unknown()),
  });

export const insertUserSelectionSchema = createInsertSchema(userSelections).pick({
  userId: true,
  targetUserId: true,
  liked: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  senderId: true,
  receiverId: true,
  content: true,
});

// Update the date night schema
export const insertDateNightSchema = createInsertSchema(dateNights)
  .pick({
    hostId: true,
    guestId: true,
    scheduledFor: true,
    notes: true,
    calendarEventId: true,
    calendarProvider: true,
    hostRating: true,
    guestRating: true,
    hostFeedback: true,
    guestFeedback: true,
    ratingSubmittedAt: true,
  })
  .extend({
    notes: z.string().optional(),
    calendarEventId: z.string().optional(),
    calendarProvider: z.enum(["google", "apple"]).optional(),
    hostRating: z.number().int().min(1).max(5).optional(),
    guestRating: z.number().int().min(1).max(5).optional(),
    hostFeedback: z.string().optional(),
    guestFeedback: z.string().optional(),
    ratingSubmittedAt: z.date().optional(),
  });

// Add new schema for date night ratings
export const dateNightRatingSchema = z.object({
  dateNightId: z.number(),
  rating: z.number().min(1).max(5),
  feedback: z.string().optional(),
  raterType: z.enum(["host", "guest"]),
});

// Add notification schema
export const insertNotificationSchema = createInsertSchema(notifications)
  .pick({
    userId: true,
    type: true,
    title: true,
    content: true,
    actionUrl: true,
    expiresAt: true,
  })
  .extend({
    type: z.enum(["match", "message", "datenight", "system"]),
    title: z.string().min(1, "Title is required"),
    content: z.string().min(1, "Content is required"),
    actionUrl: z.string().optional(),
    expiresAt: z.date().optional(),
  });

// Add after other insert schemas
export const insertFailedPaymentReportSchema = createInsertSchema(failedPaymentsStripeReporting)
  .pick({
    userId: true,
    stripePaymentId: true,
    amount: true,
    failureMessage: true,
    failureCode: true,
    failureType: true,
    paymentMethodDetails: true,
    rawStripeError: true,
  });

// Add after other insert schemas
export const insertDisputeSchema = createInsertSchema(disputes)
  .pick({
    userId: true,
    stripeDisputeId: true,
    amount: true,
    currency: true,
    status: true,
    reason: true,
    evidence: true,
    chargeId: true,
  })
  .extend({
    status: z.enum(['needs_response', 'under_review', 'won', 'lost']),
    evidence: z.record(z.string(), z.unknown()).optional(),
  });

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPremiumPreferences = z.infer<typeof insertPremiumPreferencesSchema>;
export type PremiumPreferences = typeof premiumPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserSelection = z.infer<typeof insertUserSelectionSchema>;
export type UserSelection = typeof userSelections.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
// Export types for date nights
export type InsertDateNight = z.infer<typeof insertDateNightSchema>;
export type DateNight = typeof dateNights.$inferSelect;
// Add new types for date night ratings
export type DateNightRating = z.infer<typeof dateNightRatingSchema>;
// Export notification types
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
// Add new types for quiz progress
export type InsertQuizProgress = typeof quizProgress.$inferInsert;
export type QuizProgress = typeof quizProgress.$inferSelect;
// Add to exports section
export type InsertFailedPaymentReport = z.infer<typeof insertFailedPaymentReportSchema>;
export type FailedPaymentReport = typeof failedPaymentsStripeReporting.$inferSelect;
export type InsertDispute = z.infer<typeof insertDisputeSchema>;
export type Dispute = typeof disputes.$inferSelect;