import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

interface SubscriptionStatus {
  isSubscribed: boolean;
  tier: 'free' | 'premium';
  expiresAt?: string;
}

export function useSubscriptionStatus() {
  const { data: subscriptionData } = useQuery<SubscriptionStatus>({
    queryKey: ["/api/subscription/status"],
    queryFn: getQueryFn<SubscriptionStatus>({ on401: "returnNull" }),
  });

  return {
    isSubscribed: subscriptionData?.isSubscribed ?? false,
    tier: subscriptionData?.tier ?? 'free',
    expiresAt: subscriptionData?.expiresAt,
  };
}