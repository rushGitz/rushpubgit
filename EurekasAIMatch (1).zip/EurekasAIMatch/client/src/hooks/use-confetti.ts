import confetti from 'canvas-confetti';
import { useCallback } from 'react';

export function useConfetti() {
  const fireConfetti = useCallback(() => {
    // First burst
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF1493', '#FF69B4', '#FFB6C1', '#FFC0CB'],
    });

    // Second burst with slight delay
    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#FF1493', '#FF69B4', '#FFB6C1', '#FFC0CB'],
      });
    }, 200);

    // Third burst with slight delay
    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#FF1493', '#FF69B4', '#FFB6C1', '#FFC0CB'],
      });
    }, 400);
  }, []);

  return fireConfetti;
}
