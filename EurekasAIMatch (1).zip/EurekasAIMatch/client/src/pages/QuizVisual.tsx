import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Slider } from "@/components/ui/slider";
import { ChevronLeft, ChevronRight, Save } from "lucide-react";
import axios from "axios";

const quizQuestions = [
  {
    id: 1,
    question: "How do you prefer to recharge?",
    options: [
      { text: "Quiet meditation and solitude", type: "Mystic Healer" },
      { text: "Connecting with nature", type: "Spiritual Guide" },
      { text: "Engaging in creative activities", type: "Empathic Nurturer" },
      { text: "Sharing experiences with others", type: "Mindful Explorer" }
    ]
  },
  {
    id: 2,
    question: "How do you view coincidences?",
    options: [
      { text: "Strongly believe in destiny", type: "Mystic Healer" },
      { text: "Notice meaningful coincidences", type: "Spiritual Guide" },
      { text: "Sometimes see patterns", type: "Empathic Nurturer" },
      { text: "Prefer logical explanations", type: "Mindful Explorer" }
    ]
  },
  {
    id: 3,
    question: "How do you make decisions?",
    options: [
      { text: "Always trust my gut feelings", type: "Mystic Healer" },
      { text: "Balance intuition with logic", type: "Spiritual Guide" },
      { text: "Consider others' feelings", type: "Empathic Nurturer" },
      { text: "Prefer factual decision-making", type: "Mindful Explorer" }
    ]
  },
  {
    id: 4,
    question: "When faced with a disagreement, how do you typically respond?",
    options: [
      { text: "Use spiritual guidance to find harmony", type: "Mystic Healer" },
      { text: "Listen deeply and guide towards understanding", type: "Spiritual Guide" },
      { text: "Focus on emotional healing and empathy", type: "Empathic Nurturer" },
      { text: "Analyze the situation objectively", type: "Mindful Explorer" }
    ]
  },
  {
    id: 5,
    type: "risk_tolerance",
    question: "How comfortable are you with taking emotional risks in relationships?",
    ratingLabels: {
      1: "Very cautious",
      5: "Balanced approach",
      10: "Highly comfortable"
    },
    isRating: true
  },
  {
    id: 6,
    type: "public_private",
    question: "How do you feel about sharing your spiritual/emotional journey with others?",
    ratingLabels: {
      1: "Strictly private",
      5: "Selective sharing",
      10: "Very open"
    },
    isRating: true
  },
  {
    id: 7,
    type: "activism",
    question: "How actively do you engage in causes you believe in?",
    ratingLabels: {
      1: "Observer only",
      5: "Moderate involvement",
      10: "Full engagement"
    },
    isRating: true
  },
  {
    id: 8,
    question: "In group settings, what role do you naturally take?",
    options: [
      { text: "Guide and inspire others spiritually", type: "Mystic Healer" },
      { text: "Organize and mobilize for action", type: "Spiritual Guide" },
      { text: "Support and nurture group harmony", type: "Empathic Nurturer" },
      { text: "Analyze and strategize", type: "Mindful Explorer" }
    ]
  },
  {
    id: 9,
    type: "metaphysical",
    question: "What role does spirituality or a connection to a higher power play in your life?",
    ratingLabels: {
      1: "Not important",
      5: "Central to life",
      10: "Deeply spiritual"
    },
    isRating: true
  },
  {
    id: 10,
    type: "metaphysical",
    question: "Do you believe in concepts like destiny, synchronicity, or that everything happens for a reason?",
    ratingLabels: {
      1: "Skeptical",
      5: "Open-minded",
      10: "Strong believer"
    },
    isRating: true
  },
  {
    id: 11,
    type: "boundaries",
    question: "How do you approach setting personal boundaries in relationships?",
    ratingLabels: {
      1: "Very flexible",
      5: "Balanced",
      10: "Strictly defined"
    },
    isRating: true
  },
  {
    id: 12,
    question: "How do you typically process and express emotions?",
    options: [
      { text: "Through spiritual practices and meditation", type: "Mystic Healer" },
      { text: "By seeking deeper meaning and guidance", type: "Spiritual Guide" },
      { text: "Through emotional expression and sharing", type: "Empathic Nurturer" },
      { text: "Through reflection and analysis", type: "Mindful Explorer" }
    ]
  },
  {
    id: 13,
    type: "exploration",
    question: "How open are you to exploring new spiritual or personal growth experiences?",
    ratingLabels: {
      1: "Prefer familiar",
      5: "Selective exploration",
      10: "Highly adventurous"
    },
    isRating: true
  }
];

export default function QuizVisual() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{[key: number]: number | string}>({});
  const [results, setResults] = useState<{type: string, score: number}[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user?.id) {
      loadSavedProgress();
    }
  }, [user?.id]);

  const loadSavedProgress = async () => {
    try {
      const response = await axios.get('/api/quiz-progress');
      if (response.data) {
        setAnswers(response.data.answers);
        setCurrentQuestion(response.data.currentQuestionId);
        if (response.data.isCompleted) {
          setShowResults(true);
          setResults(response.data.quizResults || []);
        }
      }
    } catch (error) {
      console.error('Error loading quiz progress:', error);
    }
  };

  const saveProgress = async () => {
    if (!user?.id || isSaving) return;

    try {
      setIsSaving(true);
      await axios.post('/api/quiz-progress', {
        userId: user.id,
        currentQuestionId: currentQuestion,
        answers,
        isCompleted: showResults
      });

      toast({
        title: "Progress Saved",
        description: "Your quiz progress has been saved successfully.",
      });
    } catch (error) {
      console.error('Error saving progress:', error);
      toast({
        title: "Error Saving Progress",
        description: "Failed to save your progress. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleRatingChange = (value: number) => {
    setAnswers(prev => ({ ...prev, [currentQuestion]: value }));
  };

  const handleAnswer = async (type?: string) => {
    if (isSubmitting) return;

    let newAnswers = answers;

    if (type) {
      newAnswers = { ...answers, [currentQuestion]: type };
      setAnswers(newAnswers);
    }

    if (currentQuestion === quizQuestions.length - 1) {
      try {
        setIsSubmitting(true);
        toast({
          title: "Saving Results",
          description: "Please wait while we save your quiz results...",
        });

        const unansweredQuestions = quizQuestions.filter((_, index) => !newAnswers[index]);
        if (unansweredQuestions.length > 0) {
          throw new Error('Please answer all questions before submitting');
        }

        const personalityAnswers = Object.entries(newAnswers).reduce((acc: Record<string, string>, [qId, answer]) => {
          const question = quizQuestions[parseInt(qId)];
          if (!question.isRating && typeof answer === 'string') {
            acc[qId] = answer;
          }
          return acc;
        }, {});

        const typeCounts = Object.values(personalityAnswers).reduce((acc: Record<string, number>, type) => {
          acc[type] = (acc[type] || 0) + 1;
          return acc;
        }, {});

        const personalityQuestions = quizQuestions.filter(q => !q.isRating);
        const totalTypeQuestions = personalityQuestions.length;

        const calculatedResults = [
          { type: "Mystic Healer", score: (typeCounts["Mystic Healer"] || 0) * (100 / totalTypeQuestions) },
          { type: "Spiritual Guide", score: (typeCounts["Spiritual Guide"] || 0) * (100 / totalTypeQuestions) },
          { type: "Empathic Nurturer", score: (typeCounts["Empathic Nurturer"] || 0) * (100 / totalTypeQuestions) },
          { type: "Mindful Explorer", score: (typeCounts["Mindful Explorer"] || 0) * (100 / totalTypeQuestions) }
        ];

        setResults(calculatedResults);

        const dominantType = calculatedResults.reduce((max, current) => 
          current.score > max.score ? current : max
        ).type;

        const metaphysicalScores = Object.entries(newAnswers).reduce((acc: Record<string, number>, [qId, value]) => {
          const question = quizQuestions[parseInt(qId)];
          if (question?.type === 'metaphysical' || question?.type === 'risk_tolerance' || question?.type === 'public_private' || question?.type === 'activism' || question?.type === 'boundaries' || question?.type === 'exploration' && typeof value === 'number') {
            acc[`question_${qId}`] = value;
          }
          return acc;
        }, {});

        if (!dominantType || !metaphysicalScores || Object.keys(metaphysicalScores).length === 0) {
          throw new Error('Missing required quiz data');
        }

        let retries = 3;
        let success = false;
        let lastError;
        let delay = 1000; 

        while (retries > 0 && !success) {
          try {
            const response = await axios.patch("/api/user/quiz", {
              type: dominantType,
              metaphysicalScores,
              quizResults: typeCounts
            }, {
              headers: {
                'Content-Type': 'application/json'
              },
              timeout: 15000, 
              withCredentials: true 
            });

            if (response.status === 200) {
              success = true;
              setShowResults(true);
              toast({
                title: "Quiz Complete!",
                description: "Your spiritual profile has been saved.",
              });
            }
          } catch (error: any) {
            lastError = error;
            retries--;
            if (retries > 0) {
              await new Promise(resolve => setTimeout(resolve, delay));
              delay *= 2; 
            }
          }
        }

        if (!success) {
          throw lastError || new Error('Failed to save quiz results after multiple attempts');
        }

      } catch (error: any) {
        console.error("Failed to save quiz results:", error);
        toast({
          title: "Error Saving Results",
          description: error.message || "Failed to save your quiz results. Please try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      } finally {
        setIsSubmitting(false);
      }
    } else {
      if (user?.id) {
        try {
          await axios.post('/api/quiz-progress', {
            userId: user.id,
            currentQuestionId: currentQuestion,
            answers,
            isCompleted: showResults
          });
        } catch (error) {
          console.error('Error auto-saving progress:', error);
        }
      }
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleNext = () => {
    if (isSubmitting) return;

    const currentAnswer = answers[currentQuestion];
    if (currentAnswer === undefined) {
      toast({
        title: "Please answer the question",
        description: "Select an option or provide a rating before continuing.",
        variant: "destructive",
      });
      return;
    }

    if (quizQuestions[currentQuestion].isRating) {
      handleAnswer();
    } else {
      handleAnswer(currentAnswer as string);
    }
  };

  const restartQuiz = () => {
    if (isSubmitting) return;
    setCurrentQuestion(0);
    setAnswers({});
    setResults([]);
    setShowResults(false);
  };

  const currentQuestionData = quizQuestions[currentQuestion];

  const formatResultsForRadar = (metaphysicalScores: Record<string, number>) => {
    // Map quiz questions to the four main metrics
    const metricMap = {
      question_5: "Kink Rating",
      question_7: "Political Activism",
      question_9: "Spiritual Practice",
      question_11: "Emotional Intelligence"
    };

    return Object.entries(metaphysicalScores)
      .filter(([key]) => metricMap[key as keyof typeof metricMap])
      .map(([key, value]) => ({
        aspect: metricMap[key as keyof typeof metricMap],
        score: value,
        fullMark: 10
      }));
  };

  const getTypeDescription = (type: string) => {
    const descriptions: Record<string, string> = {
      "Mystic Healer": "You have a deep connection to spiritual healing and intuitive guidance. Your strength lies in helping others find inner peace and harmony.",
      "Spiritual Guide": "You excel at bridging spiritual wisdom with practical guidance. Your path involves leading others toward enlightenment.",
      "Empathic Nurturer": "Your natural ability to understand and support others emotionally makes you a compassionate force for positive change.",
      "Mindful Explorer": "You approach spirituality with curiosity and analytical depth, finding meaning through conscious exploration and understanding."
    };
    return descriptions[type] || "Your unique spiritual journey combines various elements of growth and understanding.";
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-background via-background/95 to-primary/10 p-4 relative overflow-hidden">
      <h1 className="text-4xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70 relative z-10">
        Discover Your Spiritual Match
      </h1>

      <AnimatePresence mode="wait">
        {!showResults ? (
          <motion.div
            key="quiz"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-2xl relative z-10"
          >
            <Card className="backdrop-blur-xl bg-background/80 border-primary/20 shadow-xl">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleBack}
                    disabled={currentQuestion === 0 || isSubmitting}
                    className="hover:bg-primary/10"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={saveProgress}
                    disabled={isSaving || isSubmitting}
                    className="hover:bg-primary/10"
                  >
                    <Save className={`h-4 w-4 ${isSaving ? 'animate-spin' : ''}`} />
                  </Button>
                </div>

                <motion.div
                  key={currentQuestion}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-semibold mb-6 text-white">
                    {currentQuestionData.question}
                  </h2>

                  {currentQuestionData.isRating ? (
                    <div className="space-y-8">
                      <Slider
                        defaultValue={[answers[currentQuestion] as number || 5]}
                        max={10}
                        min={1}
                        step={1}
                        onValueChange={(value) => handleRatingChange(value[0])}
                        className="touch-none"
                      />
                      <div className="flex justify-between text-sm text-white/60">
                        <span>{currentQuestionData.ratingLabels[1]}</span>
                        <span>{currentQuestionData.ratingLabels[5]}</span>
                        <span>{currentQuestionData.ratingLabels[10]}</span>
                      </div>
                      <Button
                        className="mt-6 w-full bg-primary hover:bg-primary/80"
                        onClick={handleNext}
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          "Processing..."
                        ) : (
                          currentQuestion < quizQuestions.length - 1 ? "Next" : "Complete"
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {currentQuestionData.options?.map((option, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <Button
                            variant="outline"
                            className="w-full text-left p-4 hover:bg-primary/10 border-primary/20 touch-manipulation"
                            onClick={() => handleAnswer(option.type)}
                            disabled={isSubmitting}
                          >
                            {option.text}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  <div className="mt-4 flex gap-1">
                    {Array.from({ length: quizQuestions.length }).map((_, i) => (
                      <motion.div
                        key={i}
                        className={`h-1 w-8 rounded-full ${
                          i === currentQuestion ? 'bg-primary animate-pulse' :
                          i < currentQuestion ? 'bg-primary/60' :
                          'bg-primary/20'
                        }`}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                      />
                    ))}
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="w-full max-w-4xl relative z-10"
          >
            <Card className="backdrop-blur-xl bg-background/80 border-primary/20 shadow-xl">
              <CardContent className="p-6">
                <h2 className="text-2xl font-semibold mb-6 text-white text-center">
                  Your Spiritual Profile
                </h2>

                <div className="mb-8 text-center">
                  <h3 className="text-xl font-semibold mb-2 text-primary">
                    {results[0]?.type || "Analyzing..."}
                  </h3>
                  <p className="text-white/80">
                    {getTypeDescription(results[0]?.type || "")}
                  </p>
                </div>

                <div className="w-full flex flex-col items-center justify-center mb-8">
                  <RadarChart
                    width={500}
                    height={400}
                    data={formatResultsForRadar(
                      Object.entries(answers)
                        .filter(([key]) => key.startsWith('question_'))
                        .reduce((acc, [key, value]) => ({
                          ...acc,
                          [key]: value
                        }), {})
                    )}
                    className="mx-auto"
                  >
                    <PolarGrid gridType="polygon" stroke="rgba(255, 255, 255, 0.2)" />
                    <PolarAngleAxis
                      dataKey="aspect"
                      tick={{ fill: "white", fontSize: 14, fontWeight: 500 }}
                    />
                    <PolarRadiusAxis
                      angle={30}
                      domain={[0, 10]}
                      tick={{ fill: "white" }}
                      stroke="rgba(255, 255, 255, 0.2)"
                    />
                    <Radar
                      name="Your Profile"
                      dataKey="score"
                      stroke="#FF69B4"
                      fill="#FF69B4"
                      fillOpacity={0.4}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        border: "1px solid #FF69B4",
                        borderRadius: "8px",
                        color: "white"
                      }}
                    />
                  </RadarChart>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {Object.entries(answers)
                    .filter(([key]) => key.startsWith("question_"))
                    .map(([key, value]) => {
                      const radarData = formatResultsForRadar({[key]: value as number});
                      const aspect = radarData[0]?.aspect;
                      if (!aspect) return null;

                      return (
                        <div key={key} className="p-3 rounded-lg bg-pink-500/10 border border-pink-500/20">
                          <h4 className="font-medium text-white">
                            {aspect}
                          </h4>
                          <p className="text-sm text-pink-200">
                            Score: {value}/10
                          </p>
                        </div>
                      );
                    })}
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Button 
                    className="mt-6 w-full bg-primary hover:bg-primary/80 transition-all duration-300"
                    onClick={restartQuiz}
                    disabled={isSubmitting}
                  >
                    Take Quiz Again
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}