import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { type User } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { SparkVisualization } from "@/components/SparkVisualization";
import { withPremium } from "@/lib/with-premium";

// Enhanced personality insights with deeper spiritual meanings
const PERSONALITY_INSIGHTS = {
  "Mystic Healer": {
    description: "As a Mystic Healer, you possess an innate ability to sense and heal emotional wounds. Your empathic nature allows you to create deep, meaningful connections.  You are deeply intuitive and connected to the spiritual realm, often using this connection to guide and support others. Your compassion is boundless, and you find fulfillment in helping others find healing and peace.",
    strengths: ["Emotional Intelligence", "Intuitive Understanding", "Nurturing Spirit", "Spiritual Sensitivity", "Empathy"],
    compatibility: {
      "Mindful Explorer": {
        overview: "Your healing nature complements their adventurous spirit, creating a balanced partnership.  Their grounded nature helps you stay centered, while your intuition inspires their explorations.",
        compatibility: 0.85,
        pros: [
          "Your intuitive healing balances their analytical approach",
          "They bring intellectual stimulation to your spiritual practice",
          "Together you create a perfect blend of emotion and logic",
          "Mutual respect for each other's strengths"
        ],
        cons: [
          "May need to bridge communication style differences",
          "Different approaches to problem-solving could create tension",
          "Finding balance between intuition and analysis takes work",
          "Potential for miscommunication due to different communication styles"
        ]
      },
      "Spiritual Guide": {
        overview: "A deeply spiritual connection that enhances both partners' intuitive abilities.  You share a common understanding of the spiritual world, fostering a strong bond.",
        compatibility: 0.9,
        pros: [
          "Profound spiritual understanding between partners",
          "Complementary healing and guidance abilities",
          "Strong foundation in spiritual practices",
          "Shared spiritual journey and growth"
        ],
        cons: [
          "Both may need to maintain healthy boundaries",
          "Risk of becoming too focused on others' needs",
          "May need to ground spiritual experiences in reality",
          "Potential for disagreements on spiritual practices"
        ]
      },
      "Empathic Nurturer": {
        overview: "A powerfully emotional bond that can lead to profound personal growth.  You share a deep understanding of emotions and can offer each other profound support.",
        compatibility: 0.95,
        pros: [
          "Deep emotional understanding and support",
          "Natural ability to heal and nurture each other",
          "Strong intuitive connection",
          "Shared emotional depth and understanding"
        ],
        cons: [
          "Risk of emotional overwhelm",
          "May need to establish clear boundaries",
          "Could become too internally focused",
          "Potential for emotional dependency"
        ]
      }
    }
  },
  "Mindful Explorer": {
    description: "As a Mindful Explorer, you approach relationships with curiosity and openness. Your analytical mind and spiritual curiosity create unique connections. You value intellectual stimulation and seek growth through new experiences and perspectives.  You approach spirituality with an inquiring mind, seeking understanding and knowledge.",
    strengths: ["Analytical Thinking", "Spiritual Curiosity", "Balanced Perspective", "Open-mindedness", "Adaptability"],
    compatibility: {
      "Mystic Healer": {
        overview: "Their grounding presence balances your explorative nature. Their emotional depth complements your analytical approach, creating a harmonious partnership.",
        compatibility: 0.85,
        pros: [
          "They provide emotional depth to your analytical approach",
          "Your curiosity enhances their healing abilities",
          "Balance of logic and intuition",
          "Mutual respect for each other's perspectives"
        ],
        cons: [
          "May need to bridge emotional communication gaps",
          "Different decision-making styles",
          "Finding common ground in spiritual practices",
          "Potential for conflict due to different approaches to problem-solving"
        ]
      },
      "Spiritual Guide": {
        overview: "A dynamic duo for spiritual and intellectual exploration.  You share a love of learning and growing spiritually, creating a stimulating partnership.",
        compatibility: 0.88,
        pros: [
          "Shared love of spiritual discovery",
          "Complementary approaches to growth",
          "Strong intellectual connection",
          "Mutual support in spiritual exploration"
        ],
        cons: [
          "May clash on methodology",
          "Different speeds of processing experiences",
          "Need to balance analysis with intuition",
          "Potential for disagreements on spiritual approaches"
        ]
      },
      "Empathic Nurturer": {
        overview: "They provide emotional anchor for your adventures. Their nurturing nature complements your exploratory spirit, creating a balanced and supportive relationship.",
        compatibility: 0.82,
        pros: [
          "Balance of emotion and intellect",
          "Their grounding complements your exploration",
          "Deep understanding through different lenses",
          "Mutual understanding and emotional support"
        ],
        cons: [
          "May need to bridge communication styles",
          "Different approaches to emotional processing",
          "Balancing stability with exploration",
          "Potential for conflict due to different priorities"
        ]
      }
    }
  },
  "Empathic Nurturer": {
    description: "As an Empathic Nurturer, you possess a natural gift for understanding and supporting others' emotional needs. Your deep emotional intelligence and caring nature create profound connections. You have an innate ability to sense others' feelings and provide comfort, making you a natural healer and supporter in relationships.",
    strengths: ["Deep Empathy", "Emotional Support", "Intuitive Understanding", "Compassionate Nature", "Relationship Nurturing"],
    compatibility: {
      "Mystic Healer": {
        overview: "A deeply nurturing connection where both partners support each other's emotional and spiritual growth. Your shared empathy creates a safe space for vulnerability and healing.",
        compatibility: 0.95,
        pros: [
          "Strong emotional understanding and support",
          "Natural healing synergy",
          "Deep spiritual connection",
          "Mutual emotional growth"
        ],
        cons: [
          "May need to focus on practical matters",
          "Risk of emotional codependency",
          "Both need to maintain boundaries",
          "Could become too focused on others' needs"
        ]
      },
      "Mindful Explorer": {
        overview: "A balanced partnership where your emotional depth complements their analytical nature. You provide emotional grounding while they offer intellectual stimulation.",
        compatibility: 0.82,
        pros: [
          "Balance of heart and mind",
          "Complementary perspectives",
          "Growth through differences",
          "Strong emotional foundation"
        ],
        cons: [
          "Different processing styles",
          "Communication challenges",
          "Need to bridge emotional-logical gap",
          "May need to align priorities"
        ]
      },
      "Spiritual Guide": {
        overview: "A spiritually enriching partnership where both partners support each other's growth journey. Your nurturing nature complements their spiritual guidance.",
        compatibility: 0.88,
        pros: [
          "Deep spiritual connection",
          "Mutual support and growth",
          "Complementary healing approaches",
          "Shared values and understanding"
        ],
        cons: [
          "May need practical grounding",
          "Different approaches to spiritual work",
          "Balance needed in helping others",
          "Risk of neglecting personal needs"
        ]
      }
    }
  },
  "Spiritual Guide": {
    description: "As a Spiritual Guide, you are a beacon of wisdom and spiritual insight. Your ability to connect with higher truths and guide others on their spiritual journey makes you a natural leader in relationships. You bring depth, wisdom, and spiritual awareness to all your connections.",
    strengths: ["Spiritual Leadership", "Wisdom Sharing", "Higher Perspective", "Intuitive Guidance", "Deep Understanding"],
    compatibility: {
      "Mystic Healer": {
        overview: "A deeply spiritual connection that fosters mutual growth and understanding. Your guidance complements their healing nature.",
        compatibility: 0.9,
        pros: [
          "Strong spiritual synergy",
          "Complementary healing abilities",
          "Shared spiritual journey",
          "Deep understanding"
        ],
        cons: [
          "May need practical grounding",
          "Different approaches to spirituality",
          "Balance needed in teaching/learning",
          "Risk of spiritual dependency"
        ]
      },
      "Mindful Explorer": {
        overview: "An intellectually stimulating partnership that combines spiritual wisdom with analytical curiosity. Your guidance helps channel their explorations.",
        compatibility: 0.88,
        pros: [
          "Rich spiritual discussions",
          "Balanced perspectives",
          "Mutual growth and learning",
          "Complementary approaches"
        ],
        cons: [
          "Different processing speeds",
          "May clash on methodology",
          "Need to balance theory and practice",
          "Different decision-making styles"
        ]
      },
      "Empathic Nurturer": {
        overview: "A deeply supportive partnership that combines spiritual wisdom with emotional nurturing. Together you create a powerful healing presence.",
        compatibility: 0.88,
        pros: [
          "Strong emotional-spiritual bond",
          "Complementary healing styles",
          "Mutual support system",
          "Shared service orientation"
        ],
        cons: [
          "Need to maintain boundaries",
          "Balance spiritual-emotional focus",
          "Risk of over-giving",
          "May need practical grounding"
        ]
      }
    }
  }
};

function PersonalityCompatibility() {
  const { toast } = useToast();

  // Fetch current user data
  const { data: userData, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const userType = userData?.type || "";
  const userInsights = PERSONALITY_INSIGHTS[userType as keyof typeof PERSONALITY_INSIGHTS];

  if (!userInsights) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold text-primary mb-4">Personality Type Not Found</h2>
            <p className="text-muted-foreground">
              Please complete your personality quiz to view compatibility insights.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl font-bold text-primary mb-4">
                {userType}
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                {userInsights.description}
              </p>
            </motion.div>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Strengths Section */}
            <section className="space-y-4">
              <h2 className="text-2xl font-semibold text-primary">Your Spiritual Strengths</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {userInsights.strengths.map((strength, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-background/50 border-primary/20">
                      <CardContent className="p-4">
                        <h3 className="font-medium text-primary">{strength}</h3>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </section>

            {/* Compatibility Analysis */}
            <section className="space-y-4">
              <h2 className="text-2xl font-semibold text-primary">Compatibility Analysis</h2>
              <div className="grid grid-cols-1 gap-6">
                {Object.entries(userInsights.compatibility).map(([type, analysis], index) => (
                  <motion.div
                    key={type}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-background/50 border-primary/20">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-primary mb-2">{type}</h3>
                            <p className="text-muted-foreground">{analysis.overview}</p>
                          </div>
                          <div className="ml-4">
                            <SparkVisualization compatibility={analysis.compatibility} />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                          {/* Pros */}
                          <div className="space-y-2">
                            <h4 className="font-medium text-green-400">Strengths of This Match</h4>
                            <ul className="space-y-2">
                              {analysis.pros.map((pro, index) => (
                                <li key={index} className="flex items-start gap-2">
                                  <span className="text-green-400">✓</span>
                                  <span className="text-muted-foreground text-sm">{pro}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Cons */}
                          <div className="space-y-2">
                            <h4 className="font-medium text-amber-400">Growth Opportunities</h4>
                            <ul className="space-y-2">
                              {analysis.cons.map((con, index) => (
                                <li key={index} className="flex items-start gap-2">
                                  <span className="text-amber-400">•</span>
                                  <span className="text-muted-foreground text-sm">{con}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default withPremium(PersonalityCompatibility);