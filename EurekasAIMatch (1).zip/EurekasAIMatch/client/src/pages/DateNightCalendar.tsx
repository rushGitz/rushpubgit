import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { format, parse, isValid, setHours, setMinutes } from "date-fns";
import { type User, type DateNight } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";
import { useConfetti } from "@/hooks/use-confetti";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon2, Clock, User as UserIcon, Crown, Send, X, Clock as ClockIcon, Loader2 } from "lucide-react";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Check } from "lucide-react";

// Add strongly typed mutation response interface
interface DateStatusUpdateResponse {
  success: boolean;
  dateNight: DateNight;
}

const dateFormSchema = z.object({
  time: z.string(),
  notes: z.string().optional(),
});

type DateFormValues = z.infer<typeof dateFormSchema>;

export default function DateNightCalendar() {
  // 1. All useState hooks
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isScheduling, setIsScheduling] = useState(false);

  // 2. Other hooks
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fireConfetti = useConfetti();

  // 3. Form hook
  const form = useForm<DateFormValues>({
    resolver: zodResolver(dateFormSchema),
    defaultValues: {
      time: "19:00",
      notes: "",
    },
  });

  // 4. Query hooks - Removed suspense and error boundary
  const { data: dateNights, isLoading: isLoadingDateNights, error: dateNightsError } = useQuery<DateNight[]>({
    queryKey: ['/api/date-nights'],
    enabled: !!user?.id,
    retry: 3,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: allUsers = [], isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ['/api/all-users'],  // Updated endpoint
    enabled: !!user?.id,
    retry: 3,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: matches = [], isLoading: isLoadingMatches } = useQuery<User[]>({
    queryKey: ['/api/matches'],
    enabled: !!user?.id,
    retry: 3,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // 5. Mutation hooks
  const createDateNight = useMutation({
    mutationFn: async (data: { guestId: number; scheduledFor: Date; notes?: string }) => {
      const response = await fetch('/api/date-nights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to create date night');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
      toast({
        title: "Date Invitation Sent! ✨",
        description: "Your virtual date invitation has been sent. We'll notify you when they respond!",
      });
      form.reset();
      setIsScheduling(false);
    },
    onError: (error: Error) => {
      console.error('Error creating date night:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to send date invitation. Please try again.",
        variant: "destructive",
      });
    }
  });

  const respondToDate = useMutation<
    DateStatusUpdateResponse,
    Error,
    { dateId: number; status: 'accepted' | 'declined' | 'raincheck' }
  >({
    mutationFn: async ({ dateId, status }) => {
      const response = await fetch(`/api/date-nights/${dateId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Failed to update date night status');
      }

      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });

      const messages = {
        accepted: { title: "Date Accepted! ✨", description: "We've notified your match. Get ready for your virtual date!" },
        declined: { title: "Date Declined", description: "No worries! We've notified the other person." },
        raincheck: { title: "Raincheck Requested", description: "We've let them know you'd like to reschedule." }
      };

      if (variables.status === 'accepted') {
        fireConfetti();
      }

      toast({
        title: messages[variables.status].title,
        description: messages[variables.status].description,
        variant: variables.status === 'declined' ? "destructive" : "default"
      });
    },
    onError: (error: Error) => {
      console.error('Error responding to date:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update date status. Please try again.",
        variant: "destructive",
      });
    }
  });

  const cancelDateMutation = useMutation({
    mutationFn: async (dateId: number) => {
      const response = await fetch(`/api/date-nights/${dateId}/cancel`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to cancel date');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
      toast({
        title: "Date Cancelled",
        description: "The date has been cancelled. We've notified the other person.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to cancel the date. Please try again.",
        variant: "destructive",
      });
    }
  });

  // 6. useEffect hooks
  useEffect(() => {
    if (dateNightsError) {
      console.error('Date nights fetch error:', dateNightsError);
      toast({
        title: "Error Loading Dates",
        description: "Failed to load your date nights. Please refresh the page.",
        variant: "destructive"
      });
    }
  }, [dateNightsError, toast]);

  // Show loading state if any required data is still loading
  if (isLoadingDateNights || isLoadingUsers || isLoadingMatches) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading your date night calendar...</p>
        </div>
      </div>
    );
  }

  // Show error state if there are any query errors
  if (dateNightsError) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <p className="text-destructive">Error loading date nights</p>
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] })}>
            Retry
          </Button>
        </div>
      </div>
    );
  }

  const groupedDates = (dateNights ?? []).reduce((acc: Record<string, DateNight[]>, date: DateNight) => {
    if (!date || !date.scheduledFor) return acc;

    const dateTime = new Date(date.scheduledFor);
    const now = new Date();
    const status = date.status.toLowerCase();

    const isPast = dateTime.getTime() < now.getTime();

    if (isPast) {
      if (status === 'accepted' || status === 'confirmed' || status === 'completed') {
        acc.past.push(date);
      }
    } else {
      if (status === 'accepted' || status === 'confirmed') {
        acc.upcoming.push(date);
      } else if (status === 'pending' || status === 'raincheck') {
        acc.pending.push(date);
      }
    }

    // Sort dates
    acc.upcoming.sort((a: DateNight, b: DateNight) => new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime());
    acc.past.sort((a: DateNight, b: DateNight) => new Date(b.scheduledFor).getTime() - new Date(a.scheduledFor).getTime());
    acc.pending.sort((a: DateNight, b: DateNight) => new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime());

    return acc;
  }, { upcoming: [], pending: [], past: [] });

  const checkForConflicts = (selectedDate: Date, selectedTime: string) => {
    if (!dateNights || !selectedDate || !selectedTime) return false;

    const [hours, minutes] = selectedTime.split(":").map(Number);
    const scheduledDate = setMinutes(setHours(selectedDate, hours), minutes);

    return dateNights.some(dateNight => {
      if (!dateNight.scheduledFor) return false;
      const existingDate = new Date(dateNight.scheduledFor);
      const timeDiff = Math.abs(existingDate.getTime() - scheduledDate.getTime());
      const hoursDiff = timeDiff / (1000 * 60 * 60);
      return hoursDiff <= 2 && ['pending', 'accepted'].includes(dateNight.status.toLowerCase());
    });
  };

  const handleScheduleDate = (guestId: number) => {
    if (!selectedDate) {
      toast({
        title: "Select a Date",
        description: "Please select a date from the calendar first.",
        variant: "destructive"
      });
      return;
    }

    const formValues = form.getValues();
    const [hours, minutes] = formValues.time.split(":").map(Number);
    const scheduledDate = setMinutes(setHours(selectedDate, hours), minutes);

    if (checkForConflicts(selectedDate, formValues.time)) {
      toast({
        title: "Scheduling Conflict",
        description: "You already have a date scheduled within 2 hours of this time. Please choose a different time.",
        variant: "destructive"
      });
      return;
    }

    createDateNight.mutate({
      guestId,
      scheduledFor: scheduledDate,
      notes: formValues.notes,
    });
  };

  const uniqueMatches = Array.from(new Set(matches.filter(match => match.id !== user?.id).map(match => match.id)))
    .map(id => matches.find(match => match.id === id))
    .filter((match): match is User => match !== undefined);

  const getRandomIceBreakers = () => {
    const iceBreakers = [
      "What's the most adventurous thing you've done recently?",
      "What's your favorite way to recharge after a long day?",
      "What's a skill you'd love to master one day?",
      "What's the best advice someone's given you?",
      "What's a small thing that always makes you smile?",
      "If you could have dinner with anyone from history, who would it be?",
      "What's your favorite way to express creativity?",
      "What's a place you find most peaceful?",
      "What's a hobby that you'd like to share with someone?",
      "What's a personal value that's really important to you?"
    ];
    return iceBreakers.sort(() => 0.5 - Math.random()).slice(0, 3);
  };

  const getEncouragingMessage = () => {
    const messages = [
      "Remember, being yourself is your greatest strength. Your match is just as excited to meet you! 💫",
      "Every great connection starts with a simple hello. You've got this, and you're already amazing! ✨",
      "Take a deep breath - you're about to share wonderful moments with someone special. Just be your authentic self! 🌟",
      "Your unique perspective and experiences make you interesting. Embrace the journey of getting to know each other! 💝",
      "You're brave for opening your heart to new connections. That alone makes you remarkable! 🌈",
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  const renderDateCard = (date: DateNight, status: 'upcoming' | 'pending' | 'past') => {
    const otherUser = getUserDetails(
      date.hostId === user?.id ? date.guestId : date.hostId,
      allUsers,
      matches
    );

    if (!otherUser) {
      console.log('Other user not found:', {
        dateId: date.id,
        hostId: date.hostId,
        guestId: date.guestId,
        currentUserId: user?.id,
        allUsersCount: allUsers.length,
        matchesCount: matches.length
      });
    }

    const isHost = date.hostId === user?.id;
    const isPending = status === 'pending';
    const isUpcoming = status === 'upcoming';

    return (
      <Card key={date.id} className={`border-primary/20 ${isPending ? 'hover:border-primary/40' : ''} transition-colors duration-200`}>
        <CardContent className="p-4">
          <div className="flex items-start space-x-4">
            <div className="space-y-1 flex-1">
              <p className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                {date.scheduledFor ? formatDateSafely(new Date(date.scheduledFor)) : "Date not set"}
              </p>
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <UserIcon className="w-4 h-4" />
                {otherUser?.name || `User ${date.hostId === user?.id ? date.guestId : date.hostId}`}
              </p>
              <Badge variant="outline" className="flex items-center gap-1 w-fit">
                {isHost ? (
                  <>
                    <Crown className="w-3 h-3" />
                    Hosting
                  </>
                ) : (
                  "Guest"
                )}
              </Badge>
            </div>
          </div>

          {isUpcoming && (
            <div className="space-y-2 mt-4">
              <Button
                className="w-full"
                onClick={() => {
                  window.open('https://www.spatial.io/s/Eurekas-VR-Hangout-6743b7b7f55ce82a72052644?share=2375748144776782220', '_blank');
                  toast({
                    title: "Joining Virtual Date! 🌟",
                    description: "Have a wonderful time! Remember to be respectful and have fun!",
                  });
                }}
              >
                <Send className="w-4 h-4 mr-2" />
                Join Date
              </Button>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="w-full text-destructive hover:text-destructive">
                    Cancel Date
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Cancel This Date?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will cancel your scheduled date and notify the other person. Please only cancel if necessary.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <div className="flex justify-end space-x-2">
                    <AlertDialogCancel>Keep Date</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => cancelDateMutation.mutate(date.id)}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Yes, Cancel Date
                    </AlertDialogAction>
                  </div>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}

          {isPending && !isHost && (
            <div className="flex flex-wrap gap-1.5 mt-4">
              <Button
                size="sm"
                className="px-2.5 py-1 text-xs"
                onClick={() => respondToDate.mutate({ dateId: date.id, status: "accepted" })}
              >
                <Check className="w-3.5 h-3.5 mr-1.5" />
                Accept
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="px-2.5 py-1 text-xs"
                onClick={() => respondToDate.mutate({ dateId: date.id, status: "declined" })}
              >
                <X className="w-3.5 h-3.5 mr-1.5" />
                Decline
              </Button>
              <Button
                size="sm"
                variant="secondary"
                className="px-2.5 py-1 text-xs"
                onClick={() => respondToDate.mutate({ dateId: date.id, status: "raincheck" })}
              >
                <ClockIcon className="w-3.5 h-3.5 mr-1.5" />
                Raincheck
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const getUserDetails = (userId: number, allUsers: User[], matches: User[]): User | undefined => {
    if (!userId) return undefined;

    // First try to find in allUsers
    const userFromAll = allUsers.find(u => u.id === userId);
    if (userFromAll) return userFromAll;

    // Then try to find in matches
    const userFromMatches = matches.find(m => m.id === userId);
    if (userFromMatches) return userFromMatches;

    // Enhanced debugging
    console.log(`User not found for ID: ${userId}`, {
      allUsers: allUsers.length,
      matches: matches.length,
      allUserIds: allUsers.map(u => u.id),
      matchUserIds: matches.map(m => m.id)
    });

    return undefined;
  };

  const formatDateSafely = (dateStr: string | Date | null | undefined): string => {
    if (!dateStr) return "Date not set";
    try {
      let date: Date;
      if (typeof dateStr === 'string') {
        date = parse(dateStr, "MMM dd, yyyy - h:mm a", new Date());
        if (!isValid(date)) {
          date = new Date(dateStr);
        }
      } else {
        date = dateStr;
      }

      if (!isValid(date)) return "Invalid date";
      return format(date, "MMM dd, yyyy - h:mm a");
    } catch (error) {
      console.error('Error formatting date:', error);
      return "Invalid date";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <CalendarIcon2 className="w-5 h-5 text-primary" />
              Date Night Status Overview
            </h2>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="confirmed" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="confirmed">
                  Confirmed
                  {groupedDates.upcoming.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {groupedDates.upcoming.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="pending">
                  Pending
                  {groupedDates.pending.length > 0 && (
                    <Badge variant="destructive" className="ml-2">
                      {groupedDates.pending.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="past">Past</TabsTrigger>
              </TabsList>

              <TabsContent value="confirmed" className="mt-4">
                <div className="space-y-4">
                  {groupedDates.upcoming.length === 0 ? (
                    <p className="text-center text-muted-foreground py-4">No confirmed dates</p>
                  ) : (
                    groupedDates.upcoming.map((date) => renderDateCard(date, 'upcoming'))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="pending" className="mt-4">
                <div className="space-y-4">
                  {groupedDates.pending.length === 0 ? (
                    <p className="text-center text-muted-foreground py-4">No pending date requests</p>
                  ) : (
                    groupedDates.pending.map((date) => renderDateCard(date, 'pending'))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="past" className="mt-4">
                <div className="space-y-4">
                  {groupedDates.past.length === 0 ? (
                    <p className="text-center text-muted-foreground py-4">No past dates</p>
                  ) : (
                    groupedDates.past.map((date) => renderDateCard(date, 'past'))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h1 className="text-3xl font-bold text-center text-primary">Virtual Date Night Calendar</h1>
            <p className="text-center text-muted-foreground">
              Schedule and manage your virtual dates in our safe and magical space ✨
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Card className="border-primary/20">
                  <CardHeader>
                    <h2 className="text-xl font-semibold">Schedule a New Date</h2>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      className="rounded-md border"
                      disabled={(date) => date < new Date()}
                    />

                    <Dialog open={isScheduling} onOpenChange={setIsScheduling}>
                      <DialogTrigger asChild>
                        <Button className="w-full" disabled={!selectedDate}>
                          <CalendarIcon2 className="w-4 h-4 mr-2" />
                          Schedule Virtual Date
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Schedule a Virtual Date</DialogTitle>
                          <DialogDescription>
                            Select a time and a match for your virtual date.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <h3 className="text-sm font-medium">Select Time</h3>
                            <Select
                              value={form.watch("time")}
                              onValueChange={(value) => form.setValue("time", value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Choose time" />
                              </SelectTrigger>
                              <SelectContent>
                                {Array.from({ length: 48 }, (_, i) => {
                                  const hour = Math.floor(i / 2);
                                  const minutes = i % 2 === 0 ? "00" : "30";
                                  const time = `${hour.toString().padStart(2, "0")}:${minutes}`;
                                  return (
                                    <SelectItem key={time} value={time}>
                                      {format(
                                        setMinutes(setHours(new Date(), hour), parseInt(minutes)),
                                        "h:mm a"
                                      )}
                                    </SelectItem>
                                  );
                                })}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <h3 className="text-sm font-medium">Choose Your Match</h3>
                            <ScrollArea className="h-[200px]">
                              <div className="space-y-1 pr-2">
                                {uniqueMatches.map((match) => (
                                  <Button
                                    key={match.id}
                                    variant="outline"
                                    onClick={() => handleScheduleDate(match.id)}
                                    className="w-full justify-end text-right"
                                  >
                                    <span className="flex-1 text-left">{match.name}</span>
                                    <img
                                      src={match.image}
                                      alt={match.name}
                                      className="w-6 h-6 rounded-full ml-2"
                                    />
                                  </Button>
                                ))}
                                {uniqueMatches.length === 0 && (
                                  <p className="text-center text-muted-foreground py-2">
                                    No matches available for scheduling
                                  </p>
                                )}
                              </div>
                            </ScrollArea>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Tabs defaultValue="confirmed">
                  <TabsContent value="confirmed" className="m-0">
                    <h2 className="text-xl font-semibold mb-4">Upcoming Confirmed Dates</h2>
                    {groupedDates.upcoming.length === 0 ? (
                      <Card className="border-dashed">
                        <CardContent className="text-center py-8 text-muted-foreground">
                          No upcoming confirmed dates
                        </CardContent>
                      </Card>
                    ) : (
                      <div className="space-y-4">
                        <AnimatePresence>
                          {groupedDates.upcoming.map((date) => (
                            <motion.div
                              key={date.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -20 }}
                            >
                              {renderDateCard(date, 'upcoming')}
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="pending" className="m-0">
                    <h2 className="text-xl font-semibold mb-4">Pending Date Requests</h2>
                    {groupedDates.pending.length === 0 ? (
                      <Card className="border-dashed">
                        <CardContent className="text-center py-8 text-muted-foreground">
                          No pending date requests
                        </CardContent>
                      </Card>
                    ) : (
                      <div className="space-y-4">
                        <AnimatePresence>
                          {groupedDates.pending.map((date) => (
                            <motion.div
                              key={date.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -20 }}
                            >
                              {renderDateCard(date, 'pending')}
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="past" className="m-0">
                    <h2 className="text-xl font-semibold mb-4">Past Dates</h2>
                    {groupedDates.past.length === 0 ? (
                      <Card className="border-dashed">
                        <CardContent className="text-center py-8 text-muted-foreground">
                          No past dates
                        </CardContent>
                      </Card>
                    ) : (
                      <div className="space-y-4">
                        {groupedDates.past.map((date) => renderDateCard(date, 'past'))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}