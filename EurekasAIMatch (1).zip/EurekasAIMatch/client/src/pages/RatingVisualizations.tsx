import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { PoliticalRadarChart } from "@/components/PoliticalRadarChart";
import { KinkRadarChart } from "@/components/KinkRadarChart";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

export default function RatingVisualizations() {
  const { user } = useAuth();

  const { data: userData, isLoading } = useQuery({
    queryKey: ['/api/user', user?.id],
    enabled: !!user?.id,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70">
          Your Rating Profiles
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Political Activist Rating */}
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-6 text-white">Political Activist Profile</h2>
              {userData?.politicalScores ? (
                <PoliticalRadarChart scores={userData.politicalScores} />
              ) : (
                <p className="text-white/60 text-center py-8">
                  No political activist data available yet. Complete the quiz to see your profile!
                </p>
              )}
            </CardContent>
          </Card>

          {/* Kink Rating */}
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-6 text-white">Kink Profile</h2>
              {userData?.kinkScores ? (
                <KinkRadarChart scores={userData.kinkScores} />
              ) : (
                <p className="text-white/60 text-center py-8">
                  No kink rating data available yet. Complete the quiz to see your profile!
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
