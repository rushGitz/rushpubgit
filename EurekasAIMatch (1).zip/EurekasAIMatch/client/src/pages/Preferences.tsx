import { useState, useEffect as ReactuseEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const preferencesSchema = z.object({
  petPreference: z.enum(["Loves Pets", "Has Pets", "No Pets", "Allergic"]),
  smokingPreference: z.enum(["Non-smoker", "Social Smoker", "Regular Smoker", "No Preference"]),
  cohabitationPreference: z.enum(["Wants to Live Together", "Prefers Living Apart", "Open to Both"]),
  longDistancePreference: z.enum(["Open to Long Distance", "Local Only", "Willing to Relocate"]),
  physicalPreferences: z.object({
    height: z.string().optional(),
    bodyType: z.string().optional(),
    style: z.string().optional(),
  }),
  intimacyPreferences: z.object({
    pace: z.string().optional(),
    pda: z.string().optional(),
    approach: z.string().optional(),
  }),
});

type PreferencesFormData = z.infer<typeof preferencesSchema>;

type PreferencesResponse = {
  petPreference: PreferencesFormData["petPreference"];
  smokingPreference: PreferencesFormData["smokingPreference"];
  cohabitationPreference: PreferencesFormData["cohabitationPreference"];
  longDistancePreference: PreferencesFormData["longDistancePreference"];
  physicalPreferences: PreferencesFormData["physicalPreferences"];
  intimacyPreferences: PreferencesFormData["intimacyPreferences"];
};

export default function Preferences() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const form = useForm<PreferencesFormData>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: {
      petPreference: "No Pets",
      smokingPreference: "Non-smoker",
      cohabitationPreference: "Open to Both",
      longDistancePreference: "Open to Long Distance",
      physicalPreferences: {},
      intimacyPreferences: {},
    },
  });

  const { data: preferences, isLoading: isLoadingPreferences, error: preferencesError } = useQuery<PreferencesResponse>({
    queryKey: ["/api/preferences"],
    queryFn: async () => {
      const response = await fetch("/api/preferences");
      if (!response.ok) {
        throw new Error("Failed to fetch preferences");
      }
      return response.json();
    },
    staleTime: 30000,
  });

  // Update form with preferences data when available
  ReactuseEffect(() => {
    if (preferences) {
      Object.entries(preferences).forEach(([key, value]) => {
        form.setValue(key as keyof PreferencesFormData, value);
      });
    }
  }, [preferences, form]);

  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: PreferencesFormData) => {
      const response = await apiRequest("POST", "/api/preferences", {
        ...data,
        userId: user?.id,
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to update preferences");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/preferences"] });
      toast({
        title: "Preferences Updated",
        description: "Your lifestyle preferences have been saved.",
      });
      navigate("/profile");
    },
    onError: (error: Error) => {
      console.error("Error updating preferences:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PreferencesFormData) => {
    updatePreferencesMutation.mutate(data);
  };

  if (isLoadingPreferences) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h1 className="text-3xl font-bold text-center text-primary">Lifestyle Preferences</h1>
          </CardHeader>
          <CardContent>
            {preferencesError && (
              <Alert variant="destructive" className="mb-6">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                  There was an error loading your preferences. Please try refreshing the page.
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Basic Preferences */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-primary">Basic Preferences</h2>

                <div className="space-y-2">
                  <Label>Pet Preference</Label>
                  <Select
                    value={form.watch("petPreference")}
                    onValueChange={(value) => form.setValue("petPreference", value as PreferencesFormData["petPreference"])}
                    disabled={updatePreferencesMutation.isPending}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your pet preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Loves Pets">Loves Pets</SelectItem>
                      <SelectItem value="Has Pets">Has Pets</SelectItem>
                      <SelectItem value="No Pets">No Pets</SelectItem>
                      <SelectItem value="Allergic">Allergic</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.petPreference && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.petPreference.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Smoking Preference</Label>
                  <Select
                    value={form.watch("smokingPreference")}
                    onValueChange={(value) => form.setValue("smokingPreference", value as PreferencesFormData["smokingPreference"])}
                    disabled={updatePreferencesMutation.isPending}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your smoking preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Non-smoker">Non-smoker</SelectItem>
                      <SelectItem value="Social Smoker">Social Smoker</SelectItem>
                      <SelectItem value="Regular Smoker">Regular Smoker</SelectItem>
                      <SelectItem value="No Preference">No Preference</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.smokingPreference && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.smokingPreference.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Living Arrangement</Label>
                  <Select
                    value={form.watch("cohabitationPreference")}
                    onValueChange={(value) => form.setValue("cohabitationPreference", value as PreferencesFormData["cohabitationPreference"])}
                    disabled={updatePreferencesMutation.isPending}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your living preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Wants to Live Together">Wants to Live Together</SelectItem>
                      <SelectItem value="Prefers Living Apart">Prefers Living Apart</SelectItem>
                      <SelectItem value="Open to Both">Open to Both</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.cohabitationPreference && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.cohabitationPreference.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Distance Preference</Label>
                  <Select
                    value={form.watch("longDistancePreference")}
                    onValueChange={(value) => form.setValue("longDistancePreference", value as PreferencesFormData["longDistancePreference"])}
                    disabled={updatePreferencesMutation.isPending}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your distance preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Open to Long Distance">Open to Long Distance</SelectItem>
                      <SelectItem value="Local Only">Local Only</SelectItem>
                      <SelectItem value="Willing to Relocate">Willing to Relocate</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.longDistancePreference && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.longDistancePreference.message}
                    </p>
                  )}
                </div>
              </div>

              <Separator />

              {/* Submit Button */}
              <div className="space-y-4">
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/80"
                  disabled={updatePreferencesMutation.isPending}
                >
                  {updatePreferencesMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Preferences"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}