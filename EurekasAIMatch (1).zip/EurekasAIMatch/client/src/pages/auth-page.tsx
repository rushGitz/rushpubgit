import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Slider } from "@/components/ui/slider";
import { generateAvatar } from "@/lib/avatar-generator";
import { AlertCircle } from "lucide-react";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formError, setFormError] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [userLocation, setUserLocation] = useState("");
  const [genderIdentityValue, setGenderIdentityValue] = useState<number>(5);
  const { loginMutation, registerMutation, user } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const validateForm = () => {
    setFormError("");

    if (!username.trim()) {
      setFormError("Username is required");
      return false;
    }

    if (!password.trim()) {
      setFormError("Password is required");
      return false;
    }

    if (password.length < 6) {
      setFormError("Password must be at least 6 characters");
      return false;
    }

    if (!isLogin) {
      if (password !== confirmPassword) {
        setFormError("Passwords don't match");
        return false;
      }

      if (!name.trim()) {
        setFormError("Name is required");
        return false;
      }

      if (!age) {
        setFormError("Age is required");
        return false;
      }

      const ageNum = parseInt(age);
      if (isNaN(ageNum) || ageNum < 18 || ageNum > 120) {
        setFormError("Please enter a valid age (18-120)");
        return false;
      }

      if (!userLocation.trim()) {
        setFormError("Location is required");
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (isLogin) {
        await loginMutation.mutateAsync({ username, password });
      } else {
        const avatarUrl = generateAvatar();
        await registerMutation.mutateAsync({
          username,
          password,
          confirmPassword,
          name,
          age: parseInt(age),
          location: userLocation,
          genderIdentityValue,
          gender_identity: getGenderIdentityLabel(genderIdentityValue),
          bio: "",
          image: avatarUrl,
        });
      }
      navigate("/");
    } catch (error) {
      console.error("Auth error:", error);
      setFormError(error instanceof Error ? error.message : "Authentication failed");
    }
  };

  const getGenderIdentityLabel = (value: number): string => {
    const femininePercentage = (value / 10) * 100;
    if (femininePercentage <= 50) {
      const masculinePercentage = Math.abs(100 - femininePercentage);
      return `${Math.round(masculinePercentage)}% Masculine`;
    } else if (femininePercentage >= 67) {
      return `${Math.round(femininePercentage)}% Feminine`;
    } else {
      return `${Math.round(femininePercentage)}% Feminine (Androgynous)`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 flex">
      <div className="w-full md:w-1/2 p-4 flex items-center justify-center">
        <Card className="w-full max-w-md backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6">
            <div className="flex justify-center mb-6">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              >
                <img src="/logo.png" alt="EurekasMatch" className="w-16 h-16" />
              </motion.div>
            </div>
            <h1 className="text-2xl font-bold text-center mb-6 text-white">
              {isLogin ? "Welcome Back" : "Join EurekasMatch"}
            </h1>
            {formError && (
              <div className="mb-4 p-3 text-sm border border-destructive/50 text-destructive bg-destructive/10 rounded-lg flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                <span>{formError}</span>
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-background/50 border-primary/20"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-background/50 border-primary/20"
              />
              {!isLogin && (
                <Input
                  type="password"
                  placeholder="Confirm Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-background/50 border-primary/20"
                />
              )}
              {!isLogin && (
                <>
                  <Input
                    placeholder="Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <Input
                    type="number"
                    placeholder="Age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <Input
                    placeholder="Location"
                    value={userLocation}
                    onChange={(e) => setUserLocation(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <div className="space-y-3">
                    <label className="text-sm text-white/60">Gender Identity</label>
                    <Slider
                      value={[genderIdentityValue]}
                      onValueChange={([value]) => setGenderIdentityValue(value)}
                      max={10}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-white/60">
                      <span>Masculine</span>
                      <span>Androgynous</span>
                      <span>Feminine</span>
                    </div>
                    <div className="text-center text-sm font-medium text-primary">
                      Selected: {getGenderIdentityLabel(genderIdentityValue)}
                    </div>
                  </div>
                </>
              )}
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/80"
                disabled={loginMutation.isPending || registerMutation.isPending}
              >
                {loginMutation.isPending || registerMutation.isPending ? (
                  "Please wait..."
                ) : isLogin ? (
                  "Login"
                ) : (
                  "Register"
                )}
              </Button>
            </form>
            <p className="text-center mt-4 text-white/60">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => {
                  setIsLogin(!isLogin);
                  setFormError("");
                }}
                className="ml-2 text-primary hover:text-primary/80"
              >
                {isLogin ? "Register" : "Login"}
              </button>
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-primary/20 to-primary/5 items-center justify-center p-12">
        <div className="max-w-lg text-center space-y-6">
          <h2 className="text-4xl font-bold mb-6 text-white">
            Discover Your Soul's Perfect Match
          </h2>
          <p className="text-lg text-white/80 mb-4">
            Welcome to EurekasMatch – where modern dating meets spiritual wisdom. We go beyond
            superficial swipes to connect kindred spirits through our unique blend of emotional
            intelligence, aura matching, and metaphysical compatibility.
          </p>
          <div className="space-y-4 text-white/70">
            <p className="italic">
              "Two souls don't find each other by simple accident." - Jorge Luis Borges
            </p>
            <p className="text-sm">
              In a world of fleeting connections, we believe in the power of authentic spiritual bonds.
              Our AI-powered matching system considers your unique energy, personality archetype, and
              spiritual wavelength to find connections that resonate on a deeper level.
            </p>
            <p className="text-sm">
              Whether you're a Mystic Healer, Mindful Explorer, or Spiritual Guide, your perfect match
              awaits – someone who truly sees and appreciates your inner radiance.
            </p>
            <p className="text-sm mt-4 text-primary/90">
              Join our community of conscious daters and experience dating that honors both your heart
              and soul. ✨
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}