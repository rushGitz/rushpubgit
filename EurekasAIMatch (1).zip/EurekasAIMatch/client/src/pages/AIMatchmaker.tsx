import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import axios from "axios";
import { SparkVisualization } from "@/components/SparkVisualization";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

type Match = {
  id: number;
  name: string;
  age: number;
  bio: string;
  image: string;
  type: string;
  spiritualColor: string | null;
  compatibility: number;
  genderIdentity?: string;
};

export default function AIMatchmaker() {
  const [currentMatch, setCurrentMatch] = useState<Match | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasQuizResults, setHasQuizResults] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    const checkQuizResults = async () => {
      try {
        if (!user?.id) return;

        const response = await axios.get(`/api/user/${user.id}/quiz-results`);

        // If we successfully got the response, check the data
        if (response.data) {
          const hasQuizData = response.data.quizResults && 
            Object.keys(response.data.quizResults).length > 0;
          const hasMetaphysicalScores = response.data.metaphysicalScores && 
            Object.keys(response.data.metaphysicalScores).length > 0;
          const hasType = response.data.type && response.data.type.length > 0;

          if (!(hasQuizData || hasMetaphysicalScores || hasType)) {
            toast({
              title: "Profile Update Needed",
              description: "Please complete your spiritual profile before using AI matchmaking!",
            });
            setLocation("/quiz");
            return;
          }

          // If we have any of the required data, proceed with matching
          setHasQuizResults(true);
          await fetchMatch(response.data.quizResults);
        }
      } catch (error: any) {
        console.error("Error checking quiz results:", error);
        // Only show error toast if it's a real error, not just missing data
        if (error.response?.status !== 404) {
          toast({
            title: "Error",
            description: "Failed to check profile data. Please try again.",
            variant: "destructive",
          });
        } else {
          // If 404, it means no quiz results yet
          toast({
            title: "Profile Update Needed",
            description: "Please complete your spiritual profile before using AI matchmaking!",
          });
          setLocation("/quiz");
        }
      } finally {
        setIsLoading(false);
      }
    };

    checkQuizResults();
  }, [user?.id]);

  const fetchMatch = async (quizResults?: any) => {
    if (!user?.id) return;

    setIsLoading(true);
    try {
      const response = await axios.post("/api/ai-match", {
        userId: user.id,
        quizResults,
        includePersonalityMatching: true,
        includeLifestylePreferences: true,
        includeMetaphysicalScores: true
      });

      if (response.data?.match) {
        setCurrentMatch(response.data.match);
        console.log("AI Match found:", response.data.match);
      } else {
        toast({
          title: "No More Matches",
          description: "Redirecting you to dashboard...",
        });
        setTimeout(() => setLocation("/dashboard"), 1500);
      }
    } catch (error: any) {
      console.error("AI Match error:", error.response?.data || error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to find matches. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = async (action: "right" | "left") => {
    if (!currentMatch) return;

    try {
      await axios.post("/api/match", {
        targetUserId: currentMatch.id,
        action
      });

      toast({
        title: action === "right" ? "Match Sent!" : "Passed",
        description: action === "right"
          ? "We'll let you know if they match back!"
          : "We'll find you another match.",
      });

      const response = await axios.get(`/api/user/${user?.id}/quiz-results`);
      fetchMatch(response.data.quizResults);
    } catch (error: any) {
      console.error("Match error:", error.response?.data || error);
      toast({
        title: "Error",
        description: error.response?.data?.message || "Failed to process your selection. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!hasQuizResults) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <Card className="max-w-md w-full backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6 text-center">
            <h2 className="text-2xl font-bold text-primary mb-4">Spiritual Profile Update Needed</h2>
            <p className="text-muted-foreground mb-6">
              To provide the most accurate spiritual matches, we need your current energy reading.
              Please update your spiritual profile to access AI-powered matches.
            </p>
            <Button
              onClick={() => setLocation("/quiz")}
              className="bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90 transition-all duration-300"
            >
              Update Spiritual Profile ✨
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-primary">Finding your spiritual match...</p>
      </div>
    );
  }

  if (!currentMatch) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <Card className="max-w-md w-full backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6 text-center">
            <h2 className="text-2xl font-bold text-primary mb-4">No More Matches Available</h2>
            <p className="text-muted-foreground mb-6">
              We're currently working on finding your perfect match. 
              Redirecting you to your dashboard...
            </p>
            <div className="flex justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          <Card className="relative backdrop-blur-xl bg-background/60 border-primary/20">
            <CardContent className="p-6">
              <div className="flex flex-col items-center space-y-4">
                <motion.div
                  className="relative"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-full blur-md" />
                  <img
                    src={currentMatch.image}
                    alt={currentMatch.name}
                    className="relative w-48 h-48 rounded-full object-cover border-2 border-primary/50"
                  />
                </motion.div>

                <div className="text-center">
                  <h2 className="text-2xl font-bold mb-2 text-white">
                    {currentMatch.name}, {currentMatch.age}
                  </h2>
                  <p className="text-white/80 mb-4">{currentMatch.bio}</p>

                  <div className="flex flex-wrap justify-center gap-2 mb-4">
                    <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30">
                      {currentMatch.type}
                    </span>
                    {currentMatch.spiritualColor && (
                      <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30 capitalize">
                        {currentMatch.spiritualColor} Aura
                      </span>
                    )}
                  </div>

                  {currentMatch.compatibility > 0 && (
                    <div className="mb-4">
                      <SparkVisualization compatibility={currentMatch.compatibility} />
                      <p className="text-primary/80 text-sm mt-2">
                        {Math.round(currentMatch.compatibility * 100)}% Compatible
                      </p>
                    </div>
                  )}

                  <div className="flex justify-between gap-4">
                    <Button
                      variant="outline"
                      onClick={() => handleAction("left")}
                      className="w-full border-primary/20 hover:bg-primary/20"
                    >
                      Pass
                    </Button>
                    <Button
                      onClick={() => handleAction("right")}
                      className="w-full bg-primary hover:bg-primary/80"
                    >
                      Match
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}