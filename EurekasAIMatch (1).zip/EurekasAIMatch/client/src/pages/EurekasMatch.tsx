import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import axios from "axios";
import { calculateAdvancedCompatibility } from "@/lib/advanced-matching";
import { useSubscriptionStatus } from "@/hooks/use-subscription";
import { type User } from "@shared/schema";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Filter, Settings2 } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Crown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface MatchProfile extends User {
  compatibility?: {
    score: number;
    reasons: string[];
  };
  auraColor?: string;
}

interface FilterOptions {
  minCompatibility: number;
  onlyShowSpiritual: boolean;
  spiritualColorPreference: string | null;
  personalityTypePreference: string | null;
  auraColorPreference: string | null;
}

export default function EurekasMatch() {
  const [availableProfiles, setAvailableProfiles] = useState<MatchProfile[]>([]);
  const [filteredProfiles, setFilteredProfiles] = useState<MatchProfile[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [match, setMatch] = useState<MatchProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasQuizResults, setHasQuizResults] = useState(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    minCompatibility: 0,
    onlyShowSpiritual: false,
    spiritualColorPreference: null,
    personalityTypePreference: null,
    auraColorPreference: null,
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { isSubscribed } = useSubscriptionStatus();

  // Check for quiz results
  useEffect(() => {
    const checkQuizResults = async () => {
      try {
        if (!user?.id) return;

        const response = await axios.get(`/api/user/${user.id}/quiz-results`);

        // If we successfully got the response, check the data
        if (response.data) {
          const hasQuizData = response.data.quizResults &&
            Object.keys(response.data.quizResults).length > 0;
          const hasMetaphysicalScores = response.data.metaphysicalScores &&
            Object.keys(response.data.metaphysicalScores).length > 0;
          const hasType = response.data.type && response.data.type.length > 0;

          if (!(hasQuizData || hasMetaphysicalScores || hasType)) {
            toast({
              title: "Profile Update Needed",
              description: "Please complete your spiritual profile to start matching!",
            });
            setLocation("/quiz");
            return;
          }

          // If we have any of the required data, proceed with fetching profiles
          setHasQuizResults(true);
          await fetchProfiles();
        }
      } catch (error: any) {
        console.error("Error checking quiz results:", error);
        // Only show error toast if it's a real error, not just missing data
        if (error.response?.status !== 404) {
          toast({
            title: "Error",
            description: "Failed to check profile data. Please try again.",
            variant: "destructive",
          });
        } else {
          // If 404, it means no quiz results yet
          toast({
            title: "Profile Update Needed",
            description: "Please complete your spiritual profile to start matching!",
          });
          setLocation("/quiz");
        }
      }
    };

    checkQuizResults();
  }, [user?.id]);

  // Fetch profiles function updated to include advanced matching
  const fetchProfiles = async () => {
    try {
      const response = await axios.get<User[]>("/api/users");
      let profiles = response.data;

      // Apply advanced matching algorithm for premium users
      if (isSubscribed && user) {
        profiles = profiles
          .map((profile) => ({
            ...profile,
            compatibility: calculateAdvancedCompatibility(user, profile)
          }))
          .sort((a, b) => (b.compatibility?.score || 0) - (a.compatibility?.score || 0));
      }

      setAvailableProfiles(profiles);
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching profiles:", error);
      toast({
        title: "Error",
        description: "Failed to load profiles. Please try again.",
        variant: "destructive",
      });
    }
  };

  // WebSocket connection for real-time match notifications
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'match') {
        toast({
          title: "New Match!",
          description: `You matched with ${data.match.name}!`,
        });
      }
    };

    return () => socket.close();
  }, []);

  // Show no profiles message only when profiles are loaded and none are available
  useEffect(() => {
    if (!isLoading && availableProfiles.length === 0) {
      toast({
        title: "No Profiles Available",
        description: "Check back later for new matches!",
      });
    }
  }, [isLoading, availableProfiles.length]);

  // Handle swipe action
  const handleSwipe = async (direction: 'left' | 'right') => {
    const currentUser = filteredProfiles[currentIndex];
    if (!currentUser) return;

    try {
      const response = await axios.post("/api/match", {
        targetUserId: currentUser.id,
        action: direction
      });

      setMatch(response.data.match);
      setCurrentIndex(prev => prev + 1);

      // Show message when no more profiles after this swipe
      if (currentIndex === filteredProfiles.length - 1) {
        toast({
          title: "No More Profiles",
          description: "You've seen all available profiles. Check back later for new matches!",
        });
      }
    } catch (error) {
      console.error("Error handling swipe:", error);
      toast({
        title: "Error",
        description: "Failed to process your selection. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Apply filters whenever filter options or available profiles change
  const applyFilters = () => {
    let filtered = [...availableProfiles];

    if (isSubscribed) {
      if (filterOptions.minCompatibility > 0) {
        filtered = filtered.filter(
          profile => (profile.compatibility?.score || 0) >= filterOptions.minCompatibility
        );
      }

      if (filterOptions.onlyShowSpiritual) {
        filtered = filtered.filter(profile =>
          profile.metaphysicalScores && Object.values(profile.metaphysicalScores).some(score => score > 7)
        );
      }

      if (filterOptions.auraColorPreference) {
        filtered = filtered.filter(
          profile => profile.auraColor === filterOptions.auraColorPreference
        );
      }

      if (filterOptions.personalityTypePreference) {
        filtered = filtered.filter(
          profile => profile.type === filterOptions.personalityTypePreference
        );
      }
      if (filterOptions.spiritualColorPreference) {
        filtered = filtered.filter(
          profile => profile.spiritualColor === filterOptions.spiritualColorPreference
        );
      }
    }

    setFilteredProfiles(filtered);
    setCurrentIndex(0);
  };

  // Apply filters whenever filter options or available profiles change
  useEffect(() => {
    applyFilters();
  }, [filterOptions, availableProfiles]);

  const currentUser = filteredProfiles[currentIndex];
  const hasMoreProfiles = currentIndex < filteredProfiles.length;

  // Update the profile card to show aura information for premium users
  const renderAuraInfo = (user: MatchProfile) => {
    if (!user.auraColor) return null;

    if (isSubscribed) {
      return (
        <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30 capitalize">
          {user.auraColor} Aura
        </span>
      );
    }

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <Badge variant="outline" className="cursor-pointer">
              <Crown className="h-3 w-3 mr-1 text-yellow-500" />
              Premium Only
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>Upgrade to Premium to view aura colors!</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };

  // Filter UI Component
  const FilterSheet = () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="fixed top-4 right-4">
          <Filter className="h-4 w-4" />
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            Enhanced Filtering Options
            {isSubscribed && <Crown className="h-4 w-4 text-yellow-500" />}
          </SheetTitle>
        </SheetHeader>
        <div className="space-y-6 py-4">
          {isSubscribed ? (
            <>
              <div className="space-y-2">
                <Label>Minimum Compatibility Score</Label>
                <Slider
                  defaultValue={[filterOptions.minCompatibility]}
                  max={100}
                  step={5}
                  onValueChange={([value]) =>
                    setFilterOptions(prev => ({ ...prev, minCompatibility: value }))
                  }
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="spiritual-mode"
                  checked={filterOptions.onlyShowSpiritual}
                  onCheckedChange={checked =>
                    setFilterOptions(prev => ({ ...prev, onlyShowSpiritual: checked }))
                  }
                />
                <Label htmlFor="spiritual-mode">Show Only Highly Spiritual Matches</Label>
              </div>
              <div className="space-y-2">
                <Label>Preferred Aura Color</Label>
                <Select
                  value={filterOptions.auraColorPreference || ""}
                  onValueChange={value =>
                    setFilterOptions(prev => ({
                      ...prev,
                      auraColorPreference: value === "" ? null : value,
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Aura Color" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any Aura Color</SelectItem>
                    <SelectItem value="purple">Purple</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                    <SelectItem value="silver">Silver</SelectItem>
                    <SelectItem value="white">White</SelectItem>
                    <SelectItem value="blue">Blue</SelectItem>
                    <SelectItem value="green">Green</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Preferred Spiritual Color</Label>
                <Select
                  value={filterOptions.spiritualColorPreference || ""}
                  onValueChange={value =>
                    setFilterOptions(prev => ({
                      ...prev,
                      spiritualColorPreference: value === "" ? null : value,
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Color" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any Color</SelectItem>
                    <SelectItem value="purple">Purple</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                    <SelectItem value="silver">Silver</SelectItem>
                    <SelectItem value="white">White</SelectItem>
                    <SelectItem value="blue">Blue</SelectItem>
                    <SelectItem value="green">Green</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Preferred Personality Type</Label>
                <Select
                  value={filterOptions.personalityTypePreference || ""}
                  onValueChange={value =>
                    setFilterOptions(prev => ({
                      ...prev,
                      personalityTypePreference: value === "" ? null : value,
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Any Type</SelectItem>
                    <SelectItem value="Mystic Healer">Mystic Healer</SelectItem>
                    <SelectItem value="Spiritual Guide">Spiritual Guide</SelectItem>
                    <SelectItem value="Empathic Nurturer">Empathic Nurturer</SelectItem>
                    <SelectItem value="Mindful Explorer">Mindful Explorer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <Settings2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Premium Feature</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Upgrade to Premium to access enhanced filtering options, view aura colors, and find your perfect spiritual match!
              </p>
              <Button
                onClick={() => setLocation("/subscription")}
                className="w-full bg-primary hover:bg-primary/80"
              >
                Upgrade to Premium
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );

  if (!hasMoreProfiles) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <Card className="relative w-full max-w-md backdrop-blur-xl bg-background/60 border-primary/20 shadow-[0_0_15px_rgba(236,72,153,0.3)] rounded-[20px] p-8">
          <CardContent className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-white">No More Profiles</h2>
            <p className="text-white/80 mb-6">Take a break and check back later for new matches!</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <FilterSheet />
      {currentUser && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md relative"
        >
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20 shadow-xl">
            <CardContent className="p-6">
              <div className="relative mb-6">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-full blur-md" />
                <img
                  src={currentUser.image}
                  alt={currentUser.name}
                  className="relative w-48 h-48 rounded-full object-cover border-2 border-primary/50"
                />
              </div>

              {isSubscribed && currentUser.compatibility && (
                <div className="mb-4 text-center">
                  <h3 className="text-lg font-semibold text-primary mb-2">
                    Compatibility Score: {currentUser.compatibility.score}%
                  </h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {currentUser.compatibility.reasons.map((reason, i) => (
                      <li key={i}>• {reason}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="text-center">
                <h2 className="text-2xl font-bold mb-2 text-white">
                  {currentUser.name}, {currentUser.age}
                </h2>
                <p className="text-white/80 mb-4">{currentUser.bio}</p>
                <div className="flex flex-wrap justify-center gap-2">
                  <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30">
                    {currentUser.type}
                  </span>
                  {renderAuraInfo(currentUser)}
                </div>
              </div>

              <div className="flex justify-between w-full mt-8 gap-4">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleSwipe("left")}
                  className="w-full border-primary/20 hover:bg-primary/20 backdrop-blur-sm transition-all duration-300"
                >
                  Pass
                </Button>
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => handleSwipe("right")}
                  className="w-full bg-primary hover:bg-primary/80 transition-all duration-300"
                >
                  Match
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}