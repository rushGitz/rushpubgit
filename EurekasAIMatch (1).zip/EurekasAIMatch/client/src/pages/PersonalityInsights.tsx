import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { calculateAuraColor, getReadableAuraColor, type AuraColor } from "@/lib/auraCalculator";
import { AuraRevealEffect } from "@/components/AuraRevealEffect";
import type { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { SiStripe } from "react-icons/si";

const PERSONALITY_INSIGHTS = {
  "Mystic Healer": {
    description: "As a Mystic Healer, you possess a natural ability to channel healing energies and connect with the spiritual realm. Your intuitive powers are particularly strong when it comes to sensing and addressing others' physical and emotional needs.",
    strengths: [
      "Deep intuitive healing abilities",
      "Strong connection to spiritual energies",
      "Natural ability to sense others' needs",
      "Powerful emotional awareness"
    ]
  },
  "Spiritual Guide": {
    description: "Being a Spiritual Guide, you have a unique gift for helping others navigate their spiritual journey. Your wisdom and insights serve as a beacon for those seeking deeper meaning and understanding in their lives.",
    strengths: [
      "Natural leadership in spiritual matters",
      "Strong ability to interpret spiritual signs",
      "Clear channel for divine wisdom",
      "Excellent spiritual counseling abilities"
    ]
  },
  "Empathic Nurturer": {
    description: "As an Empathic Nurturer, your greatest gift is your ability to deeply understand and connect with others' emotions. You create safe spaces for healing and growth through your natural compassion and understanding.",
    strengths: [
      "Profound emotional intelligence",
      "Natural nurturing abilities",
      "Strong empathic connections",
      "Ability to create healing spaces"
    ]
  },
  "Mindful Explorer": {
    description: "Being a Mindful Explorer, you approach spirituality through careful observation and conscious experience. Your balanced approach to spiritual growth combines rational thinking with intuitive understanding.",
    strengths: [
      "Balanced analytical and intuitive thinking",
      "Strong observational skills",
      "Deep mindfulness practice",
      "Practical spiritual wisdom"
    ]
  }
} as const;

type PersonalityType = keyof typeof PERSONALITY_INSIGHTS;

export default function PersonalityInsights() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedTab, setSelectedTab] = useState<string>("insights");
  const [showAuraReveal, setShowAuraReveal] = useState(false);

  // Fetch subscription status
  const { data: subscriptionData, isLoading: isLoadingSubscription } = useQuery({
    queryKey: ['/api/subscription/status'],
    queryFn: async () => {
      const response = await fetch('/api/subscription/status');
      if (!response.ok) throw new Error('Failed to fetch subscription status');
      return response.json();
    },
    enabled: !!user
  });

  const isPremium = subscriptionData?.status === 'active';

  useEffect(() => {
    if (!user?.quizResults || !user?.type) {
      toast({
        title: "Quiz Required",
        description: "Please complete the personality quiz to unlock your insights!",
        variant: "destructive",
      });
      setLocation("/quiz");
      return;
    }
  }, [user, toast, setLocation]);

  if (isLoadingSubscription) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <div className="max-w-4xl mx-auto">
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
            <CardHeader className="text-center">
              <h1 className="text-3xl font-bold text-primary mb-4">
                Unlock Your Full Spiritual Profile
              </h1>
              <p className="text-lg text-muted-foreground">
                Upgrade to Premium to access your complete personality insights, aura analysis, and compatibility guidance.
              </p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-primary mb-4">Premium Features</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center text-muted-foreground">
                          <span className="text-primary mr-2">✨</span>
                          Detailed Personality Analysis
                        </li>
                        <li className="flex items-center text-muted-foreground">
                          <span className="text-primary mr-2">✨</span>
                          Aura Color Reading
                        </li>
                        <li className="flex items-center text-muted-foreground">
                          <span className="text-primary mr-2">✨</span>
                          Compatibility Insights
                        </li>
                        <li className="flex items-center text-muted-foreground">
                          <span className="text-primary mr-2">✨</span>
                          Spiritual Practice Recommendations
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <div className="flex flex-col justify-center items-center space-y-4">
                    <p className="text-center text-muted-foreground">
                      Unlock all premium features and discover your true spiritual potential
                    </p>
                    <Button
                      className="w-full max-w-md bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90"
                      onClick={() => setLocation("/subscription")}
                    >
                      <SiStripe className="mr-2 h-5 w-5" />
                      Upgrade to Premium
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!user?.type || !(user.type in PERSONALITY_INSIGHTS)) {
    return null;
  }

  const insights = PERSONALITY_INSIGHTS[user.type as PersonalityType];
  const auraColor = calculateAuraColor(
    user.type as PersonalityType,
    user.metaphysicalScores,
    user.quizResults
  );
  const readableAuraColor = getReadableAuraColor(auraColor);

  const handleAuraClick = () => {
    setShowAuraReveal(true);
  };

  const getAuraDescription = (color: AuraColor): string => {
    const descriptions = {
      violet: "The most spiritual of colors, violet represents enhanced intuition, connection to divine wisdom, and natural healing abilities.",
      indigo: "Associated with deep intuition and spiritual teaching, indigo represents strong guidance abilities and deep inner knowing.",
      green: "The color of heart-centered healing, green represents strong healing abilities and a deep connection to nature.",
      blue: "Representing truth-seeking and clear communication, blue shows balanced logical and intuitive thinking.",
      gold: "A rare and powerful aura color that appears when someone has achieved high spiritual awareness across multiple dimensions."
    };
    return descriptions[color];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20 overflow-hidden">
            <CardContent className="p-6">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-primary mb-2">Your Spiritual Blueprint</h1>
                <p className="text-lg text-muted-foreground">
                  Discover the depths of your {user.type} personality
                </p>
                {readableAuraColor && (
                  <div
                    className="mt-4 p-4 rounded-lg bg-primary/5 border border-primary/10 cursor-pointer transform hover:scale-105 transition-transform"
                    onClick={handleAuraClick}
                  >
                    <p className="text-lg font-semibold text-primary">
                      Click to Reveal Your Aura Color
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Experience an interactive journey through the spectrum of spiritual energies
                    </p>
                  </div>
                )}
              </div>

              <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-8">
                  <TabsTrigger value="insights">Core Insights</TabsTrigger>
                  <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
                  <TabsTrigger value="practices">Spiritual Practices</TabsTrigger>
                </TabsList>

                <TabsContent value="insights">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-6">
                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Your Essence</h2>
                        <p className="text-muted-foreground">{insights.description}</p>
                      </div>

                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Core Strengths</h2>
                        <ul className="space-y-2">
                          {insights.strengths.map((strength: string, index: number) => (
                            <li key={index} className="flex items-center text-muted-foreground">
                              <span className="text-primary mr-2">✨</span>
                              {strength}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {user.metaphysicalScores && (
                        <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                          <h2 className="text-xl font-semibold text-primary mb-4">Spiritual Awareness</h2>
                          <div className="space-y-4">
                            <p className="text-muted-foreground">
                              Your spiritual awareness scores reflect your connection to different aspects of metaphysical understanding:
                            </p>
                            <ul className="space-y-2">
                              {Object.entries(user.metaphysicalScores).map(([key, value]) => (
                                <li key={key} className="flex items-center justify-between">
                                  <span className="text-muted-foreground">Question {key.split('_')[1]}</span>
                                  <span className="text-primary font-medium">{value}/10</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="compatibility">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-6">
                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Aura Compatibility</h2>
                        <p className="text-muted-foreground">
                          Your {readableAuraColor?.toLowerCase()} aura influences your compatibility with others.
                          {auraColor === 'gold'
                            ? " As a rare gold aura bearer, you have natural compatibility with all other aura types."
                            : " You'll find particularly strong connections with those who have complementary aura colors."}
                        </p>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="practices">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-6">
                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Recommended Practices</h2>
                        <p className="text-muted-foreground">
                          Based on your personality type and aura color, here are practices that can help enhance your spiritual growth:
                        </p>
                        <ul className="mt-4 space-y-2">
                          {user.type === "Mystic Healer" && (
                            <>
                              <li className="text-muted-foreground">• Regular energy healing practices</li>
                              <li className="text-muted-foreground">• Meditation focused on channeling healing energy</li>
                              <li className="text-muted-foreground">• Crystal work and chakra balancing</li>
                            </>
                          )}
                          {user.type === "Spiritual Guide" && (
                            <>
                              <li className="text-muted-foreground">• Daily meditation and contemplation</li>
                              <li className="text-muted-foreground">• Study of spiritual texts and teachings</li>
                              <li className="text-muted-foreground">• Leading or participating in spiritual circles</li>
                            </>
                          )}
                          {user.type === "Empathic Nurturer" && (
                            <>
                              <li className="text-muted-foreground">• Regular emotional cleansing rituals</li>
                              <li className="text-muted-foreground">• Nature connection practices</li>
                              <li className="text-muted-foreground">• Heart-centered meditation</li>
                            </>
                          )}
                          {user.type === "Mindful Explorer" && (
                            <>
                              <li className="text-muted-foreground">• Mindfulness meditation</li>
                              <li className="text-muted-foreground">• Analytical journaling</li>
                              <li className="text-muted-foreground">• Scientific study of spiritual phenomena</li>
                            </>
                          )}
                        </ul>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {auraColor && (
        <AuraRevealEffect
          finalAuraColor={auraColor}
          isOpen={showAuraReveal}
          onClose={() => setShowAuraReveal(false)}
        />
      )}
    </div>
  );
}