import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { format, parseISO } from "date-fns";
import axios from "axios";
import type { User } from "@shared/schema";
import { SparkVisualization } from "@/components/SparkVisualization";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

const EMOJIS = {
  '💗': 'pink heart',
  '❤️': 'red heart',
  '💔': 'broken heart',
  '⭕': 'do not circle'
};

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [personalityTypeFilter, setPersonalityTypeFilter] = useState<string>("all");
  const [genderFilter, setGenderFilter] = useState<string>("all");
  const [isAiMatchmaking, setIsAiMatchmaking] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Sort messages by timestamp to ensure newest are at bottom
  const sortedMessages = [...messages].sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  const handleEmojiSelect = (emoji: string) => {
    setNewMessage(prev => prev + emoji);
    setShowEmojiPicker(false);
  };

  const { data: matches = [] } = useQuery<Match[]>({
    queryKey: ['/api/matches'],
    enabled: !!user?.id
  });

  const { data: pending = [] } = useQuery<Match[]>({
    queryKey: ['/api/pending-matches'],
    enabled: !!user?.id
  });

  const { data: passes = [] } = useQuery<Match[]>({
    queryKey: ['/api/passes'],
    enabled: !!user?.id
  });

  const findAIMatch = async () => {
    setIsAiMatchmaking(true);
    try {
      const response = await axios.get(`/api/user/${user?.id}/quiz-results`);
      const hasQuizData = response.data?.quizResults && Object.keys(response.data.quizResults).length > 0;
      const hasMetaphysicalScores = response.data?.metaphysicalScores &&
        Object.keys(response.data.metaphysicalScores).length > 0;
      const hasType = response.data?.type && response.data.type.length > 0;

      if (hasQuizData || hasMetaphysicalScores || hasType) {
        setLocation("/ai-matchmaker");
      } else {
        toast({
          title: "Profile Update Needed",
          description: "Please complete your spiritual profile to access AI matches.",
          variant: "destructive",
        });
        setLocation("/quiz");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check profile data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAiMatchmaking(false);
    }
  };

  const filterResults = (items: Match[], type: 'matches' | 'pending' | 'passes') => {
    return items.filter((item, index, self) => {
      const isDuplicate = self.findIndex(m => m.id === item.id) !== index;
      if (isDuplicate) return false;

      if (personalityTypeFilter !== "all" && item.type !== personalityTypeFilter) {
        return false;
      }

      if (genderFilter !== "all") {
        const value = item.genderIdentityValue;
        const range = GENDER_IDENTITY_RANGES[genderFilter as keyof typeof GENDER_IDENTITY_RANGES];
        if (!range || value < range.min || value > range.max) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (type === 'matches') {
        const scoreA = a.compatibility || 0;
        const scoreB = b.compatibility || 0;
        return scoreB - scoreA;
      }
      return 0;
    });
  };

  useEffect(() => {
    if (selectedMatch) {
      const fetchMessages = async () => {
        try {
          const response = await axios.get<Message[]>(`/api/messages/${selectedMatch.id}`);
          setMessages(response.data);
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to load messages",
            variant: "destructive"
          });
        }
      };
      fetchMessages();
    }
  }, [selectedMatch]);

  useEffect(() => {
    if (!user) return;

    let retryCount = 0;
    const maxRetries = 3;
    const retryDelay = 2000; // 2 seconds
    let retryTimeout: NodeJS.Timeout;

    const connectWebSocket = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const newSocket = new WebSocket(wsUrl);

      newSocket.onopen = () => {
        console.log('WebSocket connected successfully');
        retryCount = 0; // Reset retry count on successful connection
      };

      newSocket.onmessage = (event) => {
        const data = JSON.parse(event.data);

        if (data.type === 'chat') {
          if (selectedMatch &&
            (data.senderId === selectedMatch.id || data.receiverId === selectedMatch.id)) {
            setMessages(prev => [...prev, data.message]);
          }
        } else if (data.type === 'date_invitation') {
          if (selectedMatch &&
            (data.senderId === selectedMatch.id || data.receiverId === selectedMatch.id)) {
            setMessages(prev => [...prev, {
              id: Date.now(),
              senderId: data.senderId,
              receiverId: data.receiverId,
              content: data.content,
              createdAt: new Date().toISOString(),
              dateNightId: data.dateNightId
            }]);
          }
        }
      };

      newSocket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

      newSocket.onclose = () => {
        console.log('WebSocket connection closed');

        // Attempt to reconnect if we haven't exceeded max retries
        if (retryCount < maxRetries) {
          retryCount++;
          console.log(`Attempting to reconnect (${retryCount}/${maxRetries})...`);
          retryTimeout = setTimeout(connectWebSocket, retryDelay);
        } else {
          toast({
            title: "Connection Error",
            description: "Failed to establish real-time connection. Please refresh the page.",
            variant: "destructive"
          });
        }
      };

      setSocket(newSocket);
    };

    connectWebSocket();

    // Cleanup function
    return () => {
      if (socket) {
        socket.close();
      }
      if (retryTimeout) {
        clearTimeout(retryTimeout);
      }
    };
  }, [user, selectedMatch]);


  const handleSendMessage = async () => {
    if (!selectedMatch || !newMessage.trim()) return;

    try {
      const response = await axios.post('/api/messages', {
        receiverId: selectedMatch.id,
        content: newMessage.trim()
      });

      setMessages(prev => [...prev, response.data]);
      setNewMessage('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-primary">Your Dating Dashboard</h1>
          <div className="flex items-center gap-4">
            <Button
              onClick={findAIMatch}
              disabled={isAiMatchmaking}
              className="bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90 transition-all duration-300"
            >
              {isAiMatchmaking ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Finding Matches...
                </>
              ) : (
                "✨ AI Matchmaker"
              )}
            </Button>
          </div>
        </div>

        <Card className="mb-8 backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left space-y-2">
                <h2 className="text-xl font-semibold text-primary">Virtual Hangout Space</h2>
                <p className="text-muted-foreground">
                  Meet your matches safely in our virtual space before sharing personal details.
                  Get to know each other's energy and vibe in Eureka's Hang Out! ✨
                </p>
                <p className="text-sm text-primary/80 italic">
                  "True connection begins with safe, meaningful interaction."
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90 transition-all duration-300"
                  size="lg"
                  onClick={() => window.open('https://www.spatial.io/s/EurekaPleaseVRs-Hangout-6743b7b7f55ce82a72052644?share=2375748144776782220', '_blank')}
                >
                  🌟 Enter Virtual Hangout
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setLocation('/datenightcalendar')}
                >
                  📅 View Date Calendar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Select
            value={personalityTypeFilter}
            onValueChange={(value) => setPersonalityTypeFilter(value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Filter by Personality Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {PERSONALITY_TYPES.map(type => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={genderFilter}
            onValueChange={(value) => setGenderFilter(value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Filter by Gender Identity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Identities</SelectItem>
              <SelectItem value="Masculine">Masculine</SelectItem>
              <SelectItem value="Androgynous">Androgynous</SelectItem>
              <SelectItem value="Feminine">Feminine</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="matches">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="matches">Matches ({filterResults(matches, 'matches').length})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({filterResults(pending, 'pending').length})</TabsTrigger>
            <TabsTrigger value="passes">Passes ({filterResults(passes, 'passes').length})</TabsTrigger>
          </TabsList>

          <TabsContent value="matches">
            <div className="text-center mb-6">
              <p className="text-lg text-primary/80 italic">
                "True beauty lies in the harmony of souls, where two spirits dance in perfect resonance."
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                These beautiful connections have blossomed from spiritual compatibility. We recommend meeting in
                our Virtual Hangout first - it's a safe and magical space to let your connection grow naturally! 🌟
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filterResults(matches, 'matches').map((match) => (
                <MatchCard key={match.id} match={match} setSelectedMatch={setSelectedMatch} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="pending">
            <div className="text-center mb-6">
              <p className="text-lg text-primary/80 italic">
                "The most beautiful connections often begin with patience. Your spiritual match may still be discovering their path to you."
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                These souls have caught a glimpse of your inner light. Give them time to fully recognize the spiritual connection.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filterResults(pending, 'pending').map((match) => (
                <MatchCard key={match.id} match={match} setSelectedMatch={setSelectedMatch} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="passes">
            <div className="text-center mb-6">
              <p className="text-lg text-primary/80 italic">
                "Every pass brings you closer to your destined connection. Trust in the journey of finding your perfect match."
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Sometimes the universe guides us to pass on certain connections to make way for the ones that truly resonate with our spirit.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filterResults(passes, 'passes').map((match) => (
                <MatchCard key={match.id} match={match} setSelectedMatch={setSelectedMatch} />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {selectedMatch && (
          <Card className="fixed inset-x-0 bottom-0 md:bottom-4 md:right-4 md:left-auto w-full md:w-96 h-[70vh] md:h-[500px] backdrop-blur-xl bg-background/60 border-primary/20 rounded-t-lg md:rounded-lg">
            <CardContent className="p-4 h-full flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <img
                    src={selectedMatch.image}
                    alt={selectedMatch.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-primary/20"
                  />
                  <div>
                    <h3 className="font-semibold text-primary">{selectedMatch.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {selectedMatch.type}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedMatch(null)}
                  className="hover:bg-primary/10"
                >
                  ✕
                </Button>
              </div>

              <ScrollArea className="flex-1 pr-4">
                <div className="space-y-4">
                  {sortedMessages.map(message => {
                    const isDateInvitation = message.content.includes('✨ Special Invitation ✨');

                    return (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className="flex flex-col gap-1 items-start" 
                      >
                        <div className="flex items-start gap-2 max-w-[80%]">
                          <img
                            src={message.senderId === user?.id ? (user?.image || '/default-avatar.png') : selectedMatch.image}
                            alt={message.senderId === user?.id ? 'You' : selectedMatch.name}
                            className="w-8 h-8 rounded-full object-cover border-2 border-primary/20"
                          />
                          <div
                            className={`px-4 py-2 rounded-2xl ${
                              isDateInvitation
                                ? 'bg-primary/10 border border-primary/20'
                                : 'bg-muted'
                            }`}
                          >
                            {message.content}
                            {isDateInvitation && message.senderId !== user?.id && message.dateNightId && (
                              <div className="mt-4 flex gap-2">
                                <Button
                                  variant="default"
                                  size="sm"
                                  className="bg-primary/90 hover:bg-primary"
                                  onClick={async () => {
                                    try {
                                      await axios.patch(`/api/date-nights/${message.dateNightId}`, {
                                        status: 'accepted'
                                      });
                                      toast({
                                        title: "Date Accepted!",
                                        description: "The date has been added to your calendar.",
                                      });
                                      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
                                    } catch (error) {
                                      toast({
                                        title: "Error",
                                        description: "Failed to accept date invitation",
                                        variant: "destructive"
                                      });
                                    }
                                  }}
                                >
                                  Accept ✨
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setLocation(`/datenightcalendar?date=${message.dateNightId}`);
                                  }}
                                >
                                  View Details
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        <span className="text-xs text-muted-foreground px-2">
                          {format(parseISO(message.createdAt), 'p')}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
              </ScrollArea>

              <div className="flex flex-col gap-2 mt-4 pt-2 border-t border-primary/20">
                {showEmojiPicker && (
                  <div className="flex gap-2 p-2 bg-background/80 rounded-lg">
                    {Object.entries(EMOJIS).map(([emoji, description]) => (
                      <button
                        key={emoji}
                        onClick={() => handleEmojiSelect(emoji)}
                        className="text-xl hover:scale-125 transition-transform"
                        title={description}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="text-lg"
                  >
                    😊
                  </Button>
                  <Input
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    onKeyDown={e => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    className="flex-1 bg-background/50"
                  />
                  <Button
                    onClick={handleSendMessage}
                    className="bg-primary hover:bg-primary/80"
                    disabled={!newMessage.trim()}
                  >
                    Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

interface Match extends User {
  compatibility?: number;
}

interface Message {
  id: number;
  senderId: number;
  receiverId: number;
  content: string;
  createdAt: string;
  dateNightId?: number;
}

const PERSONALITY_TYPES = [
  "Mystic Healer",
  "Mindful Explorer",
  "Spiritual Guide",
  "Empathic Nurturer"
] as const;

// Gender identity ranges based on slider value (0-10)
const GENDER_IDENTITY_RANGES = {
  Masculine: { min: 0, max: 5 },
  Androgynous: { min: 5, max: 6.7 },
  Feminine: { min: 6.7, max: 10 }
} as const;

function MatchCard({ match, setSelectedMatch }: { match: Match, setSelectedMatch: (match: Match) => void }) {
  const getGenderIdentityDisplay = (value: number) => {
    const femininePercentage = (value / 10) * 100;
    if (femininePercentage <= 50) {
      const masculinePercentage = Math.abs(100 - femininePercentage);
      return `${Math.round(masculinePercentage)}% Masculine`;
    } else if (femininePercentage >= 67) {
      return `${Math.round(femininePercentage)}% Feminine`;
    } else {
      return `${Math.round(femininePercentage)}% Feminine (Androgynous)`;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <img
              src={match.image}
              alt={match.name}
              className="w-24 h-24 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-primary/50"
            />
            <div className="text-center sm:text-left">
              <h3 className="text-lg font-semibold text-primary">{match.name}</h3>
              <p className="text-sm text-muted-foreground">{match.location}</p>
              <p className="text-sm text-muted-foreground">{match.age} years old</p>
              <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-2">
                <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                  {match.type}
                </span>
                {match.spiritualColor && (
                  <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary capitalize">
                    {match.spiritualColor} Aura
                  </span>
                )}
                <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                  {getGenderIdentityDisplay(match.genderIdentityValue)}
                </span>
              </div>
            </div>
          </div>
          <SparkVisualization
            compatibility={match.compatibility || 0.8}
          />
          <Button
            variant="secondary"
            className="w-full mt-4"
            onClick={() => setSelectedMatch(match)}
          >
            Open Chat
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}