import { useState, useEffect } from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { useAuth } from "@/hooks/use-auth";

// Use import.meta.env for Vite environment variables
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

function CheckoutForm() {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setLoading(true);
    setError("");

    try {
      const result = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/subscription/success`,
          payment_method_data: {
            billing_details: {
              email: user?.email,
              address: {
                country: 'US',
              },
            },
          },
        },
      });

      if (result.error) {
        setError(result.error.message || "Payment failed");
        toast({
          title: "Payment Failed",
          description: result.error.message || "Please try again",
          variant: "destructive",
        });
      } else {
        navigate('/subscription/success');
      }
    } catch (err) {
      setError("An unexpected error occurred");
      toast({
        title: "Error",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      {error && <div className="text-red-500 text-sm">{error}</div>}
      <Button 
        type="submit" 
        disabled={!stripe || loading}
        className="w-full"
      >
        {loading ? "Processing..." : "Subscribe Now"}
      </Button>
    </form>
  );
}

export default function Subscription() {
  const [clientSecret, setClientSecret] = useState("");
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    const initializePayment = async () => {
      try {
        const response = await fetch('/api/subscription/create-payment-intent', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (!response.ok) {
          const error = await response.json();
          if (error.code === 'AUTH_REQUIRED') {
            toast({
              title: "Session Expired",
              description: "Please log in again to continue.",
              variant: "destructive",
            });
            navigate('/auth');
            return;
          }
          throw new Error(error.message || 'Failed to create payment intent');
        }

        const { clientSecret } = await response.json();
        setClientSecret(clientSecret);
      } catch (error) {
        toast({
          title: "Payment Setup Failed",
          description: error instanceof Error ? error.message : "Failed to start subscription process. Please try again.",
          variant: "destructive",
        });
      }
    };

    initializePayment();
  }, [toast, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-md mx-auto space-y-6">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader className="text-center">
            <h1 className="text-2xl font-bold text-primary">Upgrade to Premium</h1>
            <p className="text-muted-foreground">
              Unlock exclusive features and enhanced matching
            </p>
          </CardHeader>
          <CardContent>
            {clientSecret ? (
              <Elements
                stripe={stripePromise}
                options={{
                  clientSecret,
                  appearance: {
                    theme: 'night',
                    variables: {
                      colorPrimary: '#ec4899',
                    },
                  },
                }}
              >
                <CheckoutForm />
              </Elements>
            ) : (
              <div className="text-center py-4">Loading payment form...</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

const MOBILE_APPEARANCE = {
  theme: 'stripe' as const,
  variables: {
    colorPrimary: '#0A2540',
    colorBackground: '#ffffff',
    colorText: '#1a1a1a',
    colorDanger: '#df1b41',
    borderRadius: '8px',
    spacingUnit: '8px',
    fontFamily: "'Inter', -apple-system, system-ui, sans-serif",
    fontSizeBase: '16px'
  },
  rules: {
    '.Tab': {
      borderRadius: '8px',
      padding: '10px'
    },
    '.Input': {
      borderRadius: '8px',
      padding: '12px',
      fontSize: '16px'
    },
    '.Label': {
      fontSize: '14px',
      fontWeight: '500'
    },
    '.Error': {
      fontSize: '14px',
      color: '#df1b41'
    },
    '.Tab--selected': {
      backgroundColor: '#0A2540',
      color: '#ffffff'
    },
    '.Input--invalid': {
      borderColor: '#df1b41'
    }
  }
};