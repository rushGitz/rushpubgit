import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card } from "@/components/ui/card";

export default function FAQ() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-white">Frequently Asked Questions</h1>

        <Card className="backdrop-blur-xl bg-background/60 border-primary/20 p-6">
          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="personality-types">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                What are the different personality types and what do they mean?
              </AccordionTrigger>
              <AccordionContent className="text-white/80 space-y-4">
                <p className="text-sm text-primary mb-2">
                  ⭐ Premium Feature: Detailed personality insights and compatibility analysis are available to premium members.
                </p>
                <div>
                  <h3 className="font-semibold mb-2">Mystic Healer</h3>
                  <p>Deeply intuitive and spiritually attuned individuals who have a natural ability to sense and channel healing energies. They often rely on their inner wisdom and spiritual practices to help others find balance and wholeness.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Spiritual Guide</h3>
                  <p>Natural mentors and wisdom keepers who help others navigate their spiritual journey. They excel at interpreting spiritual signs and symbols, offering guidance through life's challenges with a balanced perspective of both practical and mystical wisdom.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Empathic Nurturer</h3>
                  <p>Highly sensitive individuals who naturally tune into others' emotional needs. They create safe spaces for emotional healing and growth, offering compassionate support and understanding through deep emotional connections.</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Mindful Explorer</h3>
                  <p>Curious and grounded seekers who approach spirituality through observation and experience. They balance rational thinking with spiritual openness, often finding profound insights through mindful practice and conscious exploration.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="aura-colors">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                What do the different aura colors mean?
              </AccordionTrigger>
              <AccordionContent className="text-white/80 space-y-4">
                <p className="text-sm text-primary mb-2">
                  ⭐ Premium Feature: Detailed aura color analysis and insights are available to premium members.
                </p>
                <div>
                  <h3 className="font-semibold mb-2">Violet (Mystic Healers)</h3>
                  <p>The most spiritual of all colors, violet auras indicate a deep connection to universal wisdom and healing abilities. Common in Mystic Healers with high spiritual awareness scores, violet represents:
                  </p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Enhanced intuitive abilities</li>
                    <li>Strong connection to divine wisdom</li>
                    <li>Natural healing capabilities</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Indigo (Spiritual Guides)</h3>
                  <p>Associated with deep intuition and spiritual teaching, indigo auras are often seen in Spiritual Guides who score highly in wisdom sharing. This color represents:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Strong intuitive guidance</li>
                    <li>Ability to communicate spiritual truths</li>
                    <li>Deep inner knowing</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Green (Empathic Nurturers)</h3>
                  <p>The color of heart-centered healing and growth, green auras are common among Empathic Nurturers with high emotional intelligence scores. This color indicates:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Strong healing abilities</li>
                    <li>Deep connection to nature</li>
                    <li>Balance between giving and receiving</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Blue (Mindful Explorers)</h3>
                  <p>Representing truth-seeking and clear communication, blue auras are often seen in Mindful Explorers who score highly in analytical thinking. This color shows:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Clear spiritual communication</li>
                    <li>Balanced logical and intuitive thinking</li>
                    <li>Peaceful presence</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Gold (Balanced Alignment)</h3>
                  <p>A rare and powerful aura color that appears when someone has achieved high scores across multiple spiritual dimensions. Gold represents:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Spiritual mastery</li>
                    <li>Divine wisdom</li>
                    <li>Enlightened consciousness</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="aura-matching">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                How do aura colors affect compatibility?
              </AccordionTrigger>
              <AccordionContent className="text-white/80 space-y-4">
                <p>Aura colors play a significant role in spiritual compatibility. Here's how different combinations work:</p>
                <div className="space-y-2">
                  <div>
                    <h4 className="font-semibold">Complementary Colors</h4>
                    <p>Violet and Green auras often create powerful healing partnerships, while Blue and Indigo auras form strong teaching/learning relationships.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Similar Colors</h4>
                    <p>People with similar aura colors often share deep understanding and can amplify each other's natural abilities.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Gold Compatibility</h4>
                    <p>Those with gold auras tend to be highly compatible with all other aura colors, acting as spiritual bridges and facilitators of growth.</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="gender-identity">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                How does the gender identity slider work?
              </AccordionTrigger>
              <AccordionContent className="text-white/80">
                Our gender identity slider allows you to express your gender identity on a spectrum from masculine to feminine.
                The slider shows percentages to help you accurately represent your identity. For example, if you slide towards
                the masculine end, you'll see a percentage like "80% Masculine", while the middle range is marked as "Androgynous".
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="matching">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                How does the matching system work?
              </AccordionTrigger>
              <AccordionContent className="text-white/80">
                Our matching system uses a combination of factors including personality quiz results, metaphysical compatibility,
                aura colors, and gender identity preferences. We analyze these data points to find connections that resonate on both spiritual
                and personal levels. The higher the compatibility percentage, the more aligned you are with a potential match.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="premium">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                What features are included in Premium?
              </AccordionTrigger>
              <AccordionContent className="text-white/80">
                <div className="space-y-4">
                  <p>Premium members enjoy enhanced features including:</p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>
                      <span className="font-semibold">Detailed Aura Color Analysis:</span>
                      <ul className="list-disc pl-6 mt-1 text-sm">
                        <li>In-depth aura color readings</li>
                        <li>Personal energy field interpretations</li>
                        <li>Aura compatibility insights with matches</li>
                      </ul>
                    </li>
                    <li>
                      <span className="font-semibold">Advanced Personality Insights:</span>
                      <ul className="list-disc pl-6 mt-1 text-sm">
                        <li>Comprehensive personality type analysis</li>
                        <li>Spiritual growth recommendations</li>
                        <li>Detailed compatibility reports</li>
                      </ul>
                    </li>
                    <li>
                      <span className="font-semibold">Enhanced Matching Features:</span>
                      <ul className="list-disc pl-6 mt-1 text-sm">
                        <li>Priority in match suggestions</li>
                        <li>Advanced filtering options</li>
                        <li>Unlimited matches</li>
                      </ul>
                    </li>
                    <li>
                      <span className="font-semibold">Additional Benefits:</span>
                      <ul className="list-disc pl-6 mt-1 text-sm">
                        <li>See who has liked your profile</li>
                        <li>Access to exclusive spiritual compatibility metrics</li>
                        <li>Premium customer support</li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="privacy">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                How is my privacy protected?
              </AccordionTrigger>
              <AccordionContent className="text-white/80">
                We take your privacy seriously. Your personal information is encrypted and securely stored. You control
                what information is visible on your profile, and your location is only shown at a city level. Messages
                are private between matched users only.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="inactive">
              <AccordionTrigger className="text-lg font-medium text-white hover:text-primary">
                What happens to inactive profiles?
              </AccordionTrigger>
              <AccordionContent className="text-white/80">
                To maintain an active and engaged community, profiles that have been inactive for more than 30 days may
                be hidden from match suggestions. You can reactivate your profile at any time by logging in and updating
                your information.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>
      </div>
    </div>
  );
}