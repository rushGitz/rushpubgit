import { useState, useEffect, useCallback } from "react";
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { generateAvatar } from "@/lib/avatar-generator";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { type User } from "@shared/schema";
import { z } from "zod";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";
import debounce from "lodash/debounce";
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Slider } from "@/components/ui/slider";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const GENDER_IDENTITIES = ["Stud", "Femme"] as const;
const AURA_COLORS = ["red", "blue", "green", "purple", "gold", "silver"] as const;

const emailSchema = z.string().email("Please enter a valid email address");

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

// Updated appearance configuration with correct types
const MOBILE_APPEARANCE = {
  theme: 'stripe' as const,
  variables: {
    colorPrimary: '#0A2540',
    colorBackground: '#ffffff',
    colorText: '#1a1a1a',
    colorDanger: '#df1b41',
    borderRadius: '8px',
    spacingUnit: '8px',
    fontFamily: "'Inter', -apple-system, system-ui, sans-serif",
    fontSizeBase: '16px'
  },
  rules: {
    '.Tab': {
      borderRadius: '8px',
      padding: '10px'
    },
    '.Input': {
      borderRadius: '8px',
      padding: '12px',
      fontSize: '16px'
    },
    '.Label': {
      fontSize: '14px',
      fontWeight: '500'
    },
    '.Error': {
      fontSize: '14px',
      color: '#df1b41'
    },
    '.Tab--selected': {
      backgroundColor: '#0A2540',
      color: '#ffffff'
    },
    '.Input--invalid': {
      borderColor: '#df1b41'
    }
  }
};

function CheckoutForm({ clientSecret, onSuccess }: { clientSecret: string; onSuccess: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isMobile] = useState(() => {
    if (typeof window === 'undefined') return false;
    return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  });
  const [isApplePayAvailable, setIsApplePayAvailable] = useState(false);

  // Get user data for billing details
  const { data: userData } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  // Check if Apple Pay is available
  useEffect(() => {
    if (!stripe) return;

    const checkApplePayAvailability = async () => {
      const canMakePayment = await stripe.paymentRequest({
        country: 'US',
        currency: 'usd',
        total: {
          label: 'EurekasMatch Premium Subscription',
          amount: 999, // $9.99
        },
        requestPayerName: true,
        requestPayerEmail: true,
      }).canMakePayment();

      setIsApplePayAvailable(!!canMakePayment?.applePay);
    };

    checkApplePayAvailability();
  }, [stripe]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      setError("The payment system isn't ready yet. Please try again in a moment.");
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      // First validate the card details
      const { error: submitError } = await elements.submit();
      if (submitError) {
        setError(submitError.message || "Please check your card details and try again");
        setProcessing(false);
        return;
      }

      // Confirm the payment
      const { error: confirmError, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/subscription/success`,
          payment_method_data: {
            billing_details: {
              email: userData?.email,
              address: {
                country: 'US',
              },
            },
          },
        },
        redirect: 'if_required'
      });

      if (confirmError) {
        // Handle specific error types
        if (confirmError.type === 'card_error') {
          setError("Your card was declined. Please try a different card.");
        } else if (confirmError.type === 'validation_error') {
          setError("Please check your card information and try again.");
        } else {
          setError("We couldn't process your payment. Please try again.");
        }

        toast({
          title: "Payment Failed",
          description: "Your payment couldn't be processed. Please try again or use a different payment method.",
          variant: "destructive",
        });
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        onSuccess();
      }
    } catch (error) {
      console.error("Payment error:", error);
      setError("Something went wrong with the payment. Please try again.");

      toast({
        title: "Payment Error",
        description: "We encountered an unexpected error. Please try again or contact support if the issue persists.",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  if (!stripe || !elements) {
    return (
      <div className="flex items-center justify-center p-6">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
        <span className="ml-2">Setting up payment form...</span>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="space-y-4 p-4">
        <PaymentElement
          options={{
            layout: 'tabs',
            paymentMethodOrder: ['apple_pay', 'google_pay', 'card'],
            wallets: {
              applePay: 'auto',
              googlePay: 'auto'
            },
            defaultValues: {
              billingDetails: {
                email: userData?.email,
              }
            }
          }}
          className="w-full min-h-[250px]"
        />

        {error && (
          <div className="p-3 text-sm text-red-500 bg-red-50 rounded-md">
            {error}
          </div>
        )}

        <Button
          type="submit"
          disabled={!stripe || processing}
          className="w-full text-lg py-6 mt-4"
        >
          {processing ? (
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              Processing Payment...
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <span>Subscribe Now</span>
              <span className="text-sm font-normal">$9.99/month • Cancel anytime</span>
            </div>
          )}
        </Button>

        {isMobile && isApplePayAvailable && (
          <p className="text-xs text-muted-foreground text-center mt-2">
            Apple Pay available for faster checkout
          </p>
        )}

        <p className="text-xs text-muted-foreground text-center mt-2">
          Secure payment processing by Stripe
        </p>
      </div>
    </form>
  );
}

export default function Profile() {
  const [imageUrl, setImageUrl] = useState("");
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [genderIdentityValue, setGenderIdentityValue] = useState<number>(5);
  const [email, setEmail] = useState("");
  const [isValidEmail, setIsValidEmail] = useState<boolean | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [isEmailSaving, setIsEmailSaving] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [physicalAddress, setPhysicalAddress] = useState("");
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);


  const { data: userData } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  useEffect(() => {
    if (userData) {
      setName(userData.name || "");
      setLocation(userData.location || "");
      setImageUrl(userData.image || "");
      setGenderIdentityValue(userData.genderIdentityValue || 5);
      setEmail(userData.email || "");
      if (userData.email) {
        validateEmail(userData.email);
      }
      setPhoneNumber(userData.phoneNumber || "");
      setPhysicalAddress(userData.physicalAddress || "");
    }
  }, [userData]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: {
      image?: string;
      name?: string;
      location?: string;
      genderIdentityValue?: number;
      email?: string;
      phoneNumber?: string;
      physicalAddress?: string;
    }) => {
      const response = await apiRequest("PATCH", "/api/user/profile", data);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to update profile");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated.",
      });
    },
    onError: (error) => {
      console.error("Error updating profile:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const validateEmail = (email: string) => {
    try {
      emailSchema.parse(email);
      setIsValidEmail(true);
      setEmailError(null);
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        setIsValidEmail(false);
        setEmailError(error.errors[0].message);
      }
      return false;
    }
  };

  const debouncedSaveEmail = useCallback(
    debounce(async (newEmail: string) => {
      if (!validateEmail(newEmail)) return;

      setIsEmailSaving(true);
      try {
        await updateProfileMutation.mutateAsync({ email: newEmail });
        toast({
          title: "Email Updated",
          description: "Your email has been successfully saved.",
        });
      } catch (error) {
        // Error handling is managed by the mutation
      } finally {
        setIsEmailSaving(false);
      }
    }, 1000),
    []
  );

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = e.target.value;
    setEmail(newEmail);
    validateEmail(newEmail);
    if (newEmail !== userData?.email) {
      debouncedSaveEmail(newEmail);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const updates: Record<string, string | number> = {};

    if (imageUrl !== userData?.image) updates.image = imageUrl;
    if (name !== userData?.name) updates.name = name;
    if (location !== userData?.location) updates.location = location;
    if (genderIdentityValue !== userData?.genderIdentityValue) updates.genderIdentityValue = genderIdentityValue;
    if (email !== userData?.email) updates.email = email;
    if (phoneNumber !== userData?.phoneNumber) updates.phoneNumber = phoneNumber;
    if (physicalAddress !== userData?.physicalAddress) updates.physicalAddress = physicalAddress;

    if (Object.keys(updates).length > 0) {
      updateProfileMutation.mutate(updates);
    } else {
      toast({
        title: "No Changes",
        description: "No profile changes were detected.",
      });
    }
  };

  const handleGenerateAvatar = () => {
    const newAvatar = generateAvatar();
    setImageUrl(newAvatar);
  };

  // Update the subscription status query implementation
  const { data: subscriptionData, isError: subscriptionError } = useQuery({
    queryKey: ["/api/subscription/status"],
    retry: 3,
    staleTime: 1000 * 60, // 1 minute
    select: (data: { status: string; expiresAt: string | null }) => ({
      status: data.status,
      expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
    }),
    onError: (error) => {
      console.error("Subscription status error:", error);
      toast({
        title: "Error",
        description: "Failed to load subscription status. Please try again.",
        variant: "destructive",
      });
    }
  });

  const createSubscriptionMutation = useMutation({
    mutationFn: async (paymentMethodId: string) => {
      const response = await apiRequest("POST", "/api/subscription", { paymentMethodId });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription/status"] });
      window.location.href = data.url;
    },
    onError: (error) => {
      console.error("Error creating subscription:", error);
      toast({
        title: "Error",
        description: "Failed to process subscription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartSubscription = async () => {
    if (!userData?.email) {
      toast({
        title: "Profile Incomplete",
        description: "Please add an email address in the Contact Information section above.",
        variant: "destructive",
      });
      return;
    }

    try {
      setShowPaymentForm(false);

      const response = await fetch('/api/subscription/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.json();

        if (error.code === 'AUTH_REQUIRED') {
          toast({
            title: "Session Expired",
            description: "Please log in again to continue.",
            variant: "destructive",
          });
          navigate('/auth');
          return;
        }

        throw new Error(error.message || 'Failed to create payment intent');
      }

      const { clientSecret } = await response.json();
      if (!clientSecret) {
        throw new Error('No client secret received');
      }

      setClientSecret(clientSecret);
      setShowPaymentForm(true);
    } catch (error) {
      console.error("Error creating payment intent:", error);
      toast({
        title: "Payment Setup Failed",
        description: error instanceof Error ? error.message : "Failed to start subscription process. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = () => {
    setShowPaymentForm(false);
    setClientSecret(null);
    queryClient.invalidateQueries({ queryKey: ["/api/subscription/status"] });
    toast({
      title: "Welcome to Premium!",
      description: "Your subscription has been activated. Enjoy all the premium features!",
    });
  };

  const getGenderIdentityDisplay = (value: number) => {
    // Map the slider value (0-10) to percentage (0-100)
    const femininePercentage = (value / 10) * 100;

    if (femininePercentage <= 50) {
      // For masculine-leaning values, show masculine percentage
      const masculinePercentage = Math.abs(100 - femininePercentage);
      return `${Math.round(masculinePercentage)}% Masculine`;
    } else if (femininePercentage >= 67) {
      return `${Math.round(femininePercentage)}% Feminine`;
    } else {
      return `${Math.round(femininePercentage)}% Feminine (Androgynous)`;
    }
  };

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/user', {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Failed to delete account');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Account Deleted",
        description: "Your account has been successfully deleted. We're sorry to see you go!",
      });
      // Redirect to home page after successful deletion
      window.location.href = '/';
    },
    onError: (error) => {
      console.error('Error deleting account:', error);
      toast({
        title: "Error",
        description: "Failed to delete your account. Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h1 className="text-3xl font-bold text-center text-primary">Your Profile</h1>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-primary">Profile Picture</label>
                {imageUrl && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="relative w-32 h-32 mx-auto mt-4"
                  >
                    <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-full blur-md" />
                    <img
                      src={imageUrl}
                      alt="Profile Preview"
                      className="relative w-full h-full rounded-full object-cover border-2 border-primary/50"
                    />
                  </motion.div>
                )}
                <div className="flex justify-center mt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleGenerateAvatar}
                    className="bg-background/50 border-primary/20"
                  >
                    Generate New Avatar
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-primary">Basic Information</h2>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-primary">Name</Label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="bg-background/50 border-primary/20"
                  />
                  {userData?.name && (
                    <p className="text-xs text-muted-foreground">Current: {userData.name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-primary">Location</Label>
                  <Input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Your location"
                    className="bg-background/50 border-primary/20"
                  />
                  {userData?.location && (
                    <p className="text-xs text-muted-foreground">Current: {userData.location}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-primary">Gender Identity</Label>
                  <div className="space-y-3">
                    <Slider
                      value={[genderIdentityValue]}
                      onValueChange={([value]) => setGenderIdentityValue(value)}
                      max={10}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Masculine</span>
                      <span>Androgynous</span>
                      <span>Feminine</span>
                    </div>
                    <div className="text-sm text-muted-foreground text-center">
                      {getGenderIdentityDisplay(genderIdentityValue)}
                    </div>
                  </div>
                  {userData?.genderIdentityValue !== undefined && (
                    <p className="text-xs text-muted-foreground">
                      Current: {getGenderIdentityDisplay(userData.genderIdentityValue)}
                    </p>
                  )}
                </div>
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-primary">Contact Information</h2>
                <div className="space-y-2 relative">
                  <Label className="text-sm font-medium text-primary">Email Address</Label>
                  <div className="relative">
                    <Input
                      type="email"
                      value={email}
                      onChange={handleEmailChange}
                      placeholder="your.email@example.com"
                      className={`bg-background/50 border-primary/20 pr-10 ${
                        isValidEmail === false ? 'border-red-500' :
                          isValidEmail === true ? 'border-green-500' : ''
                      }`}
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      {isEmailSaving ? (
                        <Loader2 className="h-4 w-4 animate-spin text-primary" />
                      ) : isValidEmail === true ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : isValidEmail === false ? (
                        <XCircle className="h-4 w-4 text-red-500" />
                      ) : null}
                    </div>
                  </div>
                  {emailError && (
                    <p className="text-sm text-red-500 mt-1">{emailError}</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Recommended: Add your email to receive important notifications
                  </p>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-primary">Phone Number (Optional)</Label>
                  <Input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="Your phone number"
                    className="bg-background/50 border-primary/20"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-primary">Physical Address (Optional)</Label>
                  <Input
                    value={physicalAddress}
                    onChange={(e) => setPhysicalAddress(e.target.value)}
                    placeholder="Your address"
                    className="bg-background/50 border-primary/20"
                  />
                </div>
              </div>

              {userData?.spiritualColor && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-primary">Your Aura Color</label>
                  <div className="p-4 rounded-md bg-background/50 border border-primary/20">
                    <p className="text-sm text-primary capitalize">{userData.spiritualColor}</p>
                    <p className="text-xs text-muted-foreground mt-1">Set by your personality test results</p>
                  </div>
                </div>
              )}

              {userData?.type && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-primary">Personality Type</label>
                  <div className="p-4 rounded-md bg-background/50 border border-primary/20">
                    <p className="text-sm text-primary">{userData.type}</p>
                    <p className="text-xs text-muted-foreground mt-1">Based on your quiz results</p>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/80 transition-all duration-300"
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
                </Button>

                <Link href="/preferences">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full border-primary/20 hover:bg-primary/10"
                  >
                    Update Lifestyle Preferences
                  </Button>
                </Link>

                <Link href="/personality-compatibility">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full border-primary/20 hover:bg-primary/10 flex items-center gap-2"
                  >
                    <span>🔮</span>
                    View Personality Compatibility
                  </Button>
                </Link>
                <Link href="/personality-insights">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full border-primary/20 hover:bg-primary/10 flex items-center gap-2 mt-2"
                  >
                    <span>✨</span>
                    View Your Spiritual Blueprint
                  </Button>
                </Link>
              </div>
            </form>

            <Separator className="my-6" />

            <div className="space-y-4 p-6">
              <h2 className="text-xl font-semibold text-primary">Subscription Status</h2>

              {/* Update the subscription status display section */}
              <div className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-primary/20">
                <div>
                  <p className="text-sm font-medium text-primary">Current Plan</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge
                      variant={subscriptionData?.status === 'active' ? 'premium' : 'secondary'}
                      className="inline-flex items-center gap-1"
                    >
                      {subscriptionData?.status === 'active' ? (
                        <>
                          <span>⭐</span>
                          <span>Premium</span>
                        </>
                      ) : 'Free'}
                    </Badge>
                    {subscriptionData?.expiresAt && (
                      <span className="text-xs text-muted-foreground">
                        Expires: {new Date(subscriptionData.expiresAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>

                {/* Only show upgrade button for non-premium users */}
                {(!subscriptionData || subscriptionData.status !== 'active') && !showPaymentForm && (
                  <Button
                    onClick={handleStartSubscription}
                    className="bg-primary hover:bg-primary/80"
                  >
                    Upgrade to Premium
                  </Button>
                )}
              </div>

              {showPaymentForm && clientSecret && (
                <Card className="mt-4">
                  <CardHeader>
                    <h3 className="text-lg font-semibold">Complete Your Subscription</h3>
                    <div className="space-y-2">
                      <p className="text-2xl font-bold text-primary">$9.99/month</p>
                      <p className="text-sm text-muted-foreground">
                        Unlock all premium features with EurekasMatch Premium
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-primary/10">
                      <p className="text-sm">
                        By proceeding with this payment, you agree to:
                      </p>
                      <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                        <li>• Be charged $9.99 today</li>
                        <li>• Automatic monthly renewal at $9.99</li>
                        <li>• Cancel anytime through your profile settings</li>
                      </ul>
                    </div>
                    <Elements
                      stripe={stripePromise}
                      options={{
                        clientSecret,
                        appearance: MOBILE_APPEARANCE,
                        loader: 'auto',
                        fonts: [{
                          cssSrc: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap'
                        }]
                      }}
                    >
                      <CheckoutForm
                        clientSecret={clientSecret}
                        onSuccess={handlePaymentSuccess}
                      />
                    </Elements>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-primary">Premium Benefits</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✨ Advanced Matching Algorithm</li>
                  <li>🔍 Detailed Personality Insights</li>
                  <li>💫 Priority in Match Queue</li>
                  <li>🎯 Enhanced Filtering Options</li>
                </ul>
              </div>
            </div>
            <Separator className="my-6" />

            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-destructive">Danger Zone</h2>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    className="w-full"
                  >
                    Delete Account
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will permanently delete your account
                      and remove your data from our servers.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => deleteAccountMutation.mutate()}
                      className="bg-destructive hover:bg-destructive/90"
                    >
                      {deleteAccountMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        "Delete Account"
                      )}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <p className="text-sm text-muted-foreground text-center">
                Once you delete your account, there is no going back. Please be certain.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}