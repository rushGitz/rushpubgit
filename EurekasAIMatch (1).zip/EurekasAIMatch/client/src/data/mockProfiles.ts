export const UserProfiles = [
  {
    id: 1,
    name: "Alice",
    age: 24,
    bio: "Data scientist exploring patterns in life and love",
    image: "https://randomuser.me/api/portraits/women/1.jpg",
    type: "Mystic Healer",
  },
  {
    id: 2,
    name: "Bob",
    age: 26,
    bio: "Quant trader seeking meaningful connections",
    image: "https://randomuser.me/api/portraits/men/1.jpg",
    type: "Mindful Explorer",
  },
  {
    id: 3,
    name: "Charlie",
    age: 27,
    bio: "AI researcher with a spiritual side",
    image: "https://randomuser.me/api/portraits/men/2.jpg",
    type: "Spiritual Guide",
  },
  {
    id: 4,
    name: "Diana",
    age: 25,
    bio: "Math PhD student who loves puzzles",
    image: "https://randomuser.me/api/portraits/women/2.jpg",
    type: "Empathic Nurturer",
  }
];
