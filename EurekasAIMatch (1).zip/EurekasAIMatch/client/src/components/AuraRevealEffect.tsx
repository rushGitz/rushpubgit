/**
 * AuraRevealEffect Component
 * Created based on RaShaan Grant's aura visualization concept
 * A dynamic, interactive aura color reveal animation
 */

import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { type AuraColor } from "@/lib/auraCalculator";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

interface AuraRevealEffectProps {
  finalAuraColor: AuraColor;
  isOpen: boolean;
  onClose: () => void;
}

const TRANSITION_COLORS = ['violet', 'indigo', 'blue', 'green', 'gold'];

export function AuraRevealEffect({ finalAuraColor, isOpen, onClose }: AuraRevealEffectProps) {
  const [currentColorIndex, setCurrentColorIndex] = useState(0);
  const [showFinalAura, setShowFinalAura] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isOpen) {
      // Reset states when opening
      setCurrentColorIndex(0);
      setShowFinalAura(false);

      // Start color transition sequence
      const interval = setInterval(() => {
        setCurrentColorIndex(prev => {
          if (prev >= TRANSITION_COLORS.length - 1) {
            clearInterval(interval);
            setShowFinalAura(true);
            return prev;
          }
          return prev + 1;
        });
      }, 800); // Transition every 800ms

      // Animate rotation continuously
      const rotationInterval = setInterval(() => {
        setRotation(prev => (prev + 1) % 360);
      }, 50);

      return () => {
        clearInterval(interval);
        clearInterval(rotationInterval);
      };
    }
  }, [isOpen]);

  const handleBackToProfile = () => {
    onClose();
    setLocation("/profile");
  };

  const getColorStyle = (color: string) => {
    const colorMap = {
      'violet': 'rgba(139, 92, 246, 0.8)',
      'indigo': 'rgba(99, 102, 241, 0.8)',
      'blue': 'rgba(59, 130, 246, 0.8)',
      'green': 'rgba(34, 197, 94, 0.8)',
      'gold': 'rgba(234, 179, 8, 0.8)'
    };
    return colorMap[color as keyof typeof colorMap] || 'rgba(147, 51, 234, 0.8)';
  };

  const getCurrentGradient = () => {
    const baseColor = showFinalAura 
      ? getColorStyle(finalAuraColor)
      : getColorStyle(TRANSITION_COLORS[currentColorIndex]);

    return `
      radial-gradient(circle at center, 
        ${baseColor.replace('0.8', '0.9')} 0%, 
        ${baseColor.replace('0.8', '0.6')} 45%, 
        ${baseColor.replace('0.8', '0.3')} 70%,
        transparent 100%)
    `;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-lg"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="relative p-6"
            onClick={e => e.stopPropagation()}
          >
            {/* Main aura container */}
            <motion.div
              className="w-80 h-80 rounded-full relative flex items-center justify-center overflow-hidden"
              style={{
                background: getCurrentGradient(),
                boxShadow: `
                  0 0 60px 30px ${showFinalAura 
                    ? getColorStyle(finalAuraColor)
                    : getColorStyle(TRANSITION_COLORS[currentColorIndex])},
                  0 0 100px 60px ${showFinalAura
                    ? getColorStyle(finalAuraColor).replace('0.8', '0.4')
                    : getColorStyle(TRANSITION_COLORS[currentColorIndex]).replace('0.8', '0.4')},
                  0 0 140px 90px ${showFinalAura
                    ? getColorStyle(finalAuraColor).replace('0.8', '0.2')
                    : getColorStyle(TRANSITION_COLORS[currentColorIndex]).replace('0.8', '0.2')}
                `
              }}
              animate={{
                scale: [1, 1.05, 1],
                rotate: rotation,
              }}
              transition={{
                scale: {
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                },
                rotate: {
                  duration: 0.05,
                  ease: "linear"
                }
              }}
            >
              {/* Animated gradient overlays */}
              <motion.div
                className="absolute inset-0"
                style={{
                  background: `linear-gradient(${rotation}deg, 
                    transparent 0%,
                    ${getColorStyle(finalAuraColor).replace('0.8', '0.2')} 50%,
                    transparent 100%
                  )`,
                  filter: 'blur(20px)',
                }}
              />

              {/* Light reflection effect */}
              <div
                className="absolute inset-0"
                style={{
                  background: `
                    radial-gradient(circle at 30% 30%, 
                      rgba(255, 255, 255, 0.4) 0%,
                      transparent 60%
                    ),
                    radial-gradient(circle at 70% 70%, 
                      rgba(255, 255, 255, 0.3) 0%,
                      transparent 50%
                    )
                  `
                }}
              />

              {showFinalAura && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center text-white relative z-10"
                >
                  <h2 className="text-3xl font-bold mb-2 drop-shadow-lg">Your Aura</h2>
                  <p className="text-xl capitalize drop-shadow-lg mb-4">{finalAuraColor}</p>
                  <Button
                    variant="outline"
                    className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                    onClick={handleBackToProfile}
                  >
                    Back to Profile
                  </Button>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}