import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, Tooltip, Legend } from 'recharts';

interface KinkScores {
  riskTolerance?: number;
  explorationIndex?: number;
  powerPlayPreference?: number;
  publicPrivate?: number;
  edgePlayScale?: number;
  vanillaToExtreme?: number;
  consentAwareness?: number;
  sensoryThreshold?: number;
}

interface KinkRadarChartProps {
  scores: KinkScores;
}

export const KinkRadarChart = ({ scores }: KinkRadarChartProps) => {
  const data = [
    {
      subject: 'Risk Tolerance',
      value: scores.riskTolerance || 0,
      fullMark: 100,
    },
    {
      subject: 'Exploration',
      value: scores.explorationIndex || 0,
      fullMark: 10,
    },
    {
      subject: 'Power Dynamic',
      value: scores.powerPlayPreference || 0,
      fullMark: 100,
    },
    {
      subject: 'Privacy Level',
      value: scores.publicPrivate || 0,
      fullMark: 100,
    },
    {
      subject: 'Edge Play',
      value: scores.edgePlayScale || 0,
      fullMark: 100,
    },
    {
      subject: 'Experience',
      value: scores.vanillaToExtreme || 0,
      fullMark: 10,
    },
    {
      subject: 'Consent Focus',
      value: scores.consentAwareness || 0,
      fullMark: 100,
    },
    {
      subject: 'Sensory',
      value: scores.sensoryThreshold || 0,
      fullMark: 100,
    },
  ];

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid stroke="rgba(255,255,255,0.2)" />
          <PolarAngleAxis
            dataKey="subject"
            tick={{ fill: 'rgba(255,255,255,0.8)', fontSize: 12 }}
          />
          <Radar
            name="Kink Profile"
            dataKey="value"
            stroke="rgba(var(--primary-rgb), 0.8)"
            fill="rgba(var(--primary-rgb), 0.3)"
            fillOpacity={0.6}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(0,0,0,0.8)',
              border: '1px solid rgba(255,255,255,0.2)',
            }}
          />
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};
