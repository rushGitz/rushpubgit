import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, Tooltip, Legend } from 'recharts';

interface PoliticalScores {
  ideologicalSpectrum?: number;
  activismEngagement?: number;
  tacticsPreference?: number;
  publicVisibility?: number;
  riskOfExtremism?: number;
  echoChamberIndex?: number;
  financialCommitment?: number;
  mobilizationAbility?: number;
}

interface PoliticalRadarChartProps {
  scores: PoliticalScores;
}

export const PoliticalRadarChart = ({ scores }: PoliticalRadarChartProps) => {
  const data = [
    {
      subject: 'Ideological Spectrum',
      value: scores.ideologicalSpectrum || 0,
      fullMark: 100,
    },
    {
      subject: 'Activism Level',
      value: scores.activismEngagement || 0,
      fullMark: 10,
    },
    {
      subject: 'Tactics',
      value: scores.tacticsPreference || 0,
      fullMark: 100,
    },
    {
      subject: 'Public Visibility',
      value: scores.publicVisibility || 0,
      fullMark: 100,
    },
    {
      subject: 'Risk Assessment',
      value: scores.riskOfExtremism || 0,
      fullMark: 100,
    },
    {
      subject: 'Echo Chamber',
      value: scores.echoChamberIndex || 0,
      fullMark: 100,
    },
    {
      subject: 'Financial Support',
      value: scores.financialCommitment || 0,
      fullMark: 100,
    },
    {
      subject: 'Mobilization',
      value: scores.mobilizationAbility || 0,
      fullMark: 100,
    },
  ];

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid stroke="rgba(255,255,255,0.2)" />
          <PolarAngleAxis
            dataKey="subject"
            tick={{ fill: 'rgba(255,255,255,0.8)', fontSize: 12 }}
          />
          <Radar
            name="Political Profile"
            dataKey="value"
            stroke="rgba(var(--primary-rgb), 0.8)"
            fill="rgba(var(--primary-rgb), 0.3)"
            fillOpacity={0.6}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(0,0,0,0.8)',
              border: '1px solid rgba(255,255,255,0.2)',
            }}
          />
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};
