import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Loader2, Sparkles } from "lucide-react";

interface SubscriptionStatus {
  status: "active" | "inactive" | "canceled" | "expired";
  expiresAt: string | null;
}

export function withPremium<P extends object>(
  WrappedComponent: React.ComponentType<P>
) {
  return function WithPremiumComponent(props: P) {
    const { user } = useAuth();
    const [, navigate] = useLocation();

    const { data: subscriptionStatus, isLoading } = useQuery<SubscriptionStatus>({
      queryKey: ["/api/subscription/status"],
      enabled: !!user,
    });

    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (!subscriptionStatus?.status || subscriptionStatus.status !== "active") {
      return (
        <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center space-y-6">
              <div className="flex justify-center">
                <Sparkles className="h-12 w-12 text-primary" />
              </div>
              <h2 className="text-2xl font-bold text-primary">Premium Feature</h2>
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  Unlock advanced spiritual insights and enhanced compatibility analysis with our premium subscription:
                </p>
                <ul className="text-sm text-left space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✨</span>
                    <span>Detailed aura color analysis and energy field interpretations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">🔮</span>
                    <span>In-depth personality insights and spiritual growth guidance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">💫</span>
                    <span>Advanced compatibility matching and filtering</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">⭐</span>
                    <span>Priority in match queue and unlimited connections</span>
                  </li>
                </ul>
              </div>
              <Button onClick={() => navigate("/subscription")} className="w-full">
                Upgrade to Premium
              </Button>
              <p className="text-xs text-muted-foreground">
                Only $9.99/month • Cancel anytime
              </p>
            </CardContent>
          </Card>
        </div>
      );
    }

    return <WrappedComponent {...props} />;
  };
}