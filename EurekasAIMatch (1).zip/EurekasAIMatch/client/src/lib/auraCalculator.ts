type MetaphysicalScores = {
  question_4: number;
  question_5: number;
  question_6: number;
  question_7: number;
  question_8: number;
};

type PersonalityType = 'Mystic Healer' | 'Spiritual Guide' | 'Empathic Nurturer' | 'Mindful Explorer';

export type AuraColor = 'violet' | 'indigo' | 'green' | 'blue' | 'gold';

const PERSONALITY_BASE_COLORS: Record<PersonalityType, AuraColor> = {
  'Mystic Healer': 'violet',
  'Spiritual Guide': 'indigo',
  'Empathic Nurturer': 'green',
  'Mindful Explorer': 'blue'
};

export function calculateAuraColor(
  personalityType: PersonalityType | null,
  metaphysicalScores: MetaphysicalScores | null,
  quizResults: Record<string, number> | null
): AuraColor | null {
  if (!personalityType || !metaphysicalScores) {
    return null;
  }

  // Calculate average metaphysical score
  const scoreValues = Object.values(metaphysicalScores);
  const avgScore = scoreValues.reduce((a, b) => a + b, 0) / scoreValues.length;

  // Check for gold aura (high scores across the board)
  if (avgScore >= 8.5 && quizResults) {
    const quizScores = Object.values(quizResults);
    const hasMultipleHighScores = quizScores.filter(score => score >= 3).length >= 2;
    if (hasMultipleHighScores) {
      return 'gold';
    }
  }

  // Return base color based on personality type
  return PERSONALITY_BASE_COLORS[personalityType];
}

// Helper function to get readable aura color name
export function getReadableAuraColor(color: AuraColor | null): string | null {
  if (!color) return null;
  
  return color.charAt(0).toUpperCase() + color.slice(1);
}

// Calculate aura compatibility percentage
export function calculateAuraCompatibility(
  userAura: AuraColor | null,
  matchAura: AuraColor | null
): number {
  if (!userAura || !matchAura) return 0;

  // Gold auras are highly compatible with everyone
  if (userAura === 'gold' || matchAura === 'gold') return 1;

  // Complementary color pairs have high compatibility
  const complementaryPairs = [
    ['violet', 'green'],
    ['blue', 'indigo']
  ];

  const arePairComplementary = complementaryPairs.some(
    pair => pair.includes(userAura) && pair.includes(matchAura)
  );

  if (arePairComplementary) return 0.9;

  // Same colors have good compatibility
  if (userAura === matchAura) return 0.85;

  // Base compatibility for all other combinations
  return 0.7;
}
