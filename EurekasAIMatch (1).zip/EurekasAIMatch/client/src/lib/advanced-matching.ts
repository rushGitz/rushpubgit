import { type User } from "@shared/schema";

interface CompatibilityScore {
  score: number;
  reasons: string[];
}

export function calculateAdvancedCompatibility(user1: User, user2: User): CompatibilityScore {
  const score = {
    score: 0,
    reasons: [] as string[],
  };

  // Base personality type compatibility (40% weight)
  const typeCompatibility = getPersonalityTypeCompatibility(user1.type, user2.type);
  score.score += typeCompatibility.score * 0.4;
  score.reasons.push(typeCompatibility.reason);

  // Metaphysical scores alignment (30% weight)
  if (user1.metaphysicalScores && user2.metaphysicalScores) {
    const metaphysicalAlignment = calculateMetaphysicalAlignment(
      user1.metaphysicalScores,
      user2.metaphysicalScores
    );
    score.score += metaphysicalAlignment.score * 0.3;
    score.reasons.push(metaphysicalAlignment.reason);
  }

  // Spiritual color harmony (20% weight)
  if (user1.spiritualColor && user2.spiritualColor) {
    const colorHarmony = calculateColorHarmony(user1.spiritualColor, user2.spiritualColor);
    score.score += colorHarmony.score * 0.2;
    score.reasons.push(colorHarmony.reason);
  }

  // Optional: Political and value alignment (10% weight)
  if (user1.politicalScores && user2.politicalScores) {
    const politicalAlignment = calculateValueAlignment(user1.politicalScores, user2.politicalScores);
    score.score += politicalAlignment * 0.1;
  }

  return {
    score: Math.min(100, Math.round(score.score)),
    reasons: score.reasons.filter(Boolean),
  };
}

function getPersonalityTypeCompatibility(type1: string | null, type2: string | null): { score: number; reason: string } {
  const compatibilityMap = {
    "Mystic Healer": {
      "Mindful Explorer": { score: 85, reason: "Balanced partnership of intuition and analysis" },
      "Spiritual Guide": { score: 90, reason: "Deep spiritual connection and mutual growth" },
      "Empathic Nurturer": { score: 95, reason: "Powerful emotional and healing synergy" },
      "Mystic Healer": { score: 80, reason: "Strong spiritual connection but may need grounding" },
    },
    "Mindful Explorer": {
      "Mystic Healer": { score: 85, reason: "Complementary analytical and intuitive approaches" },
      "Spiritual Guide": { score: 88, reason: "Rich intellectual and spiritual exploration" },
      "Empathic Nurturer": { score: 82, reason: "Balance of logic and emotional depth" },
      "Mindful Explorer": { score: 75, reason: "Strong intellectual connection but may lack emotion" },
    },
    "Spiritual Guide": {
      "Mystic Healer": { score: 90, reason: "Profound spiritual understanding and guidance" },
      "Mindful Explorer": { score: 88, reason: "Dynamic spiritual and intellectual growth" },
      "Empathic Nurturer": { score: 88, reason: "Balanced spiritual and emotional support" },
      "Spiritual Guide": { score: 85, reason: "Deep wisdom sharing but may lack practicality" },
    },
    "Empathic Nurturer": {
      "Mystic Healer": { score: 95, reason: "Deep emotional and spiritual connection" },
      "Mindful Explorer": { score: 82, reason: "Complementary emotional and logical approach" },
      "Spiritual Guide": { score: 88, reason: "Nurturing spiritual growth together" },
      "Empathic Nurturer": { score: 85, reason: "Strong emotional bond but may need boundaries" },
    },
  };

  if (!type1 || !type2) return { score: 50, reason: "Basic compatibility" };

  return (
    compatibilityMap[type1 as keyof typeof compatibilityMap]?.[
      type2 as keyof (typeof compatibilityMap)[keyof typeof compatibilityMap]
    ] || { score: 50, reason: "Unknown compatibility" }
  );
}

function calculateMetaphysicalAlignment(scores1: Record<string, number>, scores2: Record<string, number>) {
  let totalDiff = 0;
  let count = 0;

  // Compare each metaphysical score
  for (const key in scores1) {
    if (scores2[key] !== undefined) {
      totalDiff += Math.abs(scores1[key] - scores2[key]);
      count++;
    }
  }

  if (count === 0) return { score: 50, reason: "Limited metaphysical data" };

  const avgDiff = totalDiff / count;
  const score = 100 - (avgDiff * 10); // Convert difference to 0-100 scale

  return {
    score: Math.max(0, Math.min(100, score)),
    reason: `${score > 75 ? "Strong" : score > 50 ? "Moderate" : "Basic"} metaphysical alignment`,
  };
}

function calculateColorHarmony(color1: string, color2: string) {
  const colorHarmonies = {
    "purple": { "gold": 95, "silver": 90, "white": 85, "blue": 80 },
    "gold": { "purple": 95, "white": 90, "green": 85, "silver": 80 },
    "silver": { "white": 95, "purple": 90, "blue": 85, "gold": 80 },
    "white": { "silver": 95, "gold": 90, "purple": 85, "green": 80 },
    "blue": { "purple": 90, "silver": 85, "white": 80, "green": 75 },
    "green": { "gold": 85, "white": 80, "blue": 75, "silver": 70 },
  };

  const harmonyScore = colorHarmonies[color1.toLowerCase() as keyof typeof colorHarmonies]?.[
    color2.toLowerCase() as keyof (typeof colorHarmonies)[keyof typeof colorHarmonies]
  ];

  return {
    score: harmonyScore || 50,
    reason: harmonyScore ? `${color1}-${color2} aura harmony` : "Basic color compatibility",
  };
}

function calculateValueAlignment(scores1: Record<string, number>, scores2: Record<string, number>): number {
  let totalDiff = 0;
  let count = 0;

  for (const key in scores1) {
    if (scores2[key] !== undefined) {
      totalDiff += Math.abs(scores1[key] - scores2[key]);
      count++;
    }
  }

  if (count === 0) return 50;

  const avgDiff = totalDiff / count;
  return Math.max(0, Math.min(100, 100 - (avgDiff * 10)));
}