import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { AuthProvider } from "@/hooks/use-auth";
import { NavBar } from "@/components/NavBar";
import NotFound from "@/pages/not-found";
import EurekasMatch from "@/pages/EurekasMatch";
import QuizVisual from "@/pages/QuizVisual";
import Dashboard from "@/pages/Dashboard";
import Profile from "@/pages/Profile";
import AuthPage from "@/pages/auth-page";
import AIMatchmaker from "@/pages/AIMatchmaker";
import PersonalityInsights from "@/pages/PersonalityInsights";
import PersonalityCompatibility from "@/pages/PersonalityCompatibility";
import ResetPassword from "@/pages/reset-password";
import Preferences from "@/pages/Preferences";
import DateNightCalendar from "@/pages/DateNightCalendar";
import FAQ from "@/pages/FAQ";
import Subscription from "@/pages/Subscription";
import { ProtectedRoute } from "@/lib/protected-route";
import { useEffect } from "react";

function WebSocketHandler() {
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'payment_failure') {
          toast({
            title: "Payment Failed",
            description: data.data.message,
            variant: "destructive",
            duration: 5000,
          });

          console.error("Payment failure details:", {
            code: data.data.code,
            paymentId: data.data.paymentId,
            message: data.data.message
          });
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    return () => {
      socket.close();
    };
  }, [toast]);

  return null;
}

function Router() {
  return (
    <div className="pt-16">
      <NavBar />
      <Switch>
        <ProtectedRoute path="/" component={EurekasMatch} />
        <ProtectedRoute path="/quiz" component={QuizVisual} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/profile" component={Profile} />
        <ProtectedRoute path="/preferences" component={Preferences} />
        <ProtectedRoute path="/ai-matchmaker" component={AIMatchmaker} />
        <ProtectedRoute path="/personality-insights" component={PersonalityInsights} />
        <ProtectedRoute path="/personality-compatibility" component={PersonalityCompatibility} />
        <ProtectedRoute path="/datenightcalendar" component={DateNightCalendar} />
        <ProtectedRoute path="/subscription" component={Subscription} />
        <Route path="/faq" component={FAQ} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/reset-password" component={ResetPassword} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <WebSocketHandler />
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;