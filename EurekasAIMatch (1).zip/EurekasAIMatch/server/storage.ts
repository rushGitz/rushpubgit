import { users, userSelections, chatMessages, userPreferences, notifications } from "@shared/schema";
import { type User, type InsertUser, type InsertUserSelection, type UserSelection } from "@shared/schema";
import { type ChatMessage, type InsertChatMessage } from "@shared/schema";
import { payments, premiumPreferences, type Payment, type InsertPayment } from "@shared/schema";
import { type PremiumPreferences, type InsertPremiumPreferences } from "@shared/schema";
import { type UserPreferences, type InsertUserPreferences } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, or, sql, gt, isNull } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";
import { dateNights, type DateNight, type InsertDateNight } from "@shared/schema";
import { type Notification, type InsertNotification } from "@shared/schema";
import { quizProgress, type QuizProgress, type InsertQuizProgress } from "@shared/schema"; // Import quizProgress schema

const MemoryStore = createMemoryStore(session);

// Password reset types
interface PasswordReset {
  token: string;
  userId: number;
  expiresAt: Date;
}

// In-memory storage for password reset tokens (in a production app, this would be in the database)
const passwordResets = new Map<string, PasswordReset>();

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getUnseenUsers(userId: number): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserType(id: number, type: string): Promise<User | undefined>;
  updateSpiritualColor(id: number, color: string): Promise<User | undefined>;
  updateUserProfile(id: number, profile: { image?: string; name?: string; location?: string; genderIdentity?: string; email?: string; phoneNumber?: string; physicalAddress?: string; }): Promise<User | undefined>;
  updateMetaphysicalScores(id: number, scores: Record<string, number>): Promise<User | undefined>;
  findCompatibleUsers(userId: number, threshold?: number): Promise<User[]>;
  recordUserSelection(selection: InsertUserSelection): Promise<UserSelection>;
  getMatches(userId: number): Promise<User[]>;
  getPasses(userId: number): Promise<User[]>;
  getMessages(userId1: number, userId2: number): Promise<ChatMessage[]>;
  createMessage(message: InsertChatMessage): Promise<ChatMessage>;
  sessionStore: session.Store;
  updateUserWithQuizResults(id: number, updates: {
    type?: string;
    metaphysicalScores?: Record<string, number>;
    quizResults?: Record<string, unknown>;
    quizTimestamp?: Date;
  }): Promise<User | undefined>;
  getPendingMatches(userId: number): Promise<User[]>;
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  upsertUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createPasswordReset(reset: PasswordReset): Promise<void>;
  getPasswordReset(token: string): Promise<PasswordReset | undefined>;
  updateUserPassword(userId: number, hashedPassword: string): Promise<void>;
  deletePasswordReset(token: string): Promise<void>;

  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayments(userId: number): Promise<Payment[]>;
  updateSubscriptionStatus(userId: number, status: string, expiresAt?: Date): Promise<User>;
  getPremiumPreferences(userId: number): Promise<PremiumPreferences | undefined>;
  upsertPremiumPreferences(preferences: InsertPremiumPreferences): Promise<PremiumPreferences>;
  updateStripeCustomerId(userId: number, stripeCustomerId: string): Promise<User>;

  // Add date night methods
  createDateNight(dateNight: InsertDateNight): Promise<DateNight>;
  getDateNights(userId: number): Promise<DateNight[]>;
  updateDateNightStatus(id: number, status: string): Promise<DateNight>;

  checkForMutualMatch(userId: number, targetUserId: number): Promise<boolean>;
  createMatch(matchData: { user1Id: number; user2Id: number; matchedAt: Date }): Promise<{ id: number }>;
  createPendingMatch(selection: { userId: number; targetUserId: number; createdAt: Date }): Promise<void>;
  createPass(selection: { userId: number; targetUserId: number; createdAt: Date }): Promise<void>;

  // Add notification methods
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUnreadNotificationCount(userId: number): Promise<number>;
  getUserNotifications(userId: number, limit?: number): Promise<Notification[]>;
  markNotificationAsRead(notificationId: number): Promise<Notification>;
  markAllNotificationsAsRead(userId: number): Promise<void>;
  updatePoliticalScores(id: number, scores: Record<string, number>): Promise<User | undefined>;
  updateKinkScores(id: number, scores: Record<string, number>): Promise<User | undefined>;

  // Add new methods for quiz progress
  saveQuizProgress(progress: InsertQuizProgress): Promise<QuizProgress>;
  getQuizProgress(userId: number): Promise<QuizProgress | undefined>;
  updateQuizProgress(id: number, progress: Partial<InsertQuizProgress>): Promise<QuizProgress>;

  // Add new methods for password reset
  storeResetToken(email: string, token: string, expiryDate: Date): Promise<void>;
  verifyResetToken(token: string): Promise<{ email: string } | null>;
  invalidateResetToken(token: string): Promise<void>;
  updateUserPassword(email: string, hashedPassword: string): Promise<void>;
  deleteUser(userId: number): Promise<void>;
  updateUserSubscriptionStatus: (userId: number, data: {
    status: string;
    subscriptionId: string;
    clientSecret: string;
  }) => Promise<void>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  // Password reset token storage (in-memory for development)
  private resetTokens = new Map<string, { email: string; expiryDate: Date }>();

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
      // Add secret key for session security
      secret: process.env.SESSION_SECRET || 'your-secret-key', // Replace with a strong secret key
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error('Error in getUser:', error);
      throw new Error('Database error in getUser');
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance.select().from(users).where(eq(users.username, username));
      return user;
    } catch (error) {
      console.error('Error in getUserByUsername:', error);
      throw new Error('Database error in getUserByUsername');
    }
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      return await dbInstance.select().from(users);
    } catch (error) {
      console.error('Error in getAllUsers:', error);
      throw new Error('Database error in getAllUsers');
    }
  }

  async getUnseenUsers(userId: number): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      const selections = await dbInstance.select().from(userSelections).where(eq(userSelections.userId, userId));
      const seenUserIds = new Set(selections.map(s => s.targetUserId));
      const allUsers = await this.getAllUsers();
      return allUsers.filter(user => !seenUserIds.has(user.id) && user.id !== userId);
    } catch (error) {
      console.error('Error in getUnseenUsers:', error);
      throw new Error('Database error in getUnseenUsers');
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance.insert(users).values(insertUser).returning();
      return user;
    } catch (error) {
      console.error('Error in createUser:', error);
      throw new Error('Database error in createUser');
    }
  }

  async updateUserType(id: number, type: string): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ type })
        .where(eq(users.id, id))
        .returning();
      return user;
    } catch (error) {
      console.error('Error in updateUserType:', error);
      throw new Error('Database error in updateUserType');
    }
  }

  async updateSpiritualColor(id: number, color: string): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ spiritualColor: color })
        .where(eq(users.id, id))
        .returning();
      return user;
    } catch (error) {
      console.error('Error in updateSpiritualColor:', error);
      throw new Error('Database error in updateSpiritualColor');
    }
  }

  async updateUserProfile(id: number, profile: { image?: string; name?: string; location?: string; genderIdentity?: string; email?: string; phoneNumber?: string; physicalAddress?: string; }): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const updateData = Object.fromEntries(
        Object.entries(profile).filter(([_, value]) => value !== undefined)
      );

      if (Object.keys(updateData).length === 0) {
        return await this.getUser(id);
      }

      const [user] = await dbInstance
        .update(users)
        .set(updateData)
        .where(eq(users.id, id))
        .returning();

      return user;
    } catch (error) {
      console.error('Error in updateUserProfile:', error);
      throw new Error('Database error in updateUserProfile');
    }
  }

  async updateMetaphysicalScores(id: number, scores: Record<string, number>): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ metaphysicalScores: JSON.stringify(scores) })
        .where(eq(users.id, id))
        .returning();
      return user;
    } catch (error) {
      console.error('Error updating metaphysical scores:', error);
      throw new Error('Database error in updateMetaphysicalScores');
    }
  }

  async recordUserSelection(selection: InsertUserSelection): Promise<UserSelection> {
    try {
      const dbInstance = await db.query();
      const [userSelection] = await dbInstance
        .insert(userSelections)
        .values({ ...selection, createdAt: new Date() })
        .returning();
      return userSelection;
    } catch (error) {
      console.error('Error in recordUserSelection:', error);
      throw new Error('Database error in recordUserSelection');
    }
  }

  async getMatches(userId: number): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      const userLikes = await dbInstance
        .select()
        .from(userSelections)
        .where(and(eq(userSelections.userId, userId), eq(userSelections.liked, true)));

      const user = await this.getUser(userId);
      if (!user) {
        console.log('No user found for id:', userId);
        return [];
      }

      // Safely parse user scores
      let userScores = {};
      try {
        userScores = typeof user.metaphysicalScores === 'string'
          ? JSON.parse(user.metaphysicalScores)
          : user.metaphysicalScores || {};
      } catch (e) {
        console.error('Error parsing user scores:', e);
      }

      // Use a Set to track processed user IDs and prevent duplicates
      const processedUserIds = new Set<number>();

      const mutualLikes = await Promise.all(
        userLikes.map(async (like) => {
          try {
            // Skip if we've already processed this user
            if (processedUserIds.has(like.targetUserId)) {
              return undefined;
            }

            const dbInstance2 = await db.query();
            const [hasLikedBack] = await dbInstance2
              .select()
              .from(userSelections)
              .where(
                and(
                  eq(userSelections.userId, like.targetUserId),
                  eq(userSelections.targetUserId, userId),
                  eq(userSelections.liked, true)
                )
              );

            if (hasLikedBack) {
              const matchUser = await this.getUser(like.targetUserId);
              if (matchUser) {
                // Add to processed set
                processedUserIds.add(matchUser.id);

                // Safely parse match scores
                let matchScores = {};
                try {
                  matchScores = typeof matchUser.metaphysicalScores === 'string'
                    ? JSON.parse(matchUser.metaphysicalScores)
                    : matchUser.metaphysicalScores || {};
                } catch (e) {
                  console.error('Error parsing match scores:', e);
                }

                // Calculate compatibility scores
                const metaphysicalSimilarity = this.calculateSimilarity(
                  userScores,
                  matchScores
                );

                const colorCompatibility = this.calculateColorCompatibility(
                  user.spiritualColor,
                  matchUser.spiritualColor
                );

                const personalityCompatibility = user.type === matchUser.type ? 1.0 : 0.6;

                const compatibility = (
                  metaphysicalSimilarity * 0.6 +
                  colorCompatibility * 0.2 +
                  personalityCompatibility * 0.2
                );

                return {
                  ...matchUser,
                  compatibility
                };
              }
            }
            return undefined;
          } catch (error) {
            console.error('Error processing match:', error);
            return undefined;
          }
        })
      );

      // Filter out undefined values and ensure unique matches
      const uniqueMatches = mutualLikes.filter((match): match is (User & { compatibility: number }) =>
        match !== undefined && typeof match.compatibility === 'number'
      );

      // Sort by compatibility score in descending order
      return uniqueMatches.sort((a, b) => b.compatibility - a.compatibility);
    } catch (error) {
      console.error('Error in getMatches:', error);
      throw new Error('Database error in getMatches');
    }
  }

  async getPasses(userId: number): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      const passes = await dbInstance
        .select()
        .from(userSelections)
        .where(and(eq(userSelections.userId, userId), eq(userSelections.liked, false)));

      const users = await Promise.all(
        passes.map(pass => this.getUser(pass.targetUserId))
      );

      return users.filter((user): user is User => user !== undefined);
    } catch (error) {
      console.error('Error in getPasses:', error);
      throw new Error('Database error in getPasses');
    }
  }

  async getMessages(userId1: number, userId2: number): Promise<ChatMessage[]> {
    try {
      const dbInstance = await db.query();
      return dbInstance
        .select()
        .from(chatMessages)
        .where(
          or(
            and(
              eq(chatMessages.senderId, userId1),
              eq(chatMessages.receiverId, userId2)
            ),
            and(
              eq(chatMessages.senderId, userId2),
              eq(chatMessages.receiverId, userId1)
            )
          )
        )
        .orderBy(desc(chatMessages.createdAt));
    } catch (error) {
      console.error('Error in getMessages:', error);
      throw new Error('Database error in getMessages');
    }
  }

  async createMessage(message: InsertChatMessage): Promise<ChatMessage> {
    try {
      const dbInstance = await db.query();
      const [newMessage] = await dbInstance
        .insert(chatMessages)
        .values({ ...message, createdAt: new Date() })
        .returning();
      return newMessage;
    } catch (error) {
      console.error('Error in createMessage:', error);
      throw new Error('Database error in createMessage');
    }
  }

  private calculateSimilarity(scores1: Record<string, number>, scores2: Record<string, number>): number {
    const questions = Object.keys(scores1);

    // Calculate normalized difference for each question
    const differences = questions.map(q => {
      const score1 = scores1[q] || 0;
      const score2 = scores2[q] || 0;
      // Calculate absolute difference and normalize to 0-1 range
      return 1 - Math.abs(score1 - score2) / 5; // Assuming scores are 1-5
    });

    // Average all differences
    return differences.reduce((sum, diff) => sum + diff, 0) / differences.length;
  }

  private calculateColorCompatibility(color1: string | undefined | null, color2: string | undefined | null): number {
    if (!color1 || !color2) return 0;

    // Color wheel compatibility matrix (values from 0 to 1)
    const colorMatrix: Record<string, Record<string, number>> = {
      'red': {
        'red': 0.7,
        'blue': 0.9,
        'green': 0.5,
        'purple': 0.8,
        'gold': 0.6,
        'silver': 0.7
      },
      'blue': {
        'red': 0.9,
        'blue': 0.7,
        'green': 0.8,
        'purple': 0.6,
        'gold': 0.8,
        'silver': 0.7
      },
      'green': {
        'red': 0.5,
        'blue': 0.8,
        'green': 0.7,
        'purple': 0.9,
        'gold': 0.7,
        'silver': 0.8
      },
      'purple': {
        'red': 0.8,
        'blue': 0.6,
        'green': 0.9,
        'purple': 0.7,
        'gold': 0.5,
        'silver': 0.9
      },
      'gold': {
        'red': 0.6,
        'blue': 0.8,
        'green': 0.7,
        'purple': 0.5,
        'gold': 0.7,
        'silver': 0.6
      },
      'silver': {
        'red': 0.7,
        'blue': 0.7,
        'green': 0.8,
        'purple': 0.9,
        'gold': 0.6,
        'silver': 0.8
      }
    };

    return colorMatrix[color1.toLowerCase()]?.[color2.toLowerCase()] || 0;
  }

  async findCompatibleUsers(userId: number, threshold = 0.7): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      const user = await this.getUser(userId);
      if (!user) return [];

      const allUsers = await this.getAllUsers();

      // Parse all scores
      const userMetaphysicalScores = user.metaphysicalScores ? JSON.parse(user.metaphysicalScores as string) : {};
      const userPoliticalScores = user.politicalScores ? JSON.parse(user.politicalScores as string) : {};
      const userKinkScores = user.kinkScores ? JSON.parse(user.kinkScores as string) : {};

      return allUsers.filter(otherUser => {
        if (otherUser.id === userId) return false;

        // Calculate metaphysical compatibility (existing)
        const otherMetaphysicalScores = otherUser.metaphysicalScores ? JSON.parse(otherUser.metaphysicalScores as string) : {};
        const metaphysicalSimilarity = this.calculateSimilarity(userMetaphysicalScores, otherMetaphysicalScores);

        // Calculate political compatibility (new)
        const otherPoliticalScores = otherUser.politicalScores ? JSON.parse(otherUser.politicalScores as string) : {};
        const politicalSimilarity = this.calculateSimilarity(userPoliticalScores, otherPoliticalScores);

        // Calculate kink compatibility (new)
        const otherKinkScores = otherUser.kinkScores ? JSON.parse(otherUser.kinkScores as string) : {};
        const kinkSimilarity = this.calculateSimilarity(userKinkScores, otherKinkScores);

        // Calculate weighted average (adjustable weights)
        const totalCompatibility = (
          metaphysicalSimilarity * 0.4 + // 40% weight for metaphysical
          politicalSimilarity * 0.3 + // 30% weight for political
          kinkSimilarity * 0.3 // 30% weight for kink
        );

        console.log('Match calculation:', {
          user1: user.id,
          user2: otherUser.id,
          metaphysicalSimilarity,
          politicalSimilarity,
          kinkSimilarity,
          totalCompatibility
        });

        return totalCompatibility >= threshold;
      });
    } catch (error) {
      console.error('Error in findCompatibleUsers:', error);
      throw new Error('Database error in findCompatibleUsers');
    }
  }

  async updateUserWithQuizResults(
    id: number,
    updates: {
      type?: string;
      metaphysicalScores?: Record<string, number>;
      quizResults?: Record<string, unknown>;
      quizTimestamp?: Date;
    }
  ): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const updateData: Partial<User> = {};

      if (updates.type) {
        updateData.type = updates.type;
      }

      if (updates.metaphysicalScores) {
        updateData.metaphysicalScores = JSON.stringify(updates.metaphysicalScores);
      }

      if (updates.quizResults) {
        updateData.quizResults = JSON.stringify(updates.quizResults);
      }

      if (updates.quizTimestamp) {
        updateData.quizTimestamp = updates.quizTimestamp;
      }

      const [updatedUser] = await dbInstance
        .update(users)
        .set(updateData)
        .where(eq(users.id, id))
        .returning();

      return updatedUser;
    } catch (error) {
      console.error('Error updating user quiz results:', error);
      throw new Error('Database error in updateUserWithQuizResults');
    }
  }
  async getPendingMatches(userId: number): Promise<User[]> {
    try {
      const dbInstance = await db.query();
      // Get users that the current user has liked
      const userLikes = await dbInstance
        .select()
        .from(userSelections)
        .where(and(eq(userSelections.userId, userId), eq(userSelections.liked, true)));

      const pendingMatches = await Promise.all(
        userLikes.map(async (like) => {
          const dbInstance2 = await db.query();
          // Check if the other user has NOT liked back
          const [hasLikedBack] = await dbInstance2
            .select()
            .from(userSelections)
            .where(
              and(
                eq(userSelections.userId, like.targetUserId),
                eq(userSelections.targetUserId, userId),
                eq(userSelections.liked, false)
              )
            );

          // If they haven't liked back, this is a pending match
          if (!hasLikedBack) {
            return this.getUser(like.targetUserId);
          }
          return undefined;
        })
      );

      return pendingMatches.filter((user): user is User => user !== undefined);
    } catch (error) {
      console.error('Error in getPendingMatches:', error);
      throw new Error('Database error in getPendingMatches');
    }
  }
  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    try {
      const dbInstance = await db.query();
      const [preferences] = await dbInstance
        .select()
        .from(userPreferences)
        .where(eq(userPreferences.userId, userId));
      return preferences;
    } catch (error) {
      console.error('Error in getUserPreferences:', error);
      throw new Error('Database error in getUserPreferences');
    }
  }

  async upsertUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    try {
      const dbInstance = await db.query();
      const [existing] = await dbInstance
        .select()
        .from(userPreferences)
        .where(eq(userPreferences.userId, preferences.userId));

      if (existing) {
        const [updated] = await dbInstance
          .update(userPreferences)
          .set({
            ...preferences,
            updatedAt: new Date()
          })
          .where(eq(userPreferences.userId, preferences.userId))
          .returning();
        return updated;
      }

      const [created] = await dbInstance
        .insert(userPreferences)
        .values({
          ...preferences,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      return created;
    } catch (error) {
      console.error('Error in upsertUserPreferences:', error);
      throw new Error('Database error in upsertUserPreferences');
    }
  }
  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .select()
        .from(users)
        .where(eq(users.email, email));
      return user;
    } catch (error) {
      console.error('Error in getUserByEmail:', error);
      throw new Error('Database error in getUserByEmail');
    }
  }

  async createPasswordReset(reset: PasswordReset): Promise<void> {
    passwordResets.set(reset.token, reset);
  }

  async getPasswordReset(token: string): Promise<PasswordReset | undefined> {
    return passwordResets.get(token);
  }

  async updateUserPassword(userId: number, hashedPassword: string): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance
        .update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, userId));
    } catch (error) {
      console.error('Error in updateUserPassword:', error);
      throw new Error('Database error in updateUserPassword');
    }
  }

  async deletePasswordReset(token: string): Promise<void> {
    passwordResets.delete(token);
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    try {
      const dbInstance = await db.query();
      const [newPayment] = await dbInstance
        .insert(payments)
        .values(payment)
        .returning();
      return newPayment;
    } catch (error) {
      console.error('Error in createPayment:', error);
      throw new Error('Database error in createPayment');
    }
  }

  async getPayments(userId: number): Promise<Payment[]> {
    try {
      const dbInstance = await db.query();
      return dbInstance
        .select()
        .from(payments)
        .where(eq(payments.userId, userId))
        .orderBy(desc(payments.createdAt));
    } catch (error) {
      console.error('Error in getPayments:', error);
      throw new Error('Database error in getPayments');
    }
  }

  async updateSubscriptionStatus(userId: number, status: string, expiresAt?: Date): Promise<User> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({
          subscriptionStatus: status,
          subscriptionExpiresAt: expiresAt,
        })
        .where(eq(users.id, userId))
        .returning();
      return user;
    } catch (error) {
      console.error('Error in updateSubscriptionStatus:', error);
      throw new Error('Database error in updateSubscriptionStatus');
    }
  }

  async getPremiumPreferences(userId: number): Promise<PremiumPreferences | undefined> {
    try {
      const dbInstance = await db.query();
      const [preferences] = await dbInstance
        .select()
        .from(premiumPreferences)
        .where(eq(premiumPreferences.userId, userId));
      return preferences;
    } catch (error) {
      console.error('Error in getPremiumPreferences:', error);
      throw new Error('Database error in getPremiumPreferences');
    }
  }

  async upsertPremiumPreferences(preferences: InsertPremiumPreferences): Promise<PremiumPreferences> {
    try {
      const dbInstance = await db.query();
      const [existing] = await dbInstance
        .select()
        .from(premiumPreferences)
        .where(eq(premiumPreferences.userId, preferences.userId));

      if (existing) {
        const [updated] = await dbInstance
          .update(premiumPreferences)
          .set({
            ...preferences,
            updatedAt: new Date()
          })
          .where(eq(premiumPreferences.userId, preferences.userId))
          .returning();
        return updated;
      }

      const [created] = await dbInstance
        .insert(premiumPreferences)
        .values({
          ...preferences,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      return created;
    } catch (error) {
      console.error('Error in upsertPremiumPreferences:', error);
      throw new Error('Database error in upsertPremiumPreferences');
    }
  }

  async updateStripeCustomerId(userId: number, stripeCustomerId: string): Promise<User> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ stripeCustomerId })
        .where(eq(users.id, userId))
        .returning();
      return user;
    } catch (error) {
      console.error('Error in updateStripeCustomerId:', error);
      throw new Error('Database error in updateStripeCustomerId');
    }
  }

  async createDateNight(dateNight: InsertDateNight): Promise<DateNight> {
    try {
      console.log("[DEBUG] Creating date night with data:", dateNight);
      const dbInstance = await db.query();
      const [newDateNight] = await dbInstance
        .insert(dateNights)
        .values({
          ...dateNight,
          status: "pending",
          calendarSyncStatus: dateNight.calendarProvider ? "pending" : "not_synced",
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return newDateNight;
    } catch (error) {
      console.error('Error in createDateNight:', error);
      throw new Error('Database error in createDateNight');
    }
  }

  async getDateNights(userId: number): Promise<DateNight[]> {
    try {
      const dbInstance = await db.query();
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      return dbInstance
        .select()
        .from(dateNights)
        .where(
          and(
            or(
              eq(dateNights.hostId, userId),
              eq(dateNights.guestId, userId)
            ),
            or(
              eq(dateNights.status, "pending"),
              eq(dateNights.status, "accepted")
            ),
            gt(dateNights.scheduledFor, thirtyDaysAgo)
          )
        )
        .orderBy(desc(dateNights.scheduledFor));
    } catch (error) {
      console.error('Error in getDateNights:', error);
      throw new Error('Database error in getDateNights');
    }
  }

  async updateDateNightStatus(id: number, status: string): Promise<DateNight> {
    try {
      const dbInstance = await db.query();
      const [dateNight] = await dbInstance
        .update(dateNights)
        .set({
          status,
          updatedAt: new Date()
        })
        .where(eq(dateNights.id, id))
        .returning();
      return dateNight;
    } catch (error) {
      console.error('Error in updateDateNightStatus:', error);
      throw new Error('Database error in updateDateNightStatus');
    }
  }

  async checkForMutualMatch(userId: number, targetUserId: number): Promise<boolean> {
    try {
      const dbInstance = await db.query();
      const [mutualLike] = await dbInstance
        .select()
        .from(userSelections)
        .where(
          and(
            eq(userSelections.userId, targetUserId),
            eq(userSelections.targetUserId, userId),
            eq(userSelections.liked, true)
          )
        );
      return !!mutualLike;
    } catch (error) {
      console.error('Error in checkForMutualMatch:', error);
      throw new Error('Database error in checkForMutualMatch');
    }
  }

  async createMatch(matchData: { user1Id: number; user2Id: number; matchedAt: Date }): Promise<{ id: number }> {
    try {
      const dbInstance = await db.query();

      // First insert the first user's selection
      await dbInstance
        .insert(userSelections)
        .values({
          userId: matchData.user1Id,
          targetUserId: matchData.user2Id,
          liked: true,
          createdAt: matchData.matchedAt
        })
        .onConflictDoNothing();

      // Then insert the second user's selection
      await dbInstance
        .insert(userSelections)
        .values({
          userId: matchData.user2Id,
          targetUserId: matchData.user1Id,
          liked: true,
          createdAt: matchData.matchedAt
        })
        .onConflictDoNothing();

      // Return a pseudo match object with timestamp as ID
      return { id: Date.now() };
    } catch (error) {
      console.error('Error in createMatch:', error);
      throw new Error('Database error in createMatch');
    }
  }

  async createPendingMatch(selection: { userId: number; targetUserId: number; createdAt: Date }): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance
        .insert(userSelections)
        .values({
          userId: selection.userId,
          targetUserId: selection.targetUserId,
          liked: true,
          createdAt: selection.createdAt
        })
        .onConflictDoNothing();
    } catch (error) {
      console.error('Error in createPendingMatch:', error);
      throw new Error('Database error in createPendingMatch');
    }
  }

  async createPass(selection: { userId: number; targetUserId: number; createdAt: Date }): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance
        .insert(userSelections)
        .values({
          userId: selection.userId,
          targetUserId: selection.targetUserId,
          liked: false,
          createdAt: selection.createdAt
        })
        .onConflictDoNothing();
    } catch (error) {
      console.error('Errorin createPass:', error);
      throw new Error('Database error in createPass');
    }
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    try {
      const dbInstance = await db.query();
      const [newNotification] = await dbInstance
        .insert(notifications)
        .values(notification)
        .returning();
      return newNotification;
    } catch (error) {
      console.error('Error in createNotification:', error);
      throw new Error('Database error in createNotification');
    }
  }

  async getUnreadNotificationCount(userId: number): Promise<number> {
    try {
      const dbInstance = await db.query();
      const result = await dbInstance
        .select({ count: sql<number>`count(*)` })
        .from(notifications)
        .where(
          and(
            eq(notifications.userId, userId),
            eq(notifications.read, false),
            or(
              isNull(notifications.expiresAt),
              gt(notifications.expiresAt, new Date())
            )
          )
        );
      return Number(result[0]?.count) || 0;
    } catch (error) {
      console.error('Error in getUnreadNotificationCount:', error);
      throw new Error('Database error in getUnreadNotificationCount');
    }
  }

  async getUserNotifications(userId: number, limit = 50): Promise<Notification[]> {
    try {
      const dbInstance = await db.query();
      return dbInstance
        .select()
        .from(notifications)
        .where(
          and(
            eq(notifications.userId, userId),
            or(
              isNull(notifications.expiresAt),
              gt(notifications.expiresAt, new Date())
            )
          )
        )
        .orderBy(desc(notifications.createdAt))
        .limit(limit);
    } catch (error) {
      console.error('Error in getUserNotifications:', error);
      throw new Error('Database error in getUserNotifications');
    }
  }

  async markNotificationAsRead(notificationId: number): Promise<Notification> {
    try {
      const dbInstance = await db.query();
      const [notification] = await dbInstance
        .update(notifications)
        .set({
          read: true,
          readAt: new Date(),
        })
        .where(eq(notifications.id, notificationId))
        .returning();
      return notification;
    } catch (error) {
      console.error('Error in markNotificationAsRead:', error);
      throw new Error('Database error in markNotificationAsRead');
    }
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance
        .update(notifications)
        .set({
          read: true,
          readAt: new Date(),
        })
        .where(eq(notifications.userId, userId));
    } catch (error) {
      console.error('Error in markAllNotificationsAsRead:', error);
      throw new Error('Database error in markAllNotificationsAsRead');
    }
  }
  async updatePoliticalScores(id: number, scores: Record<string, number>): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ politicalScores: JSON.stringify(scores) })
        .where(eq(users.id, id))
        .returning();
      return user;
    } catch (error) {
      console.error('Error updating political scores:', error);
      throw new Error('Database error in updatePoliticalScores');
    }
  }

  async updateKinkScores(id: number, scores: Record<string, number>): Promise<User | undefined> {
    try {
      const dbInstance = await db.query();
      const [user] = await dbInstance
        .update(users)
        .set({ kinkScores: JSON.stringify(scores) })
        .where(eq(users.id, id))
        .returning();
      return user;
    } catch (error) {
      console.error('Error updating kink scores:', error);
      throw new Error('Database error in updateKinkScores');
    }
  }
  async saveQuizProgress(progress: InsertQuizProgress): Promise<QuizProgress> {
    try {
      const dbInstance = await db.query();
      const [existing] = await dbInstance
        .select()
        .from(quizProgress)
        .where(eq(quizProgress.userId, progress.userId));

      if (existing) {
        const [updated] = await dbInstance
          .update(quizProgress)
          .set({
            ...progress,
            lastUpdated: new Date()
          })
          .where(eq(quizProgress.userId, progress.userId))
          .returning();
        return updated;
      }

      const [created] = await dbInstance
        .insert(quizProgress)
        .values({
          ...progress,
          lastUpdated: new Date()
        })
        .returning();
      return created;
    } catch (error) {
      console.error('Error in saveQuizProgress:', error);
      throw new Error('Database error in saveQuizProgress');
    }
  }

  async getQuizProgress(userId: number): Promise<QuizProgress | undefined> {
    try {
      const dbInstance = await db.query();
      const [progress] = await dbInstance
        .select()
        .from(quizProgress)
        .where(eq(quizProgress.userId, userId));
      return progress;
    } catch (error) {
      console.error('Error in getQuizProgress:', error);
      throw new Error('Database error in getQuizProgress');
    }
  }

  async updateQuizProgress(id: number, progress: Partial<InsertQuizProgress>): Promise<QuizProgress> {
    try {
      const dbInstance = await db.query();
      const [updated] = await dbInstance
        .update(quizProgress)
        .set({
          ...progress,
          lastUpdated: new Date()
        })
        .where(eq(quizProgress.id, id))
        .returning();
      return updated;
    } catch (error) {
      console.error('Error in updateQuizProgress:', error);
      throw new Error('Database error in updateQuizProgress');
    }
  }
  async storeResetToken(email: string, token: string, expiryDate: Date): Promise<void> {
    this.resetTokens.set(token, { email, expiryDate });
  }

  async verifyResetToken(token: string): Promise<{ email: string } | null> {
    const record = this.resetTokens.get(token);
    if (!record) return null;

    if (record.expiryDate < new Date()) {
      this.resetTokens.delete(token);
      return null;
    }

    return { email: record.email };
  }

  async invalidateResetToken(token: string): Promise<void> {
    this.resetTokens.delete(token);
  }

  async updateUserPassword(email: string, hashedPassword: string): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance
        .update(users)
        .set({ password: hashedPassword })
        .where(eq(users.email, email));
    } catch (error) {
      console.error('Error updating password:', error);
      throw new Error('Database error in updateUserPassword');
    }
  }
  async deleteUser(userId: number): Promise<void> {
    try {
      const dbInstance = await db.query();
      // First delete related records
      await dbInstance.delete(userSelections).where(or(
        eq(userSelections.userId, userId),
        eq(userSelections.targetUserId, userId)
      ));
      await dbInstance.delete(chatMessages).where(or(
        eq(chatMessages.senderId, userId),
        eq(chatMessages.receiverId, userId)
      ));
      await dbInstance.delete(notifications).where(eq(notifications.userId, userId));
      await dbInstance.delete(userPreferences).where(eq(userPreferences.userId, userId));
      await dbInstance.delete(premiumPreferences).where(eq(premiumPreferences.userId, userId));
      await dbInstance.delete(dateNights).where(or(
        eq(dateNights.hostId, userId),
        eq(dateNights.guestId, userId)
      ));
      await dbInstance.delete(quizProgress).where(eq(quizProgress.userId, userId));
      // Finally delete the user
      await dbInstance.delete(users).where(eq(users.id, userId));
    } catch (error) {
      console.error('Error in deleteUser:', error);
      throw new Error('Database error in deleteUser');
    }
  }
  async updateUserSubscriptionStatus(userId: number, data: {
    status: string;
    subscriptionId: string;
    clientSecret: string;
  }): Promise<void> {
    try {
      const dbInstance = await db.query();
      await dbInstance.update(users).set({ subscriptionStatus: data.status, subscriptionId: data.subscriptionId }).where(eq(users.id, userId));
    } catch (error) {
      console.error("Error updating user subscription status:", error);
      throw new Error("Database error in updateUserSubscriptionStatus");
    }
  }
}

export const storage = new DatabaseStorage();