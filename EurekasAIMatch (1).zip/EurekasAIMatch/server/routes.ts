import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { WebSocket, WebSocketServer } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import type { IncomingMessage } from "http";
import { insertUserPreferencesSchema } from "@shared/schema";
import type { RequestHandler } from 'express-session';
import { stripe, createSubscription, handleSubscriptionWebhook } from "./stripe";
import express from "express";
import { randomBytes } from "crypto";
import { hashPassword } from "./auth";

// Add environment check helper
const isProduction = process.env.NODE_ENV === 'production';

// Define schemas for quiz validation
const metaphysicalScoresSchema = z.record(z.string(), z.number());
const quizResultsSchema = z.record(z.string(), z.union([z.number(), z.string()]));

// Define session types
interface WebSocketWithSession extends WebSocket {
  userId?: number;
}

interface SessionWithPassport extends IncomingMessage {
  session?: {
    passport?: {
      user?: number;
    };
  };
}

export function registerRoutes(app: Express, sessionMiddleware: RequestHandler): Server {
  const httpServer = createServer(app);

  // Set up WebSocket server with specific path and session handling
  const wss = new WebSocketServer({
    noServer: true
  });

  // Store active connections with their user IDs
  const connectedClients = new Map<number, WebSocketWithSession>();

  // Handle upgrade manually
  httpServer.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url!, `http://${request.headers.host}`).pathname;

    if (pathname === '/ws') {
      // Apply session middleware
      sessionMiddleware(request as Request, {} as any, () => {
        const req = request as unknown as SessionWithPassport;

        if (!req.session?.passport?.user) {
          socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
          socket.destroy();
          return;
        }

        wss.handleUpgrade(request, socket, head, (ws) => {
          const userId = req.session?.passport?.user;
          (ws as WebSocketWithSession).userId = userId;
          connectedClients.set(userId, ws as WebSocketWithSession);

          ws.on('close', () => {
            connectedClients.delete(userId);
          });

          wss.emit('connection', ws, request);
        });
      });
    }
  });

  // Set up auth routes first
  setupAuth(app);

  // Password reset endpoints
  app.post("/api/request-reset", async (req, res) => {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({
          message: "Email is required",
          code: "EMAIL_REQUIRED"
        });
      }

      // Generate a reset token
      const resetToken = randomBytes(32).toString('hex');
      const tokenExpiry = new Date(Date.now() + 3600000); // 1 hour expiry

      // Store the reset token in the database
      await storage.storeResetToken(email, resetToken, tokenExpiry);

      // In a real application, you would send an email here
      // For now, we'll return the token directly (only in development)
      if (process.env.NODE_ENV === 'production') {
        res.json({
          message: "If an account exists with that email, you will receive password reset instructions."
        });
      } else {
        res.json({
          message: "Reset token generated. In production, this would be emailed.",
          token: resetToken // Only included in development
        });
      }
    } catch (error) {
      console.error('Error in password reset request:', error);
      res.status(500).json({
        message: "Failed to process reset request",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "RESET_REQUEST_FAILED"
      });
    }
  });

  app.post("/api/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;

      if (!token || !newPassword) {
        return res.status(400).json({
          message: "Token and new password are required",
          code: "MISSING_FIELDS"
        });
      }

      // Verify token and get associated email
      const resetRecord = await storage.verifyResetToken(token);

      if (!resetRecord) {
        return res.status(400).json({
          message: "Invalid or expired reset token",
          code: "INVALID_TOKEN"
        });
      }

      // Hash the new password
      const hashedPassword = await hashPassword(newPassword);

      // Update the user's password
      await storage.updateUserPassword(resetRecord.email, hashedPassword);

      // Invalidate the used token
      await storage.invalidateResetToken(token);

      res.json({
        message: "Password has been successfully reset. Please log in with your new password."
      });
    } catch (error) {
      console.error('Error in password reset:', error);
      res.status(500).json({
        message: "Failed to reset password",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "RESET_FAILED"
      });
    }
  });

  // Rest of your routes...
  app.get('/api/matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const matches = await storage.getMatches(req.user.id);
    res.json(matches);
  });

  app.get('/api/pending-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    try {
      const pendingMatches = await storage.getPendingMatches(req.user.id);
      const matches = await storage.getMatches(req.user.id);

      const matchedIds = new Set(matches.map(m => m.id));
      const seenTargetUsers = new Set();

      const filteredPending = pendingMatches.filter(p => {
        if (matchedIds.has(p.id) || seenTargetUsers.has(p.id)) {
          return false;
        }
        seenTargetUsers.add(p.id);
        return true;
      });

      res.json(filteredPending);
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch pending matches",
        details: !isProduction ? (error instanceof Error ? error.message : "Unknown error") : undefined,
        code: "PENDING_MATCH_ERROR"
      });
    }
  });

  app.get('/api/passes', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const passes = await storage.getPasses(req.user.id);
    res.json(passes);
  });

  app.get('/api/messages/:userId', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const otherUserId = parseInt(req.params.userId);
    const messages = await storage.getMessages(req.user.id, otherUserId);
    res.json(messages);
  });

  app.post('/api/messages', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { receiverId, content } = req.body;

    const message = await storage.createMessage({
      senderId: req.user.id,
      receiverId,
      content
    });

    // Send message only to the sender and receiver
    const receiverWs = connectedClients.get(receiverId);
    const senderWs = connectedClients.get(req.user.id);

    const messageData = JSON.stringify({
      type: 'chat',
      senderId: req.user.id,
      receiverId,
      message
    });

    // Send to receiver if they're connected
    if (receiverWs?.readyState === WebSocket.OPEN) {
      receiverWs.send(messageData);
    }

    // Send to sender to confirm delivery
    if (senderWs?.readyState === WebSocket.OPEN) {
      senderWs.send(messageData);
    }

    res.json(message);
  });

  app.patch('/api/user/quiz', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to save quiz results",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { type, metaphysicalScores, quizResults } = req.body;

      // Validate required fields
      if (!type || !metaphysicalScores || !quizResults) {
        return res.status(400).json({
          message: "Missing required quiz data",
          code: "INVALID_QUIZ_DATA"
        });
      }

      // Validate metaphysical scores
      const parsedScores = metaphysicalScoresSchema.safeParse(metaphysicalScores);
      if (!parsedScores.success) {
        return res.status(400).json({
          message: "Invalid metaphysical scores format",
          details: parsedScores.error.errors,
          code: "INVALID_SCORES"
        });
      }

      // Validate quiz results
      const parsedResults = quizResultsSchema.safeParse(quizResults);
      if (!parsedResults.success) {
        return res.status(400).json({
          message: "Invalid quiz results format",
          details: parsedResults.error.errors,
          code: "INVALID_RESULTS"
        });
      }

      // Update user with quiz results
      const updatedUser = await storage.updateUserWithQuizResults(req.user.id, {
        type,
        metaphysicalScores: parsedScores.data,
        quizResults: parsedResults.data,
        quizTimestamp: new Date()
      });

      if (!updatedUser) {
        return res.status(404).json({
          message: "User not found or update failed",
          code: "UPDATE_FAILED"
        });
      }

      // Return the updated user without sensitive information
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user quiz results:', error);
      res.status(500).json({
        message: "Failed to update quiz results",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "SERVER_ERROR"
      });
    }
  });

  app.get('/api/user', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove sensitive information before sending
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });

  app.get('/api/user/:id/quiz-results', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to access quiz results",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const user = await storage.getUser(parseInt(req.params.id));

      if (!user) {
        return res.status(404).json({
          message: "User not found",
          code: "USER_NOT_FOUND"
        });
      }

      // Return only the quiz-related data
      const quizData = {
        type: user.type,
        quizResults: user.quizResults,
        metaphysicalScores: user.metaphysicalScores,
        quizTimestamp: user.quizTimestamp
      };

      res.json(quizData);
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch quiz results",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "FETCH_ERROR"
      });
    }
  });

  app.get('/api/compatible-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const threshold = req.query.threshold ? parseFloat(req.query.threshold as string) : 0.7;
      const compatibleUsers = await storage.findCompatibleUsers(req.user.id, threshold);
      res.json(compatibleUsers);
    } catch (error) {
      console.error('Error finding compatible matches:', error);
      res.status(500).json({ message: "Failed to find compatible matches" });
    }
  });

  app.get('/api/users', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const unseenUsers = await storage.getUnseenUsers(req.user.id);
    res.json(unseenUsers);
  });

  app.post('/api/match', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { targetUserId, action } = req.body;

    try {
      // Validate input
      if (!targetUserId || !action) {
        return res.status(400).json({
          message: "Missing required fields",
          code: "INVALID_INPUT"
        });
      }

      // Record the user's selection
      await storage.recordUserSelection({
        userId: req.user.id,
        targetUserId,
        liked: action === 'right'
      });

      if (action === 'right') {
        // Check for mutual match
        const hasMatch = await storage.checkForMutualMatch(req.user.id, targetUserId);

        if (hasMatch) {
          // Create a match record
          const match = await storage.createMatch({
            user1Id: req.user.id,
            user2Id: targetUserId,
            matchedAt: new Date()
          });

          // Get matched user details
          const matchedUser = await storage.getUser(targetUserId);
          if (!matchedUser) {
            throw new Error('Matched user not found');
          }

          // Notify both users via WebSocket
          const matchNotification = JSON.stringify({
            type: 'match',
            match: {
              id: matchedUser.id,
              name: matchedUser.name,
              image: matchedUser.image,
              location: matchedUser.location
            }
          });

          // Send to both users if connected
          const receiverWs = connectedClients.get(targetUserId);
          const senderWs = connectedClients.get(req.user.id);

          if (receiverWs?.readyState === WebSocket.OPEN) {
            receiverWs.send(matchNotification);
          }

          if (senderWs?.readyState === WebSocket.OPEN) {
            senderWs.send(matchNotification);
          }

          return res.json({ match: matchedUser });
        } else {
          // Create pending match
          await storage.createPendingMatch({
            userId: req.user.id,
            targetUserId,
            createdAt: new Date()
          });
          return res.json({ match: null });
        }
      } else {
        // Record pass
        await storage.createPass({
          userId: req.user.id,
          targetUserId,
          createdAt: new Date()
        });
        return res.json({ match: null });
      }
    } catch (error) {
      console.error('Error in match processing:', error);
      res.status(500).json({
        message: "Failed to process match action",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "MATCH_ERROR"
      });
    }
  });

  app.post('/api/super-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { quizResults } = req.body;

    try {
      // Get all unseen users
      const unseenUsers = await storage.getUnseenUsers(req.user.id);

      // Find best matches for each gender identity
      const studMatches = unseenUsers
        .filter(u => u.gender_identity === 'Stud')
        .map(user => {
          const userResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          if (!userResults || !quizResults) return null;

          // Calculate compatibility score
          const compatibilityScore = Object.entries(quizResults).reduce((score, [key, value]) => {
            return score + (userResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(quizResults).length;

          return { ...user, compatibility: compatibilityScore };
        })
        .filter(match => match !== null)
        .sort((a, b) => (b?.compatibility ?? 0) - (a?.compatibility ?? 0));

      const femmeMatches = unseenUsers
        .filter(u => u.gender_identity === 'Femme')
        .map(user => {
          const userResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          if (!userResults || !quizResults) return null;

          const compatibilityScore = Object.entries(quizResults).reduce((score, [key, value]) => {
            return score + (userResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(quizResults).length;

          return { ...user, compatibility: compatibilityScore };
        })
        .filter(match => match !== null)
        .sort((a, b) => (b?.compatibility ?? 0) - (a?.compatibility ?? 0));

      // Get the top match from each category
      const matches = [
        studMatches[0],
        femmeMatches[0]
      ].filter(match => match !== undefined);

      res.json({ matches });
    } catch (error) {
      console.error('Error finding super matches:', error);
      res.status(500).json({ message: "Failed to find super matches" });
    }
  });

  app.post('/api/ai-match', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { quizResults } = req.body;

    try {
      if (!quizResults) {
        return res.status(400).json({
          message: "Quiz results are required",
          code: "MISSING_QUIZ_RESULTS"
        });
      }

      // Get only unseen users for AI matching
      const unseenUsers = await storage.getUnseenUsers(req.user.id);

      const compatibleUsers = unseenUsers.filter(user => {
        try {
          // Handle both string and object quiz results
          const userQuizResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          const currentUserResults = typeof quizResults === 'string'
            ? JSON.parse(quizResults)
            : quizResults;

          if (!userQuizResults || !currentUserResults) {
            return false;
          }

          // Calculate compatibility score
          const compatibilityScore = Object.entries(currentUserResults).reduce((score, [key, value]) => {
            return score + (userQuizResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(currentUserResults).length;

          // Consider users with at least 30% compatibility
          return compatibilityScore >= 0.3;
        } catch (error) {
          return false;
        }
      });

      if (compatibleUsers.length > 0) {
        // Select a random match from the compatible users
        const match = compatibleUsers[Math.floor(Math.random() * compatibleUsers.length)];
        res.json({ match });
      } else {
        res.json({
          match: null,
          message: "No compatible matches found at this time. Try again later!"
        });
      }
    } catch (error) {
      console.error('Error in AI matching:', error);
      res.status(500).json({
        message: "Failed to process AI matching",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "AI_MATCH_ERROR"
      });
    }
  });



  app.patch('/api/user/profile', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const { image, name, location, genderIdentity, email, phoneNumber, physicalAddress } = req.body;

      // Update user's profile information
      const updatedUser = await storage.updateUserProfile(req.user.id, {
        image,
        name,
        location,
        gender_identity: genderIdentity, // Map to correct field name
        email,
        phoneNumber,
        physicalAddress
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Notify connected clients about the user update
      const clients = Array.from(wss.clients) as WebSocket[];
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'user_update',
            userId: req.user?.id,
            update: { image, name, location, genderIdentity, email, phoneNumber, physicalAddress }
          }));
        }
      });

      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get('/api/preferences', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const preferences = await storage.getUserPreferences(req.user.id);
      res.json(preferences);
    } catch (error) {
      console.error('Error fetching preferences:', error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.post('/api/preferences', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const parsed = insertUserPreferencesSchema.safeParse({
        ...req.body,
        userId: req.user.id
      });

      if (!parsed.success) {
        return res.status(400).json({
          message: "Invalid preferences data",
          errors: parsed.error.errors
        });
      }

      const preferences = await storage.upsertUserPreferences(parsed.data);
      res.json(preferences);
    } catch (error) {
      console.error('Error saving preferences:', error);
      res.status(500).json({ message: "Failed to save preferences" });
    }
  });

  // Subscription endpoints
  app.post("/api/subscription", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to upgrade to Premium",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { paymentMethodId } = req.body;
      if (!paymentMethodId) {
        return res.status(400).json({
          message: "We couldn't process your payment. Please try again.",
          code: "PAYMENT_METHOD_REQUIRED"
        });
      }

      const subscription = await createSubscription(req.user.id, paymentMethodId);
      res.json(subscription);
    } catch (error) {
      const errorMessage = isProduction
        ? "We couldn't complete your subscription. Please try again or contact support if the issue persists."
        : error instanceof Error ? error.message : "Unexpected error occurred";

      res.status(500).json({
        message: "Subscription Setup Failed",
        details: errorMessage,
        code: "SUBSCRIPTION_FAILED"
      });
    }
  });

  app.post("/api/subscription/create-payment-intent", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to upgrade to Premium",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({
          message: "We couldn't find your account. Please try logging in again.",
          code: "USER_NOT_FOUND"
        });
      }

      if (!user.email) {
        return res.status(400).json({
          message: "Please add an email to your profile before upgrading to Premium",
          code: "EMAIL_REQUIRED"
        });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: 999, // $9.99 in cents
        currency: 'usd',
        payment_method_types: ['card'],
        metadata: {
          userId: user.id.toString(),
          environment: process.env.NODE_ENV || 'development'
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      const errorMessage = isProduction
        ? "We couldn't set up the payment process. Please try again or contact support if the issue persists."
        : error instanceof Error ? error.message : "Unexpected error occurred";

      res.status(500).json({
        message: "Payment Setup Failed",
        details: errorMessage,
        code: "PAYMENT_INTENT_FAILED"
      });
    }
  });

  // Add debugging for Stripe webhook
  const constructWebhookEvent = (body: any, sig: string) => {
    if (!process.env.STRIPE_WEBHOOK_SECRET) {
      throw new Error("STRIPE_WEBHOOK_SECRET is not configured");
    }
    return stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  }

  app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
    const sig = req.headers["stripe-signature"];


    if (!sig) {
      return res.sendStatus(400);
    }

    try {
      const event = constructWebhookEvent(req.body, sig);

      await handleSubscriptionWebhook(event);

      res.json({ received: true });
    } catch (error) {
      res.status(400).json({
        message: "Webhook error",
        details: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  app.get('/api/compatibility/:userId', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const targetUserId = parseInt(req.params.userId);
      const compatibility = await storage.calculateCompatibilityScore(req.user.id, targetUserId);
      res.json(compatibility);
    } catch (error) {
      console.error('Error calculating compatibility:', error);
      res.status(500).json({ message: "Failed to calculate compatibility" });
    }
  });

  // Add date nights endpoints
  app.post("/api/date-nights", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to create a date night",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { guestId, scheduledFor, notes, calendarProvider } = req.body;

      // Create the date night
      const dateNight = await storage.createDateNight({
        hostId: req.user.id,
        guestId,
        scheduledFor: new Date(scheduledFor),
        notes,
        calendarProvider,
        calendarSyncStatus: calendarProvider ? "pending" : "not_synced"
      });


      // Get host information for the message
      const host = await storage.getUser(req.user.id);
      if (!host) {
        throw new Error("Host not found");
      }

      // Create an exciting invitation message
      const date = new Date(scheduledFor);
      const formattedDate = date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      const invitationMessage = {
        type: 'date_invitation',
        senderId: req.user.id,
        receiverId: guestId,
        dateNightId: dateNight.id,
        content: `✨ Special Invitation ✨\n\n${host.name} would love to go on a date with you on ${formattedDate}! 🌟\n\nReady to create some magic together? Accept this invitation to start your journey! 💫`,
        scheduledFor: scheduledFor
      };

      // Send WebSocket notification to the guest if they're online
      const guestWs = connectedClients.get(guestId);
      if (guestWs?.readyState === WebSocket.OPEN) {
        guestWs.send(JSON.stringify(invitationMessage));
      }

      // Also save this as a chat message
      await storage.createMessage({
        senderId: req.user.id,
        receiverId: guestId,
        content: invitationMessage.content
      });

      res.json(dateNight);
    } catch (error) {
      res.status(500).json({
        message: "Failed to create date night",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "DATE_NIGHT_CREATION_FAILED"
      });
    }
  });

  app.patch("/api/date-nights/:id", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to update date night status",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const dateNightId = parseInt(req.params.id);
      const { status } = req.body;

      if (!['accepted', 'declined', 'raincheck'].includes(status)) {
        return res.status(400).json({
          message: "Invalid status. Must be 'accepted', 'declined', or 'raincheck'",
          code: "INVALID_STATUS"
        });
      }

      const dateNight = await storage.updateDateNightStatus(dateNightId, status);

      if (!dateNight) {
        return res.status(404).json({
          message: "Date night not found",
          code: "DATE_NIGHT_NOT_FOUND"
        });
      }

      // Get host and guest information
      const [host, guest] = await Promise.all([
        storage.getUser(dateNight.hostId),
        storage.getUser(dateNight.guestId)
      ]);

      if (!host || !guest) {
        throw new Error("Could not find host or guest information");
      }

      // Send notification to host via WebSocket
      const hostWs = connectedClients.get(dateNight.hostId);
      if (hostWs?.readyState === WebSocket.OPEN) {
        hostWs.send(JSON.stringify({
          type: 'date_response',
          dateNightId,
          status,
          responder: {
            id: guest.id,
            name: guest.name
          }
        }));
      }

      res.json(dateNight);
    } catch (error) {
      console.error('Error updating date night status:', error);
      res.status(500).json({
        message: "Failed to update date night status",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "UPDATE_STATUS_FAILED"
      });
    }
  });

  app.patch("/api/date-nights/:id/cancel", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to cancel date night",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const dateNightId = parseInt(req.params.id);
      const dateNight = await storage.updateDateNightStatus(dateNightId, 'cancelled');

      if (!dateNight) {
        return res.status(404).json({
          message: "Date night not found",
          code: "DATE_NIGHT_NOT_FOUND"
        });
      }

      // Get host and guest information
      const [host, guest] = await Promise.all([
        storage.getUser(dateNight.hostId),
        storage.getUser(dateNight.guestId)
      ]);

      if (!host || !guest) {
        throw new Error("Could not find host or guest information");
      }

      // Send cancellation notification to both users via WebSocket
      const notification = JSON.stringify({
        type: 'date_cancelled',
        dateNightId,
        cancelledBy: req.user.id,
        dateDetails: {
          scheduledFor: dateNight.scheduledFor,
          hostName: host.name,
          guestName: guest.name
        }
      });

      // Send to both host and guest if they're online
      const hostWs = connectedClients.get(dateNight.hostId);
      const guestWs = connectedClients.get(dateNight.guestId);

      if (hostWs?.readyState === WebSocket.OPEN) {
        hostWs.send(notification);
      }

      if (guestWs?.readyState === WebSocket.OPEN) {
        guestWs.send(notification);
      }

      res.json(dateNight);
    } catch (error) {
      console.error('Error cancelling date night:', error);
      res.status(500).json({
        message: "Failed to cancel date night",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "CANCEL_FAILED"
      });
    }
  });

  app.get("/api/date-nights", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to view date nights",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const dateNights = await storage.getDateNights(req.user.id);
      res.json(dateNights);
    } catch (error) {
      console.error('Error fetching date nights:', error);
      res.status(500).json({
        message: "Failed to fetch date nights",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "FETCH_FAILED"
      });
    }
  });

  // Add these routes after the existing quiz routes
  app.post("/api/quiz-progress", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to save quiz progress",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { currentQuestionId, answers, isCompleted } = req.body;

      const progress = await storage.saveQuizProgress({
        userId: req.user.id,
        currentQuestionId,
        answers,
        isCompleted,
        lastUpdated: new Date()
      });

      res.json(progress);
    } catch (error) {
      console.error('Error saving quiz progress:', error);
      res.status(500).json({
        message: "Failed to save quiz progress",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "SAVE_PROGRESS_ERROR"
      });
    }
  });

  app.get("/api/quiz-progress", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to load quiz progress",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const progress = await storage.getQuizProgress(req.user.id);
      res.json(progress || null);
    } catch (error) {
      console.error('Error loading quiz progress:', error);
      res.status(500).json({
        message: "Failed to load quiz progress",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "LOAD_PROGRESS_ERROR"
      });
    }
  });

  wss.on('connection', (ws: WebSocketWithSession, request: IncomingMessage) => {
    const req = request as unknown as SessionWithPassport;
    const userId = req.session?.passport?.user;

    if (!userId) {
      ws.close(1008, 'No user ID found');
      return;
    }

    ws.userId = userId;
    connectedClients.set(userId, ws);

    // Send initial connection success message
    ws.send(JSON.stringify({
      type: 'connection_status',
      status: 'connected',
      userId: userId
    }));

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message.toString());

        // Broadcast message to relevant clients
        for (const [clientId, clientWs] of connectedClients.entries()) {
          if (clientWs.readyState === WebSocket.OPEN &&
            clientId !== userId && // Don't send to sender
            (clientId === data.receiverId || clientId === data.senderId)) {
            clientWs.send(JSON.stringify({
              type: 'chat',
              senderId: userId,
              receiverId: data.receiverId,
              message: data
            }));
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message'
        }));
      }
    });

    ws.on('close', () => {
      connectedClients.delete(userId);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error for user', userId, ':', error);
      ws.close(1011, 'Internal server error');
    });
  });

  app.get('/api/all-users', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error('Error fetching all users:', error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Add this route after the existing subscription-related routes
  app.get("/api/subscription/status", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to check subscription status",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({
          message: "User not found",
          code: "USER_NOT_FOUND"
        });
      }

      res.json({
        status: user.subscriptionStatus,
        expiresAt: user.subscriptionExpiresAt,
        isActive: user.subscriptionStatus === 'active',
        customerId: user.stripeCustomerId
      });
    } catch (error) {
      res.status(500).json({
        message: "Failed to fetch subscription status",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "FETCH_ERROR"
      });
    }
  });

  // Add subscription status endpoint
  app.get("/api/subscription/status", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to check subscription status",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({
          message: "User not found",
          code: "USER_NOT_FOUND"
        });
      }

      // Return subscription status details
      res.json({
        status: user.subscriptionStatus || 'none',
        expiresAt: user.subscriptionExpiresAt,
        customerId: user.stripeCustomerId,
        subscriptionId: user.subscriptionId
      });
    } catch (error) {
      console.error("[ERROR] Failed to fetch subscription status:", error);
      res.status(500).json({
        message: "Failed to fetch subscription status",
        code: "STATUS_FETCH_FAILED"
      });
    }
  });

  return httpServer;
}