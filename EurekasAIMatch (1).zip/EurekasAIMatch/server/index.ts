import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { setupAuth } from "./auth";
import session from 'express-session';
import { storage } from "./storage";
import { createServer } from "http";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Add production check helper at the top
const isProduction = process.env.NODE_ENV === 'production';

const app = express();

// Trust proxy in production
if (isProduction) {
  app.set("trust proxy", 1);
}

// Add JSON parsing middleware with improved error handling
app.use((req, res, next) => {
  // Skip JSON parsing for Stripe webhook routes which need raw body
  if (req.path === '/api/webhooks/stripe') {
    next();
    return;
  }

  let rawBody = '';
  req.on('data', chunk => {
    rawBody += chunk;
  });

  req.on('end', () => {
    if (!rawBody) {
      next();
      return;
    }

    try {
      const parsedBody = JSON.parse(rawBody);
      req.body = parsedBody;
      next();
    } catch (e) {
      // Only log error details in development
      if (!isProduction) {
        console.error('JSON Parse Error:', {
          error: e,
          path: req.path,
          rawBody: rawBody.slice(0, 200), // Log first 200 chars of raw body
          contentType: req.headers['content-type']
        });
      }

      if (!res.headersSent) {
        res.status(400).json({
          message: 'Invalid JSON payload',
          details: !isProduction ? e.message : undefined,
          code: 'INVALID_JSON'
        });
      }
    }
  });
});

app.use(express.urlencoded({ extended: false }));

// Configure static file serving with proper MIME types
app.use('/static', express.static(path.resolve(__dirname, '../static'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.png')) {
      res.setHeader('Content-Type', 'image/png');
    }
  }
}));

// Global error handler - ensure we always return JSON and check headers
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  // Only log full error details in development
  if (!isProduction) {
    console.error('Error:', {
      message: err.message,
      stack: err.stack,
      status: err.status || err.statusCode
    });
  }

  if (!res.headersSent) {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({
      message,
      error: !isProduction ? err.stack : undefined,
      code: err.code || 'SERVER_ERROR'
    });
  }
});

// Add request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  let port = 5000;
  const maxRetries = 3;
  let server;

  const startServer = async (retryCount = 0) => {
    try {
      server = createServer(app);

      // Configure session middleware with secure settings
      const sessionMiddleware = session({
        secret: process.env.REPL_ID!,
        resave: false,
        saveUninitialized: false,
        store: storage.sessionStore,
        cookie: {
          secure: app.get("env") === "production",
          httpOnly: true,
          sameSite: 'lax',
          maxAge: 24 * 60 * 60 * 1000, // 24 hours
          path: '/'
        },
        name: 'eurekasMatch.sid'
      });

      // Apply session middleware before passport
      app.use(sessionMiddleware);

      // Set up authentication after session
      setupAuth(app);

      // Register routes and get server instance
      const routes = registerRoutes(app, sessionMiddleware);

      // In production, serve static files
      if (app.get("env") === "production") {
        app.use(express.static(path.resolve(__dirname, "public")));
        app.use(express.static(path.resolve(__dirname, "../client/public")));
        app.use("*", (_req, res) => {
          res.sendFile(path.resolve(__dirname, "public/index.html"));
        });
      } else {
        await setupVite(app, server);
      }

      // Handle server shutdown gracefully
      const cleanup = () => {
        server.close(() => {
          console.log('Server closed');
          process.exit(0);
        });
      };

      process.on('SIGTERM', cleanup);
      process.on('SIGINT', cleanup);

      await new Promise((resolve, reject) => {
        server.listen(port, "0.0.0.0")
          .once('listening', resolve)
          .once('error', reject);
      });

      log(`Server started on port ${port} in ${app.get("env")} mode`);

    } catch (error: any) {
      if (error.code === 'EADDRINUSE' && retryCount < maxRetries) {
        console.log(`Port ${port} is in use, trying port ${port + 1}`);
        port++;
        return startServer(retryCount + 1);
      }

      console.error('Failed to start server:', error);
      process.exit(1);
    }
  };

  await startServer();
})();