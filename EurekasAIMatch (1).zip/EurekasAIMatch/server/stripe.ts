import Stripe from 'stripe';
import { WebSocket } from 'ws';
import { db } from './db';
import { users, payments, failedPaymentsStripeReporting, disputes } from '@shared/schema';
import { eq, sql } from 'drizzle-orm';

declare global {
  var wss: { clients: Set<WebSocket> };
}

// Export the stripe instance
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-01-27.acacia',
  appInfo: {
    name: 'EurekasMatch',
    version: '1.0.0'
  },
  typescript: true,
});

const SUBSCRIPTION_PRICE_ID = process.env.STRIPE_PRICE_ID || 'price_H5ggYwtDq4fbrJ';

async function recordFailedPayment(
  userId: number,
  error: any,
  paymentIntentId: string,
  amount: number
) {
  try {
    console.log("[DEBUG] Starting to record failed payment:", {
      userId,
      paymentIntentId,
      error: error.message,
      errorType: error.type,
      errorCode: error.code
    });

    const dbInstance = await db.getInstance();

    // Ensure we have valid error data
    const errorData = {
      message: error.message || 'Unknown error',
      code: error.code || 'unknown_code',
      type: error.type || 'unknown_type'
    };

    // First record failure in the payments table
    await recordPaymentAttempt(userId, {
      paymentIntentId,
      amount,
      currency: 'usd',
      status: 'failed',
      attemptStatus: 'failed',
      failureMessage: errorData.message,
      metadata: {
        error: errorData.code,
        type: errorData.type
      }
    });

    console.log("[DEBUG] Inserting into failed_payments_stripe_reporting table:", {
      userId,
      paymentIntentId,
      amount: amount / 100
    });

    const [failedPayment] = await dbInstance
      .insert(failedPaymentsStripeReporting)
      .values({
        userId: sql`${userId}::integer`, // Explicit type casting
        stripePaymentId: paymentIntentId,
        amount: sql`${amount / 100}::decimal`, // Convert to decimal with explicit casting
        failureMessage: errorData.message,
        failureCode: errorData.code,
        failureType: errorData.type,
        paymentMethodDetails: error.payment_method ?
          { type: error.payment_method.type } :
          { type: 'unknown' },
        rawStripeError: error,
        createdAt: new Date()
      })
      .returning();

    console.log("[DEBUG] Failed payment record created:", failedPayment);

    // Emit failure notification through WebSocket
    if (global.wss) {
      const failureNotification = {
        type: 'payment_failure',
        data: {
          message: errorData.message,
          code: errorData.code,
          paymentId: paymentIntentId
        }
      };

      global.wss.clients.forEach((client: WebSocket) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(failureNotification));
        }
      });
    }

    return failedPayment;
  } catch (error) {
    console.error("[ERROR] Failed to record failed payment:", error);
    throw error;
  }
}

async function recordPaymentAttempt(
  userId: number,
  paymentData: {
    paymentIntentId: string,
    amount: number,
    currency: string,
    status: string,
    attemptStatus: string,
    failureMessage?: string,
    paymentMethodType?: string,
    metadata?: Record<string, any>
  }
) {
  console.log("[DEBUG] Recording payment attempt:", {
    userId,
    ...paymentData
  });

  try {
    const dbInstance = await db.getInstance();
    const [result] = await dbInstance
      .insert(payments)
      .values({
        userId: sql`${userId}::integer`, // Explicit type casting
        amount: sql`${paymentData.amount / 100}::decimal`, // Convert to decimal with explicit casting
        currency: paymentData.currency,
        status: paymentData.status,
        stripePaymentId: paymentData.paymentIntentId,
        createdAt: new Date(),
        attemptStatus: paymentData.attemptStatus,
        failureMessage: paymentData.failureMessage,
        paymentMethodType: paymentData.paymentMethodType,
        stripeMetadata: paymentData.metadata
      })
      .returning();

    console.log("[DEBUG] Payment attempt recorded:", result);
    return result;
  } catch (error) {
    console.error("[ERROR] Failed to record payment attempt:", error);
    throw error;
  }
}

async function recordSubscriptionDetails(userId: number, stripeData: {
  customerId: string;
  subscriptionId: string;
  status: string;
  currentPeriodEnd: number;
}) {
  try {
    const dbInstance = await db.getInstance();
    await dbInstance
      .update(users)
      .set({
        stripeCustomerId: stripeData.customerId,
        subscriptionId: stripeData.subscriptionId,
        subscriptionStatus: stripeData.status,
        subscriptionExpiresAt: new Date(stripeData.currentPeriodEnd * 1000)
      })
      .where(eq(users.id, sql`${userId}::integer`));

    console.log("[DEBUG] Updated user subscription details:", {
      userId,
      customerId: stripeData.customerId,
      subscriptionId: stripeData.subscriptionId,
      status: stripeData.status
    });
  } catch (error) {
    console.error("[ERROR] Failed to record subscription details:", error);
    throw error;
  }
}

export async function createSubscription(userId: number, paymentMethodId: string) {
  console.log("[DEBUG] Starting subscription creation:", { userId, paymentMethodId });
  try {
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user) {
      console.error("[DEBUG] User not found:", userId);
      throw new Error('User not found');
    }
    if (!user.email) {
      console.error("[DEBUG] User email missing for user:", userId);
      throw new Error('User email is required for subscription');
    }

    let stripeCustomerId = user.stripeCustomerId;
    console.log("[DEBUG] Existing Stripe customer ID:", stripeCustomerId);

    // Record initial payment attempt
    await recordPaymentAttempt(userId, {
      paymentIntentId: 'pending',
      amount: 999, // $9.99 in cents
      currency: 'usd',
      status: 'pending',
      attemptStatus: 'initiated',
      metadata: {
        userId: userId.toString(),
        email: user.email,
        type: 'subscription_creation'
      }
    });

    if (!stripeCustomerId) {
      console.log("[DEBUG] Creating new Stripe customer");
      const customer = await stripe.customers.create({
        email: user.email,
        payment_method: paymentMethodId,
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      });
      stripeCustomerId = customer.id;

      // Store customer ID immediately
      await recordSubscriptionDetails(userId, {
        customerId: customer.id,
        subscriptionId: '', // Will be updated after subscription creation
        status: 'pending',
        currentPeriodEnd: Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60 // 30 days from now
      });

      console.log("[DEBUG] Customer created and DB updated:", {
        customerId: customer.id,
        userId
      });
    }

    console.log("[DEBUG] Creating subscription with price:", SUBSCRIPTION_PRICE_ID);
    const subscription = await stripe.subscriptions.create({
      customer: stripeCustomerId,
      items: [{ price: SUBSCRIPTION_PRICE_ID }],
      payment_behavior: 'default_incomplete',
      payment_settings: {
        payment_method_types: ['card'],
        save_default_payment_method: 'on_subscription',
      },
      expand: ['latest_invoice.payment_intent'],
      metadata: {
        userId: userId.toString(),
        email: user.email
      }
    });

    // Update subscription details with actual subscription ID
    await recordSubscriptionDetails(userId, {
      customerId: stripeCustomerId,
      subscriptionId: subscription.id,
      status: subscription.status,
      currentPeriodEnd: subscription.current_period_end
    });

    console.log("[DEBUG] Subscription created:", {
      id: subscription.id,
      status: subscription.status,
      customerId: subscription.customer
    });

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;

    if (paymentIntent) {
      await recordPaymentAttempt(userId, {
        paymentIntentId: paymentIntent.id,
        amount: paymentIntent.amount,
        currency: paymentIntent.currency,
        status: paymentIntent.status,
        attemptStatus: 'processing',
        paymentMethodType: paymentIntent.payment_method_types[0],
        metadata: {
          subscriptionId: subscription.id,
          invoiceId: invoice.id,
          customerId: stripeCustomerId
        }
      });
    }

    return {
      subscriptionId: subscription.id,
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error: any) {
    // Record the failure
    await recordPaymentAttempt(userId, {
      paymentIntentId: 'subscription_creation_failed',
      amount: 999,
      currency: 'usd',
      status: 'failed',
      attemptStatus: 'failed',
      failureMessage: error instanceof Error ? error.message : 'Unknown error',
      metadata: {
        error: error.code || error.type || 'unknown',
        message: error.message
      }
    });

    console.error('[ERROR] Stripe subscription creation failed:', {
      error: error.message,
      code: error.code,
      type: error.type,
      userId
    });
    throw error;
  }
}

export async function handleSubscriptionWebhook(event: Stripe.Event) {
  const eventId = event.id;
  const eventType = event.type;

  console.log("[DEBUG] Processing webhook event:", {
    id: eventId,
    type: eventType,
    created: new Date(event.created * 1000),
    data: JSON.stringify(event.data.object),
    livemode: event.livemode
  });

  try {
    switch (eventType) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        console.log("[DEBUG] Payment succeeded:", {
          id: paymentIntent.id,
          amount: paymentIntent.amount,
          metadata: paymentIntent.metadata
        });

        if (paymentIntent.metadata.userId) {
          await recordPaymentAttempt(
            parseInt(paymentIntent.metadata.userId),
            {
              paymentIntentId: paymentIntent.id,
              amount: paymentIntent.amount,
              currency: paymentIntent.currency,
              status: paymentIntent.status,
              attemptStatus: 'completed',
              paymentMethodType: paymentIntent.payment_method_types[0],
              metadata: paymentIntent.metadata
            }
          );
        }
        break;

      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        const subscription = event.data.object as Stripe.Subscription;
        console.log("[DEBUG] Subscription event:", {
          id: subscription.id,
          status: subscription.status,
          customer: subscription.customer
        });

        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.stripeCustomerId, subscription.customer as string));

        if (!user) {
          console.error('[ERROR] User not found for customer:', subscription.customer);
          return;
        }

        await recordSubscriptionDetails(user.id, {
          customerId: subscription.customer as string,
          subscriptionId: subscription.id,
          status: subscription.status,
          currentPeriodEnd: subscription.current_period_end
        });

        console.log("[DEBUG] Updated subscription status:", {
          userId: user.id,
          status: subscription.status,
          expiresAt: new Date(subscription.current_period_end * 1000)
        });
        break;

      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object as Stripe.PaymentIntent;
        console.log("[DEBUG] Payment failed webhook received:", {
          id: failedPayment.id,
          amount: failedPayment.amount,
          metadata: failedPayment.metadata,
          error: failedPayment.last_payment_error,
          created: new Date(failedPayment.created * 1000)
        });

        if (failedPayment.metadata?.userId) {
          const userId = parseInt(failedPayment.metadata.userId);
          console.log("[DEBUG] Processing failed payment for user:", userId);

          const dbInstance = await db.getInstance();

          // First record in payments table
          const [paymentRecord] = await dbInstance
            .insert(payments)
            .values({
              userId: sql`${userId}::integer`, // Explicit type casting
              amount: sql`${failedPayment.amount / 100}::decimal`, // Convert to decimal with explicit casting
              currency: failedPayment.currency,
              status: 'failed',
              stripePaymentId: failedPayment.id,
              createdAt: new Date(),
              attemptStatus: 'failed',
              failureMessage: failedPayment.last_payment_error?.message || 'Unknown error',
              paymentMethodType: failedPayment.payment_method_types[0],
              stripeMetadata: failedPayment.metadata
            })
            .returning();

          console.log("[DEBUG] Payment record created:", paymentRecord);

          // Then record in failed_payments_stripe_reporting
          const [failedRecord] = await dbInstance
            .insert(failedPaymentsStripeReporting)
            .values({
              userId: sql`${userId}::integer`, // Explicit type casting
              stripePaymentId: failedPayment.id,
              amount: sql`${failedPayment.amount / 100}::decimal`, // Convert to decimal with explicit casting
              failureMessage: failedPayment.last_payment_error?.message || 'Unknown error',
              failureCode: failedPayment.last_payment_error?.code || 'unknown',
              failureType: failedPayment.last_payment_error?.type || 'unknown',
              paymentMethodDetails: {
                type: failedPayment.payment_method_types[0]
              },
              rawStripeError: failedPayment.last_payment_error || {
                message: 'No specific error details available'
              },
              createdAt: new Date()
            })
            .returning();

          console.log("[DEBUG] Failed payment record created:", failedRecord);

          // Send WebSocket notification
          if (global.wss) {
            const notification = {
              type: 'payment_failure',
              data: {
                message: failedPayment.last_payment_error?.message || 'Payment failed',
                code: failedPayment.last_payment_error?.code,
                paymentId: failedPayment.id
              }
            };

            global.wss.clients.forEach((client: WebSocket) => {
              if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(notification));
              }
            });
          }
        }
        break;

      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object as Stripe.Subscription;
        const [deletedUser] = await db
          .select()
          .from(users)
          .where(eq(users.stripeCustomerId, deletedSubscription.customer as string));

        if (deletedUser) {
          await db
            .update(users)
            .set({
              subscriptionStatus: 'canceled',
              subscriptionExpiresAt: null
            })
            .where(eq(users.id, deletedUser.id));

          console.log("[DEBUG] Marked subscription as canceled:", {
            userId: deletedUser.id,
            subscriptionId: deletedSubscription.id
          });
        }
        break;

      case 'charge.dispute.created':
      case 'charge.dispute.updated':
      case 'charge.dispute.closed': {
        const dispute = event.data.object as Stripe.Dispute;
        console.log("[DEBUG] Processing dispute event:", {
          id: dispute.id,
          status: dispute.status,
          amount: dispute.amount,
          reason: dispute.reason
        });

        // Get the charge and associated payment
        const charge = await stripe.charges.retrieve(dispute.charge as string);
        const customerId = charge.customer as string;

        // Find user by Stripe customer ID
        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.stripeCustomerId, customerId));

        if (!user) {
          console.error('[ERROR] User not found for dispute:', dispute.id);
          break;
        }

        // Record dispute in database
        const [disputeRecord] = await db
          .insert(disputes)
          .values({
            userId: user.id,
            stripeDisputeId: dispute.id,
            amount: dispute.amount / 100, // Convert cents to dollars
            currency: dispute.currency,
            status: dispute.status,
            reason: dispute.reason,
            evidence: dispute.evidence,
            chargeId: dispute.charge as string,
            created: new Date(dispute.created * 1000),
            updated: new Date()
          })
          .onConflictDoUpdate({
            target: [disputes.stripeDisputeId],
            set: {
              status: dispute.status,
              evidence: dispute.evidence,
              updated: new Date()
            }
          })
          .returning();

        console.log("[DEBUG] Dispute record created/updated:", disputeRecord);

        // If dispute is lost and subscription is active, handle accordingly
        if (dispute.status === 'lost' && user.subscriptionStatus === 'active') {
          await db
            .update(users)
            .set({
              subscriptionStatus: 'disputed',
              subscriptionExpiresAt: new Date() // Expire immediately
            })
            .where(eq(users.id, user.id));

          // Attempt to cancel the subscription in Stripe
          if (user.subscriptionId) {
            try {
              await stripe.subscriptions.cancel(user.subscriptionId);
            } catch (error) {
              console.error('[ERROR] Failed to cancel subscription after dispute:', error);
            }
          }
        }

        // Send WebSocket notification
        if (global.wss) {
          const notification = {
            type: 'payment_dispute',
            data: {
              status: dispute.status,
              reason: dispute.reason,
              amount: dispute.amount / 100,
              currency: dispute.currency
            }
          };

          global.wss.clients.forEach((client: WebSocket) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(notification));
            }
          });
        }
        break;
      }

      default:
        console.log("[DEBUG] Unhandled event type:", eventType);
    }
  } catch (error: any) {
    console.error('[ERROR] Webhook processing failed:', {
      eventId,
      eventType,
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    throw error;
  }
}

export function constructWebhookEvent(payload: string | Buffer, signature: string) {
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    throw new Error('Missing STRIPE_WEBHOOK_SECRET');
  }

  try {
    console.log("[DEBUG] Constructing webhook event with signature:", signature);
    const event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    console.log("[DEBUG] Successfully constructed webhook event:", {
      id: event.id,
      type: event.type
    });
    return event;
  } catch (error) {
    console.error("[ERROR] Failed to construct webhook event:", error);
    throw error;
  }
}