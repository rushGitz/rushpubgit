import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from 'zod-validation-error';
import connectPgSimple from "connect-pg-simple";
import { db } from "./db";

const scryptAsync = promisify(scrypt);

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const PostgresSessionStore = connectPgSimple(session);
  const sessionStore = new PostgresSessionStore({
    pool: db.pool,
    createTableIfMissing: true,
    tableName: 'session',
    pruneSessionInterval: 60 // Prune expired sessions every minute
  });

  app.use(session({
    store: sessionStore,
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: true,
    saveUninitialized: true,
    rolling: true,
    name: 'eurekasMatch.sid',
    cookie: {
      secure: false, // Set to false for development
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    }
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  // Add session debugging middleware
  app.use((req, res, next) => {
    console.log('Session data:', {
      hasSession: !!req.session,
      hasPassport: !!req.session?.passport,
      userId: req.session?.passport?.user,
      cookies: req.headers.cookie
    });
    next();
  });

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log("Login attempt:", { username });
        const user = await storage.getUserByUsername(username);
        if (!user) {
          console.log("User not found:", { username });
          return done(null, false, { message: "The username you entered doesn't exist" });
        }
        if (!(await comparePasswords(password, user.password))) {
          console.log("Invalid password:", { username });
          return done(null, false, { message: "Incorrect password. Please try again" });
        }
        console.log("Login successful:", { id: user.id, username: user.username });
        return done(null, user);
      } catch (error) {
        console.error("Login error:", error);
        return done(error);
      }
    })
  );

  passport.serializeUser((user, done) => {
    console.log("Serializing user:", user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log("Deserializing user:", id);
      const user = await storage.getUser(id);
      if (!user) {
        console.log("User not found during deserialization:", id);
        return done(null, false);
      }
      done(null, user);
    } catch (error) {
      console.error("Deserialization error:", error);
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      console.log("Registration attempt:", req.body);

      const registrationSchema = insertUserSchema
        .extend({
          password: z.string().min(6, "Password must be at least 6 characters"),
          confirmPassword: z.string(),
          email: z.string().optional().transform(val => val || ''),
          type: z.string().optional().transform(val => val || ''),
          spiritualColor: z.string().optional().transform(val => val || ''),
          quizResults: z.record(z.any()).optional().transform(val => val || {}),
          metaphysicalScores: z.record(z.any()).optional().transform(val => val || {}),
          stripeCustomerId: z.string().optional().transform(val => val || ''),
          quizTimestamp: z.date().nullable().optional(),
          subscriptionExpiresAt: z.date().nullable().optional(),
          genderIdentityValue: z.number().default(5)
        })
        .refine((data) => data.password === data.confirmPassword, {
          message: "Passwords don't match",
          path: ["confirmPassword"],
        });

      const validatedData = registrationSchema.parse(req.body);

      // Check for existing user
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({
          message: "Username already exists"
        });
      }

      // Create user with hashed password and guaranteed gender identity
      const hashedPassword = await hashPassword(validatedData.password);
      const genderIdentityValue = validatedData.genderIdentityValue ?? 5;
      let gender_identity = validatedData.gender_identity;

      // Map genderIdentity if not provided
      if (!gender_identity) {
        gender_identity = getGenderIdentityDisplay(genderIdentityValue);
      }

      console.log("Creating user with gender identity:", gender_identity); 

      const userData = {
        username: validatedData.username,
        password: hashedPassword,
        name: validatedData.name,
        age: validatedData.age,
        location: validatedData.location,
        bio: validatedData.bio || '',
        image: validatedData.image,
        type: validatedData.type || '',
        email: validatedData.email || '',
        spiritualColor: validatedData.spiritualColor || '',
        subscriptionStatus: 'free',
        quizResults: validatedData.quizResults || {},
        metaphysicalScores: validatedData.metaphysicalScores || {},
        stripeCustomerId: validatedData.stripeCustomerId || '',
        quizTimestamp: validatedData.quizTimestamp || null,
        subscriptionExpiresAt: validatedData.subscriptionExpiresAt || null,
        genderIdentityValue,
        gender_identity, 
        phoneNumber: validatedData.phoneNumber || '',
        physicalAddress: validatedData.physicalAddress || ''
      };

      console.log("Final user data before creation:", { ...userData, password: '[REDACTED]' }); 

      const user = await storage.createUser(userData);
      console.log("Registration successful:", { id: user.id, username: user.username });

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      req.login(user, (err) => {
        if (err) {
          console.error("Login error after registration:", err);
          return next(err);
        }
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Registration error:", error);
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({
          message: "Validation failed",
          errors: validationError.details
        });
      }
      res.status(500).json({
        message: error instanceof Error ? error.message : "Registration failed"
      });
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate(
      "local",
      (err: Error | null, user: Express.User | false, info: { message?: string } | undefined) => {
        if (err) {
          console.error("Login error:", err);
          return res.status(500).json({ 
            message: "An unexpected error occurred. Please try again later" 
          });
        }
        if (!user) {
          console.log("Login failed:", info?.message);
          return res.status(401).json({ 
            message: info?.message || "Invalid username or password" 
          });
        }
        req.logIn(user, (err) => {
          if (err) {
            console.error("Session creation error:", err);
            return res.status(500).json({ 
              message: "Failed to create login session. Please try again" 
            });
          }
          console.log("Login successful:", { id: user.id, username: user.username });
          const { password, ...userWithoutPassword } = user;
          res.json(userWithoutPassword);
        });
      }
    )(req, res, next);
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      console.log("Unauthorized /api/user access");
      return res.sendStatus(401);
    }
    console.log("User data requested:", { id: req.user.id });
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });

  app.post("/api/logout", (req, res, next) => {
    const userId = req.user?.id;
    console.log("Logout attempt:", { userId });
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
        return next(err);
      }
      console.log("Logout successful:", { userId });
      res.sendStatus(200);
    });
  });

  app.delete("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      console.log("Unauthorized attempt to delete account");
      return res.sendStatus(401);
    }

    try {
      const userId = req.user.id;
      console.log("Account deletion requested for user:", userId);

      // Delete the user's data
      await storage.deleteUser(userId);

      // Log the user out
      req.logout((err) => {
        if (err) {
          console.error("Error logging out after account deletion:", err);
          return res.status(500).json({ message: "Error during logout after account deletion" });
        }
        console.log("Account successfully deleted for user:", userId);
        res.status(200).json({ message: "Account successfully deleted" });
      });
    } catch (error) {
      console.error("Error deleting account:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to delete account"
      });
    }
  });
}

function getGenderIdentityDisplay(value: number): string {
  const femininePercentage = (value / 10) * 100;
  if (femininePercentage <= 50) {
    const masculinePercentage = Math.abs(100 - femininePercentage);
    return `${Math.round(masculinePercentage)}% Masculine`;
  } else if (femininePercentage >= 67) {
    return `${Math.round(femininePercentage)}% Feminine`;
  } else {
    return `${Math.round(femininePercentage)}% Feminine (Androgynous)`;
  }
}