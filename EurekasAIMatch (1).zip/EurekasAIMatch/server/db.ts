import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// Initialize pool
let pool: Pool | null = null;
let dbInstance: ReturnType<typeof drizzle> | null = null;

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

// Create and initialize the pool with retries
async function initializePool(retryCount = 0): Promise<ReturnType<typeof drizzle>> {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set. Did you forget to provision a database?");
  }

  try {
    if (!pool) {
      pool = new Pool({ 
        connectionString: process.env.DATABASE_URL,
        max: 10, // Reduced max connections to prevent overwhelming
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 5000,
        keepAlive: true,
        keepAliveInitialDelayMillis: 10000
      });

      // Test the connection
      const client = await pool.connect();
      client.release();
      console.log('Successfully connected to database');

      // Initialize Drizzle with the pool
      dbInstance = drizzle(pool, { schema });

      // Add connection error handling
      pool.on('error', async (err) => {
        console.error('Unexpected database error:', err);
        // Attempt to reconnect
        await reconnectDatabase();
      });
    }

    return dbInstance!;
  } catch (error) {
    console.error(`Database initialization attempt ${retryCount + 1} failed:`, error);

    if (retryCount < MAX_RETRIES) {
      console.log(`Retrying in ${RETRY_DELAY}ms...`);
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
      return initializePool(retryCount + 1);
    }

    // Clear the pool if initialization failed
    if (pool) {
      await pool.end();
      pool = null;
      dbInstance = null;
    }
    throw error;
  }
}

async function reconnectDatabase() {
  console.log('Attempting to reconnect to database...');
  try {
    if (pool) {
      await pool.end();
    }
    pool = null;
    dbInstance = null;
    await initializePool();
  } catch (error) {
    console.error('Failed to reconnect to database:', error);
  }
}

// Initialize the database connection
const dbPromise = initializePool();

// Export an object with async query methods
export const database = {
  async query() {
    try {
      let instance = await dbPromise;
      if (!instance) {
        instance = await initializePool();
      }
      if (!instance) {
        throw new Error('Database not initialized');
      }
      return instance;
    } catch (error) {
      console.error('Error in database query:', error);
      throw error;
    }
  },

  async getInstance() {
    return this.query();
  },

  get pool() {
    if (!pool) {
      throw new Error('Database pool not initialized');
    }
    return pool;
  }
};

// For compatibility with existing code
export { pool };
export const db = database;