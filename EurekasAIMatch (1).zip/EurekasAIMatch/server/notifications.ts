import { MailService } from '@sendgrid/mail';
import { type User, type DateNight } from "@shared/schema";
import { format } from 'date-fns';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

const FROM_EMAIL = 'noreply@eurekasmatch.com';

export async function sendDateInvitation(host: User, guest: User, dateNight: DateNight): Promise<boolean> {
  try {
    if (!guest.email) {
      console.error('Cannot send invitation: guest email not found');
      return false;
    }

    const dateStr = format(new Date(dateNight.scheduledFor), "PPP 'at' p");

    await mailService.send({
      to: guest.email,
      from: FROM_EMAIL,
      subject: `${host.name} invited you to a virtual date! 💫`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Virtual Date Invitation</h2>
          <p>Hi ${guest.name}! 🌟</p>
          <p>${host.name} would like to have a virtual date with you on <strong>${dateStr}</strong>!</p>
          <p>This magical encounter will take place in our exclusive virtual space where you can get to know each other better.</p>
          <div style="margin: 20px 0;">
            <a href="https://eurekasmatch.com/datenightcalendar" 
               style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Respond to Invitation
            </a>
          </div>
          <p>See you in the virtual world! ✨</p>
        </div>
      `,
      text: `
        Virtual Date Invitation

        Hi ${guest.name}!

        ${host.name} would like to have a virtual date with you on ${dateStr}!

        This magical encounter will take place in our exclusive virtual space where you can get to know each other better.

        Visit https://eurekasmatch.com/datenightcalendar to respond to the invitation.

        See you in the virtual world!
      `,
    });

    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}