import { pgTable, text, serial, integer, jsonb, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define all tables first to avoid circular references
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  bio: text("bio").notNull(),
  location: text("location").notNull(),
  image: text("image").notNull(),
  type: text("type"),
  genderIdentity: text("gender_identity").notNull(),
  spiritualColor: text("spiritual_color"),
  metaphysicalScores: jsonb("metaphysical_scores"),
  quizResults: jsonb("quiz_results"),
  quizTimestamp: timestamp("quiz_timestamp"),
  // Add subscription related fields
  subscriptionStatus: text("subscription_status").default("free").notNull(),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  stripeCustomerId: text("stripe_customer_id"),
  // Keep existing contact fields
  email: text("email"),
  phoneNumber: text("phone_number"),
  physicalAddress: text("physical_address"),
});

// New payments table for subscription tracking
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("usd").notNull(),
  status: text("status").notNull(), // succeeded, failed, pending
  stripePaymentId: text("stripe_payment_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// New premium preferences table
export const premiumPreferences = pgTable("premium_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Premium questionnaire responses
  relationshipGoals: text("relationship_goals").notNull(),
  communicationStyle: text("communication_style").notNull(),
  emotionalIntelligence: integer("emotional_intelligence").notNull(),
  spiritualPractices: jsonb("spiritual_practices").notNull(),
  lifestyleCompatibility: jsonb("lifestyle_compatibility").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Keep existing tables
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Lifestyle preferences
  petPreference: text("pet_preference").notNull(),
  smokingPreference: text("smoking_preference").notNull(),
  cohabitationPreference: text("cohabitation_preference").notNull(),
  longDistancePreference: text("long_distance_preference").notNull(),
  physicalPreferences: jsonb("physical_preferences"),
  intimacyPreferences: jsonb("intimacy_preferences"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const userSelections = pgTable("user_selections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  targetUserId: integer("target_user_id").notNull(),
  liked: boolean("liked").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Add date nights table
export const dateNights = pgTable("date_nights", {
  id: serial("id").primaryKey(),
  hostId: integer("host_id").notNull(),
  guestId: integer("guest_id").notNull(),
  scheduledFor: timestamp("scheduled_for").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, declined, completed
  location: text("location").notNull().default("https://www.spatial.io/s/EurekaPleaseVRs-Hangout-6743b7b7f55ce82a72052644?share=2375748144776782220"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Define schemas after table definitions
export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    name: true,
    age: true,
    bio: true,
    location: true,
    image: true,
    genderIdentity: true,
  })
  .extend({
    password: z.string().min(6, "Password must be at least 6 characters"),
    username: z.string().min(3, "Username must be at least 3 characters"),
    bio: z.string().default(""),
    image: z.string().default("/default-avatar.png"),
    genderIdentity: z.enum(["Stud", "Femme"], {
      required_error: "Gender identity is required (Stud or Femme)",
      invalid_type_error: "Gender identity must be either Stud or Femme",
    }),
    email: z.string().email("Invalid email address").optional(),
    phoneNumber: z.string().optional(),
    physicalAddress: z.string().optional(),
    type: z.string().optional().default(""),
    spiritualColor: z.string().nullable().optional(),
    metaphysicalScores: z.record(z.string(), z.number()).nullable().optional(),
    quizResults: z.record(z.string(), z.unknown()).nullable().optional(),
    quizTimestamp: z.date().nullable().optional(),
    subscriptionStatus: z.string().default("free"),
    subscriptionExpiresAt: z.date().nullable().optional(),
    stripeCustomerId: z.string().nullable().optional(),
  });

// New schema for payments
export const insertPaymentSchema = createInsertSchema(payments).pick({
  userId: true,
  amount: true,
  currency: true,
  status: true,
  stripePaymentId: true,
});

// New schema for premium preferences
export const insertPremiumPreferencesSchema = createInsertSchema(premiumPreferences)
  .pick({
    userId: true,
    relationshipGoals: true,
    communicationStyle: true,
    emotionalIntelligence: true,
    spiritualPractices: true,
    lifestyleCompatibility: true,
  })
  .extend({
    relationshipGoals: z.enum([
      "Long-term Partnership",
      "Spiritual Connection",
      "Personal Growth",
      "Community Building",
    ]),
    communicationStyle: z.enum([
      "Direct",
      "Empathetic",
      "Analytical",
      "Expressive",
    ]),
    emotionalIntelligence: z.number().min(1).max(10),
    spiritualPractices: z.record(z.string(), z.boolean()),
    lifestyleCompatibility: z.record(z.string(), z.unknown()),
  });

// Keep existing schemas
export const insertUserPreferencesSchema = createInsertSchema(userPreferences)
  .pick({
    userId: true,
    petPreference: true,
    smokingPreference: true,
    cohabitationPreference: true,
    longDistancePreference: true,
    physicalPreferences: true,
    intimacyPreferences: true,
  })
  .extend({
    petPreference: z.enum(["Loves Pets", "Has Pets", "No Pets", "Allergic"]),
    smokingPreference: z.enum(["Non-smoker", "Social Smoker", "Regular Smoker", "No Preference"]),
    cohabitationPreference: z.enum(["Wants to Live Together", "Prefers Living Apart", "Open to Both"]),
    longDistancePreference: z.enum(["Open to Long Distance", "Local Only", "Willing to Relocate"]),
    physicalPreferences: z.record(z.string(), z.unknown()),
    intimacyPreferences: z.record(z.string(), z.unknown()),
  });

export const insertUserSelectionSchema = createInsertSchema(userSelections).pick({
  userId: true,
  targetUserId: true,
  liked: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  senderId: true,
  receiverId: true,
  content: true,
});

// Add date night schema
export const insertDateNightSchema = createInsertSchema(dateNights)
  .pick({
    hostId: true,
    guestId: true,
    scheduledFor: true,
    location: true,
    notes: true,
  });

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPremiumPreferences = z.infer<typeof insertPremiumPreferencesSchema>;
export type PremiumPreferences = typeof premiumPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserSelection = z.infer<typeof insertUserSelectionSchema>;
export type UserSelection = typeof userSelections.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
// Export types for date nights
export type InsertDateNight = z.infer<typeof insertDateNightSchema>;
export type DateNight = typeof dateNights.$inferSelect;