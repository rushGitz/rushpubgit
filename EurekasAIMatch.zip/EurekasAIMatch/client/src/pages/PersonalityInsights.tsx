import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PERSONALITY_INSIGHTS = {
  "Mystic Healer": {
    description: "As a Mystic Healer, you possess an innate ability to sense and heal emotional wounds. Your empathic nature allows you to create deep, meaningful connections.",
    strengths: ["Emotional Intelligence", "Intuitive Understanding", "Nurturing Spirit"],
    compatibility: {
      "Mindful Explorer": "Your healing nature complements their adventurous spirit, creating a balanced partnership.",
      "Spiritual Guide": "A deeply spiritual connection that enhances both partners' intuitive abilities.",
      "Empathic Nurturer": "A powerfully emotional bond that can lead to profound personal growth."
    },
    conversationStarters: [
      "What spiritual practices help you stay grounded?",
      "How do you channel your healing energy in daily life?",
      "What's your favorite way to practice self-care?"
    ]
  },
  "Mindful Explorer": {
    description: "As a Mindful Explorer, you approach relationships with curiosity and openness. Your adventurous spirit brings excitement and growth to partnerships.",
    strengths: ["Adaptability", "Curiosity", "Open-mindedness"],
    compatibility: {
      "Mystic Healer": "Their grounding presence balances your explorative nature.",
      "Spiritual Guide": "A dynamic duo for spiritual and intellectual exploration.",
      "Empathic Nurturer": "They provide the emotional anchor for your adventures."
    },
    conversationStarters: [
      "What's the most interesting spiritual concept you've explored lately?",
      "How do you balance adventure with mindfulness?",
      "What unexpected discoveries have shaped your path?"
    ]
  },
  "Spiritual Guide": {
    description: "As a Spiritual Guide, you illuminate the path for others while maintaining a deep connection to universal wisdom. Your presence inspires spiritual growth.",
    strengths: ["Wisdom", "Leadership", "Spiritual Awareness"],
    compatibility: {
      "Mystic Healer": "Together, you create a powerful healing and guiding force.",
      "Mindful Explorer": "Your wisdom guides their exploration, leading to mutual growth.",
      "Empathic Nurturer": "A deeply spiritual and emotionally nurturing connection."
    },
    conversationStarters: [
      "What spiritual teachings resonate most with you?",
      "How do you maintain your connection to universal wisdom?",
      "What role does meditation play in your daily life?"
    ]
  },
  "Empathic Nurturer": {
    description: "As an Empathic Nurturer, you create safe spaces for emotional expression and growth. Your compassionate nature fosters deep emotional bonds.",
    strengths: ["Emotional Depth", "Supportiveness", "Compassion"],
    compatibility: {
      "Mystic Healer": "A deeply healing and nurturing partnership.",
      "Mindful Explorer": "You provide emotional stability for their adventures.",
      "Spiritual Guide": "Your emotional wisdom complements their spiritual guidance."
    },
    conversationStarters: [
      "How do you maintain emotional boundaries while staying open?",
      "What practices help you recharge your empathic energy?",
      "How do you create safe spaces for emotional connection?"
    ]
  }
};

export default function PersonalityInsights() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedTab, setSelectedTab] = useState<string>("insights");

  useEffect(() => {
    if (!user?.quizResults || !user?.type) {
      toast({
        title: "Quiz Required",
        description: "Please complete the personality quiz to unlock your insights!",
        variant: "destructive",
      });
      setLocation("/quiz");
      return;
    }
  }, [user, toast, setLocation]);

  if (!user?.type || !PERSONALITY_INSIGHTS[user.type as keyof typeof PERSONALITY_INSIGHTS]) {
    return null;
  }

  const insights = PERSONALITY_INSIGHTS[user.type as keyof typeof PERSONALITY_INSIGHTS];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="backdrop-blur-xl bg-background/60 border-primary/20 overflow-hidden">
            <CardContent className="p-6">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-primary mb-2">Your Spiritual Blueprint</h1>
                <p className="text-lg text-muted-foreground">
                  Discover the depths of your {user.type} personality
                </p>
              </div>

              <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-8">
                  <TabsTrigger value="insights">Core Insights</TabsTrigger>
                  <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
                  <TabsTrigger value="conversation">Connection Guide</TabsTrigger>
                </TabsList>

                <TabsContent value="insights">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-6">
                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Essence</h2>
                        <p className="text-muted-foreground">{insights.description}</p>
                      </div>

                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">Your Strengths</h2>
                        <ul className="space-y-2">
                          {insights.strengths.map((strength, index) => (
                            <li key={index} className="flex items-center text-muted-foreground">
                              <span className="text-primary mr-2">✨</span>
                              {strength}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="compatibility">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-4">
                      {Object.entries(insights.compatibility).map(([type, description], index) => (
                        <motion.div
                          key={type}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="p-6 rounded-lg bg-primary/5 border border-primary/10"
                        >
                          <h3 className="text-lg font-semibold text-primary mb-2">{type}</h3>
                          <p className="text-muted-foreground">{description}</p>
                        </motion.div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="conversation">
                  <ScrollArea className="h-[60vh] pr-4">
                    <div className="space-y-4">
                      <div className="p-6 rounded-lg bg-primary/5 border border-primary/10">
                        <h2 className="text-xl font-semibold text-primary mb-4">
                          Spiritual Connection Starters
                        </h2>
                        <div className="space-y-4">
                          {insights.conversationStarters.map((starter, index) => (
                            <motion.div
                              key={index}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="p-4 rounded-lg bg-primary/10 backdrop-blur-sm"
                            >
                              <p className="text-primary-foreground">"{starter}"</p>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
