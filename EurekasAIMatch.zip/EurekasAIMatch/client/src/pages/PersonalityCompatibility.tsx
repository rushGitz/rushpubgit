import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { type User } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function PersonalityCompatibility() {
  const { toast } = useToast();
  const [compatibilityScores, setCompatibilityScores] = useState<{
    overall: number;
    spiritual: number;
    metaphysical: number;
    personality: number;
  } | null>(null);

  // Fetch current user data
  const { data: userData, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  // Fetch compatible matches
  const { data: compatibleUsers, isLoading: matchesLoading } = useQuery<User[]>({
    queryKey: ["/api/compatible-users"],
    enabled: !!userData,
  });

  if (userLoading || matchesLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h1 className="text-3xl font-bold text-center text-primary">Personality Compatibility Analysis</h1>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* User's Profile Summary */}
            <section className="space-y-4">
              <h2 className="text-2xl font-semibold text-primary">Your Spiritual Profile</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-background/50 border-primary/20">
                  <CardContent className="p-4">
                    <h3 className="font-medium text-primary">Aura Color</h3>
                    <p className="text-lg capitalize">{userData?.spiritualColor || "Not Set"}</p>
                  </CardContent>
                </Card>
                <Card className="bg-background/50 border-primary/20">
                  <CardContent className="p-4">
                    <h3 className="font-medium text-primary">Personality Type</h3>
                    <p className="text-lg">{userData?.type || "Not Set"}</p>
                  </CardContent>
                </Card>
                <Card className="bg-background/50 border-primary/20">
                  <CardContent className="p-4">
                    <h3 className="font-medium text-primary">Metaphysical Score</h3>
                    <p className="text-lg">
                      {userData?.metaphysicalScores && typeof userData.metaphysicalScores === 'object'
                        ? (Object.values(userData.metaphysicalScores as Record<string, number>)
                            .reduce((a, b) => a + b, 0) / 
                            Object.values(userData.metaphysicalScores as Record<string, number>).length)
                            .toFixed(1)
                        : "Not Set"}
                    </p>
                  </CardContent>
                </Card>
              </div>
            </section>

            {/* Compatible Matches */}
            <section className="space-y-4">
              <h2 className="text-2xl font-semibold text-primary">Your Compatible Matches</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {compatibleUsers?.map((match) => (
                  <motion.div
                    key={match.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="bg-background/50 border-primary/20">
                      <CardContent className="p-4 space-y-4">
                        <div className="flex items-center space-x-4">
                          <div className="relative w-16 h-16">
                            <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-full blur-md" />
                            <img
                              src={match.image}
                              alt={match.name}
                              className="relative w-full h-full rounded-full object-cover border-2 border-primary/50"
                            />
                          </div>
                          <div>
                            <h3 className="font-medium text-primary">{match.name}</h3>
                            <p className="text-sm text-muted-foreground capitalize">
                              {match.spiritualColor} Aura • {match.type}
                            </p>
                          </div>
                        </div>
                        <Button
                          onClick={() => {/* TODO: Implement detailed comparison view */}}
                          className="w-full bg-primary/20 hover:bg-primary/30"
                        >
                          View Compatibility Details
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}