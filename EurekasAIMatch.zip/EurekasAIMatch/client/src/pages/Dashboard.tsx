import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { format } from "date-fns";
import axios from "axios";
import type { User } from "@shared/schema";
import { SparkVisualization } from "@/components/SparkVisualization";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

type Match = {
  id: number;
  username: string;
  name: string;
  age: number;
  bio: string;
  image: string;
  type: string;
  spiritualColor: string | null;
  location: string;
  genderIdentity: string;
  compatibility?: number;
};

type Message = {
  id: number;
  senderId: number;
  receiverId: number;
  content: string;
  createdAt: string;
  dateNightId?: number; // Added to handle dateNightId
};

const PERSONALITY_TYPES = [
  "Mystic Healer",
  "Mindful Explorer",
  "Spiritual Guide",
  "Empathic Nurturer"
] as const;

const GENDER_IDENTITIES = ["Stud", "Femme"] as const;

const formatMessageTime = (dateString: string) => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  if (date.toDateString() === today.toDateString()) {
    return `Today at ${format(date, 'h:mm a')}`;
  } else if (date.toDateString() === yesterday.toDateString()) {
    return `Yesterday at ${format(date, 'h:mm a')}`;
  } else {
    return format(date, 'MMM d, yyyy h:mm a');
  }
};

const scrollToBottom = (container: HTMLDivElement) => {
  container.scrollTop = container.scrollHeight;
};

export default function Dashboard() {
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [personalityTypeFilter, setPersonalityTypeFilter] = useState<string>("all");
  const [genderFilter, setGenderFilter] = useState<string>("all");
  const [isAiMatchmaking, setIsAiMatchmaking] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: matches = [] } = useQuery({
    queryKey: ['/api/matches'],
    queryFn: async () => {
      const response = await axios.get<Match[]>("/api/matches");
      return response.data;
    }
  });

  const { data: pendingMatches = [] } = useQuery({
    queryKey: ['/api/pending-matches'],
    queryFn: async () => {
      const response = await axios.get<Match[]>("/api/pending-matches");
      return response.data;
    }
  });

  const { data: passes = [] } = useQuery({
    queryKey: ['/api/passes'],
    queryFn: async () => {
      const response = await axios.get<Match[]>("/api/passes");
      return response.data;
    }
  });

  const { data: messages = [], refetch: refetchMessages } = useQuery({
    queryKey: ['/api/messages', selectedMatch?.id],
    queryFn: async () => {
      if (!selectedMatch) return [];
      const response = await axios.get<Message[]>(`/api/messages/${selectedMatch.id}`);
      return response.data;
    },
    enabled: !!selectedMatch
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedMatch) throw new Error("No match selected");
      const response = await axios.post("/api/messages", {
        receiverId: selectedMatch.id,
        content: content.trim()
      });
      return response.data;
    },
    onSuccess: () => {
      setNewMessage("");
      refetchMessages();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  });

  const filteredMatches = matches
    .filter((match, index, self) => {
      const isDuplicate = self.findIndex(m => m.id === match.id) !== index;
      if (isDuplicate) return false;

      if (personalityTypeFilter !== "all" && match.type !== personalityTypeFilter) {
        return false;
      }

      if (genderFilter !== "all" && match.genderIdentity !== genderFilter) {
        return false;
      }

      return true;
    })
    .sort((a, b) => {
      const scoreA = a.compatibility || 0;
      const scoreB = b.compatibility || 0;
      return scoreB - scoreA;
    });

  useEffect(() => {
    if (!user?.id) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("WebSocket connected");
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'chat' &&
          (data.senderId === selectedMatch?.id || data.receiverId === selectedMatch?.id)) {
          refetchMessages();
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    return () => {
      socket.close();
    };
  }, [user?.id, selectedMatch?.id]);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    await sendMessageMutation.mutateAsync(newMessage);
  };

  const findAIMatch = async () => {
    setIsAiMatchmaking(true);
    try {
      // Check user's quiz results and profile data
      const response = await axios.get(`/api/user/${user?.id}/quiz-results`);
      console.log("Checking user profile data:", response.data);

      // Check for required matching criteria
      const hasQuizData = response.data?.quizResults && Object.keys(response.data.quizResults).length > 0;
      const hasMetaphysicalScores = response.data?.metaphysicalScores && 
        Object.keys(response.data.metaphysicalScores).length > 0;
      const hasType = response.data?.type && response.data.type.length > 0;

      // Check if quiz is expired (30 days)
      const quizTimestamp = response.data?.quizTimestamp ? new Date(response.data.quizTimestamp) : null;
      const isQuizExpired = quizTimestamp && 
        (new Date().getTime() - quizTimestamp.getTime()) > (30 * 24 * 60 * 60 * 1000);

      if ((hasQuizData || hasMetaphysicalScores || hasType) && !isQuizExpired) {
        // If we have valid matching data, proceed to AI matchmaker
        setLocation("/ai-matchmaker");
      } else {
        // If profile is incomplete or expired, redirect to quiz
        toast({
          title: "Profile Update Needed",
          description: "Please complete or update your spiritual profile to access AI matches.",
          variant: "destructive",
        });
        setLocation("/quiz");
      }
    } catch (error) {
      console.error("Error checking profile data:", error);
      toast({
        title: "Error",
        description: "Failed to check profile data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAiMatchmaking(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-primary">Your Dating Dashboard</h1>
          <Button
            onClick={findAIMatch}
            disabled={isAiMatchmaking}
            className="bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90 transition-all duration-300"
          >
            {isAiMatchmaking ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Finding Matches...
              </>
            ) : (
              "✨ AI Matchmaker"
            )}
          </Button>
        </div>

        <Card className="mb-8 backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left space-y-2">
                <h2 className="text-xl font-semibold text-primary">Virtual Hangout Space</h2>
                <p className="text-muted-foreground">
                  Meet your matches safely in our virtual space before sharing personal details.
                  Get to know each other's energy and vibe in Eureka's Hang Out! ✨
                </p>
                <p className="text-sm text-primary/80 italic">
                  "True connection begins with safe, meaningful interaction."
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-gradient-to-r from-primary/90 to-primary hover:from-primary hover:to-primary/90 transition-all duration-300"
                  size="lg"
                  onClick={() => window.open('https://www.spatial.io/s/EurekaPleaseVRs-Hangout-6743b7b7f55ce82a72052644?share=2375748144776782220', '_blank')}
                >
                  🌟 Enter Virtual Hangout
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setLocation('/datenightcalendar')}
                >
                  📅 View Date Calendar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Select
            value={personalityTypeFilter}
            onValueChange={(value) => setPersonalityTypeFilter(value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Filter by Personality Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {PERSONALITY_TYPES.map(type => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={genderFilter}
            onValueChange={(value) => setGenderFilter(value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Filter by Identity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Identities</SelectItem>
              {GENDER_IDENTITIES.map(identity => (
                <SelectItem key={identity} value={identity}>
                  {identity}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="matches" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="matches">Matches ({filteredMatches.length})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({pendingMatches.length})</TabsTrigger>
            <TabsTrigger value="passes">Passes ({passes.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="matches" className="space-y-4">
            <div className="text-center mb-6">
              <p className="text-lg text-primary/80 italic">
                "True beauty lies in the harmony of souls, where two spirits dance in perfect resonance."
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                These beautiful connections have blossomed from spiritual compatibility. We recommend meeting in
                our Virtual Hangout first - it's a safe and magical space to let your connection grow naturally
                before sharing personal contact information. 🌟
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {filteredMatches.map(match => (
                  <motion.div
                    key={match.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="relative overflow-hidden backdrop-blur-xl bg-background/60 border-primary/20">
                      <CardContent className="p-6">
                        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
                          <img
                            src={match.image}
                            alt={match.name}
                            className="w-24 h-24 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-primary/50"
                          />
                          <div className="text-center sm:text-left">
                            <div className="flex items-center justify-center sm:justify-start gap-2">
                              <h3 className="text-lg font-semibold text-primary">{match.name}</h3>
                              <span className="text-sm font-medium text-primary/80">
                                {Math.round((match.compatibility || 0) * 100)}% Match
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">{match.location}</p>
                            <p className="text-sm text-muted-foreground">{match.age} years old</p>
                            <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-2">
                              <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                                {match.type}
                              </span>
                              {match.spiritualColor && (
                                <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary capitalize">
                                  {match.spiritualColor} Aura
                                </span>
                              )}
                              <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                                {match.genderIdentity}
                              </span>
                            </div>
                          </div>
                        </div>
                        <SparkVisualization
                          compatibility={match.compatibility || 0.8}
                        />
                        <Button
                          variant="secondary"
                          className="w-full mt-4"
                          onClick={() => setSelectedMatch(match)}
                        >
                          Open Chat
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            <div className="text-center mb-6">
              <p className="text-lg text-primary/80 italic">
                "The most beautiful connections often begin with patience. Your spiritual match may still be discovering their path to you."
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                These souls have caught a glimpse of your inner light. Give them time to fully recognize the spiritual connection.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {pendingMatches.map(match => (
                  <motion.div
                    key={match.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 0.6, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="relative"
                  >
                    <div className="absolute inset-0 flex items-center justify-center z-10">
                      <span className="px-3 py-1 bg-background/80 rounded-full text-sm font-medium text-primary">
                        A Soul in Waiting
                      </span>
                    </div>
                    <Card className="relative overflow-hidden backdrop-blur-xl bg-background/60 border-primary/20">
                      <CardContent className="p-6">
                        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
                          <img
                            src={match.image}
                            alt={match.name}
                            className="w-24 h-24 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-primary/50"
                          />
                          <div className="text-center sm:text-left">
                            <h3 className="text-lg font-semibold text-primary">{match.name}</h3>
                            <p className="text-sm text-muted-foreground">{match.location}</p>
                            <p className="text-sm text-muted-foreground">{match.age} years old</p>
                            <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-2">
                              <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                                {match.type}
                              </span>
                              {match.spiritualColor && (
                                <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary capitalize">
                                  {match.spiritualColor} Aura
                                </span>
                              )}
                              <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary">
                                {match.genderIdentity}
                              </span>
                            </div>
                          </div>
                        </div>
                        <SparkVisualization
                          compatibility={0.8}
                        />
                        <Button
                          variant="secondary"
                          className="w-full mt-4"
                          onClick={() => setSelectedMatch(match)}
                        >
                          Open Chat
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </TabsContent>

          <TabsContent value="passes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {passes.map(pass => (
                <motion.div
                  key={pass.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
                    <CardContent className="p-6">
                      <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
                        <img
                          src={pass.image}
                          alt={pass.name}
                          className="w-24 h-24 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-primary/50 opacity-50"
                        />
                        <div className="text-center sm:text-left">
                          <h3 className="text-lg font-semibold text-muted-foreground">{pass.name}</h3>
                          <p className="text-sm text-muted-foreground/60">{pass.location}</p>
                          <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-2">
                            <span className="px-2 py-1 text-xs rounded-full bg-primary/20 text-primary/50">
                              {pass.genderIdentity}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {selectedMatch && (
          <Card className="fixed inset-x-0 bottom-0 md:bottom-4 md:right-4 md:left-auto w-full md:w-96 h-[70vh] md:h-[500px] backdrop-blur-xl bg-background/60 border-primary/20 rounded-t-lg md:rounded-lg">
            <CardContent className="p-4 h-full flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <img
                    src={selectedMatch.image}
                    alt={selectedMatch.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-primary/20"
                  />
                  <div>
                    <h3 className="font-semibold text-primary">{selectedMatch.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {selectedMatch.type}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedMatch(null)}
                  className="hover:bg-primary/10"
                >
                  ✕
                </Button>
              </div>

              <ScrollArea
                className="flex-1 pr-4"
                ref={(ref) => {
                  if (ref) {
                    scrollToBottom(ref as unknown as HTMLDivElement);
                  }
                }}
              >
                <div className="space-y-4">
                  {messages.map(message => {
                    const isDateInvitation = message.content.includes('✨ Special Invitation ✨');
                    const isCurrentUser = message.senderId === user?.id;

                    return (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`flex flex-col gap-1 ${
                          isCurrentUser ? 'items-end' : 'items-start'
                        }`}
                      >
                        <div
                          className={`flex items-start gap-2 max-w-[80%] ${
                            isCurrentUser ? 'flex-row-reverse' : 'flex-row'
                          }`}
                        >
                          <img
                            src={isCurrentUser ? (user?.image || '/default-avatar.png') : selectedMatch?.image}
                            alt={isCurrentUser ? 'You' : selectedMatch?.name}
                            className="w-8 h-8 rounded-full object-cover border-2 border-primary/20"
                          />
                          <div
                            className={`px-4 py-2 rounded-2xl ${
                              isDateInvitation
                                ? 'bg-primary/10 border border-primary/20'
                                : isCurrentUser
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted'
                            }`}
                          >
                            {message.content}
                            {isDateInvitation && !isCurrentUser && (
                              <div className="mt-4 flex gap-2">
                                <Button
                                  variant="default"
                                  size="sm"
                                  className="bg-primary/90 hover:bg-primary"
                                  onClick={() => {
                                    // Extract dateNightId from message metadata if available
                                    const dateNightId = (message as any).dateNightId;
                                    if (dateNightId) {
                                      axios.patch(`/api/date-nights/${dateNightId}`, {
                                        status: 'accepted'
                                      }).then(() => {
                                        toast({
                                          title: "Date Accepted!",
                                          description: "The date has been added to your calendar.",
                                        });
                                        queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
                                      }).catch((error) => {
                                        toast({
                                          title: "Error",
                                          description: "Failed to accept date invitation",
                                          variant: "destructive"
                                        });
                                      });
                                    }
                                  }}
                                >
                                  Accept ✨
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    const dateNightId = (message as any).dateNightId;
                                    if (dateNightId) {
                                      axios.patch(`/api/date-nights/${dateNightId}`, {
                                        status: 'declined'
                                      }).then(() => {
                                        toast({
                                          title: "Date Declined",
                                          description: "The invitation has been declined.",
                                        });
                                        queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
                                      }).catch((error) => {
                                        toast({
                                          title: "Error",
                                          description: "Failed to decline date invitation",
                                          variant: "destructive"
                                        });
                                      });
                                    }
                                  }}
                                >
                                  Decline
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        <span className={`text-xs text-muted-foreground px-2 ${
                          isCurrentUser ? 'text-right' : 'text-left'
                        }`}>
                          {formatMessageTime(message.createdAt)}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
              </ScrollArea>

              <div className="flex items-center gap-2 mt-4 pt-2 border-t border-primary/20">
                <Input
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  className="flex-1 bg-background/50"
                />
                <Button
                  onClick={sendMessage}
                  className="bg-primary hover:bg-primary/80"
                >
                  Send
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}