import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import { type User, type DateNight } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function DateNightCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Fetch date nights where user is either host or guest
  const { data: dateNights = [], isLoading: isLoadingDateNights } = useQuery<DateNight[]>({
    queryKey: ['/api/date-nights'],
    enabled: !!user?.id,
  });

  // Fetch matches for inviting
  const { data: matches = [], isLoading: isLoadingMatches } = useQuery<User[]>({
    queryKey: ['/api/matches'],
    enabled: !!user?.id,
  });

  const createDateNight = useMutation({
    mutationFn: async (data: { guestId: number; scheduledFor: Date }) => {
      const response = await fetch('/api/date-nights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create date night');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
      toast({
        title: "Date Invitation Sent!",
        description: "Your virtual date invitation has been sent. We'll notify you when they respond!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send date invitation. Please try again.",
        variant: "destructive",
      });
    }
  });

  const respondToDate = useMutation({
    mutationFn: async ({ dateId, status }: { dateId: number; status: 'accepted' | 'declined' }) => {
      const response = await fetch(`/api/date-nights/${dateId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) throw new Error('Failed to update date night status');
      return response.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/date-nights'] });
      toast({
        title: variables.status === 'accepted' ? "Date Accepted!" : "Date Declined",
        description: variables.status === 'accepted' 
          ? "Get ready for your virtual date! We've added it to your calendar."
          : "No worries! We've notified the other person.",
      });
    }
  });

  if (isLoadingDateNights || isLoadingMatches) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="text-muted-foreground">Loading your magical calendar...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="backdrop-blur-xl bg-background/60 border-primary/20">
          <CardHeader>
            <h1 className="text-3xl font-bold text-center text-primary">Virtual Date Night Calendar</h1>
            <p className="text-center text-muted-foreground">
              Schedule and manage your virtual dates in our safe and magical space ✨
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h2 className="text-xl font-semibold mb-4">Select a Date</h2>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                  disabled={(date) => date < new Date()}
                />
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full mt-4" disabled={!date}>Schedule Virtual Date</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Schedule a Virtual Date</DialogTitle>
                      <DialogDescription>
                        Choose a match to invite for a virtual date in our magical space.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 mt-4">
                      {matches.map((match) => (
                        <Button
                          key={match.id}
                          variant="outline"
                          onClick={() => {
                            if (date && user?.id) {
                              createDateNight.mutate({
                                guestId: match.id,
                                scheduledFor: date,
                              });
                            }
                          }}
                          className="flex items-center gap-2"
                        >
                          <img
                            src={match.image}
                            alt={match.name}
                            className="w-8 h-8 rounded-full"
                          />
                          <span>{match.name}</span>
                        </Button>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4">Your Date Nights</h2>
                <div className="space-y-4">
                  {dateNights && dateNights.length > 0 ? (
                    dateNights.map((dateNight) => (
                      <Card key={dateNight.id} className="bg-background/50">
                        <CardContent className="p-4">
                          <p className="font-medium">
                            {format(new Date(dateNight.scheduledFor), "PPP 'at' p")}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Status: <span className="capitalize">{dateNight.status}</span>
                          </p>
                          {dateNight.guestId === user?.id && dateNight.status === 'pending' && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                size="sm"
                                onClick={() => respondToDate.mutate({ dateId: dateNight.id, status: 'accepted' })}
                              >
                                Accept
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => respondToDate.mutate({ dateId: dateNight.id, status: 'declined' })}
                              >
                                Decline
                              </Button>
                            </div>
                          )}
                          {dateNight.status === 'accepted' && (
                            <Button
                              className="w-full mt-2"
                              onClick={() => window.open(dateNight.location, '_blank')}
                            >
                              Join Virtual Date
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center p-6 border-2 border-dashed rounded-lg border-muted-foreground/20">
                      <p className="text-muted-foreground">
                        No date nights scheduled yet. Start by selecting a date and inviting someone special! ✨
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}