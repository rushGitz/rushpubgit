import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadialBarChart, RadialBar, Legend, Tooltip } from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Slider } from "@/components/ui/slider";
import axios from "axios";

const quizQuestions = [
  {
    id: 1,
    question: "How do you prefer to recharge?",
    options: [
      { text: "Quiet meditation and solitude", type: "Mystic Healer" },
      { text: "Connecting with nature", type: "Spiritual Guide" },
      { text: "Engaging in creative activities", type: "Empathic Nurturer" },
      { text: "Sharing experiences with others", type: "Mindful Explorer" }
    ]
  },
  {
    id: 2,
    question: "How do you view coincidences?",
    options: [
      { text: "Strongly believe in destiny", type: "Mystic Healer" },
      { text: "Notice meaningful coincidences", type: "Spiritual Guide" },
      { text: "Sometimes see patterns", type: "Empathic Nurturer" },
      { text: "Prefer logical explanations", type: "Mindful Explorer" }
    ]
  },
  {
    id: 3,
    question: "How do you make decisions?",
    options: [
      { text: "Always trust my gut feelings", type: "Mystic Healer" },
      { text: "Balance intuition with logic", type: "Spiritual Guide" },
      { text: "Consider others' feelings", type: "Empathic Nurturer" },
      { text: "Prefer factual decision-making", type: "Mindful Explorer" }
    ]
  },
  {
    id: 4,
    question: "Tell me about a time you and someone you cared about had a disagreement. How would you handle it?",
    options: [
      { text: "Use spiritual guidance to find harmony", type: "Mystic Healer" },
      { text: "Listen deeply and guide towards understanding", type: "Spiritual Guide" },
      { text: "Focus on emotional healing and empathy", type: "Empathic Nurturer" },
      { text: "Analyze the situation objectively", type: "Mindful Explorer" }
    ]
  },
  {
    id: 5,
    type: "metaphysical",
    question: "What role does spirituality or a connection to a higher power play in your life?",
    ratingLabels: {
      1: "Not important",
      5: "Central to life",
      10: "Deeply spiritual"
    },
    isRating: true
  },
  {
    id: 6,
    type: "metaphysical",
    question: "Do you believe in concepts like destiny, synchronicity, or that everything happens for a reason?",
    ratingLabels: {
      1: "Skeptical",
      5: "Open-minded",
      10: "Strong believer"
    },
    isRating: true
  },
  {
    id: 7,
    type: "metaphysical",
    question: "How do you rely on intuition when making decisions?",
    ratingLabels: {
      1: "Rarely",
      5: "Sometimes",
      10: "Always"
    },
    isRating: true
  },
  {
    id: 8,
    type: "metaphysical",
    question: "How strongly do you feel connected to nature and the universe?",
    ratingLabels: {
      1: "Little connection",
      5: "Moderate connection",
      10: "Deep connection"
    },
    isRating: true
  },
  {
    id: 9,
    type: "metaphysical",
    question: "How frequently do you engage in spiritual practices (meditation, yoga, etc.)?",
    ratingLabels: {
      1: "Never",
      5: "Occasionally",
      10: "Daily"
    },
    isRating: true
  },
  {
    id: 10,
    question: "How do you interpret dreams or symbols in your daily life?",
    options: [
      { text: "They carry profound spiritual messages", type: "Mystic Healer" },
      { text: "Tools for personal insight", type: "Spiritual Guide" },
      { text: "Reflections of emotional states", type: "Empathic Nurturer" },
      { text: "Interesting psychological phenomena", type: "Mindful Explorer" }
    ]
  },
  {
    id: 11,
    question: "Describe how you show support for others without being asked.",
    options: [
      { text: "Offer spiritual guidance and healing", type: "Mystic Healer" },
      { text: "Share wisdom and life lessons", type: "Spiritual Guide" },
      { text: "Provide emotional comfort and care", type: "Empathic Nurturer" },
      { text: "Give practical advice and solutions", type: "Mindful Explorer" }
    ]
  }
];

export default function QuizVisual() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{[key: number]: number | string}>({});
  const [results, setResults] = useState<{type: string, score: number}[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const handleRatingChange = (value: number) => {
    setAnswers(prev => ({ ...prev, [currentQuestion]: value }));
  };

  const handleAnswer = async (type?: string) => {
    if (isSubmitting) return;

    let newAnswers = answers;

    // If type is provided, it's a multiple choice answer
    if (type) {
      newAnswers = { ...answers, [currentQuestion]: type };
      setAnswers(newAnswers);
    }

    // Check if this is the last question
    if (currentQuestion === quizQuestions.length - 1) {
      try {
        setIsSubmitting(true);
        toast({
          title: "Saving Results",
          description: "Please wait while we save your quiz results...",
        });

        // Validate that we have all required answers
        const unansweredQuestions = quizQuestions.filter((_, index) => !newAnswers[index]);
        if (unansweredQuestions.length > 0) {
          throw new Error('Please answer all questions before submitting');
        }

        // Filter out the rating questions to count only personality type answers
        const personalityAnswers = Object.entries(newAnswers).reduce((acc: Record<string, string>, [qId, answer]) => {
          const question = quizQuestions[parseInt(qId)];
          if (!question.isRating && typeof answer === 'string') {
            acc[qId] = answer;
          }
          return acc;
        }, {});

        const typeCounts = Object.values(personalityAnswers).reduce((acc: Record<string, number>, type) => {
          acc[type] = (acc[type] || 0) + 1;
          return acc;
        }, {});

        // Calculate personality type scores
        const personalityQuestions = quizQuestions.filter(q => !q.isRating);
        const totalTypeQuestions = personalityQuestions.length;

        const calculatedResults = [
          { type: "Mystic Healer", score: (typeCounts["Mystic Healer"] || 0) * (100 / totalTypeQuestions) },
          { type: "Spiritual Guide", score: (typeCounts["Spiritual Guide"] || 0) * (100 / totalTypeQuestions) },
          { type: "Empathic Nurturer", score: (typeCounts["Empathic Nurturer"] || 0) * (100 / totalTypeQuestions) },
          { type: "Mindful Explorer", score: (typeCounts["Mindful Explorer"] || 0) * (100 / totalTypeQuestions) }
        ];

        setResults(calculatedResults);

        const dominantType = calculatedResults.reduce((max, current) => 
          current.score > max.score ? current : max
        ).type;

        // Get metaphysical scores from rating questions
        const metaphysicalScores = Object.entries(newAnswers).reduce((acc: Record<string, number>, [qId, value]) => {
          const question = quizQuestions[parseInt(qId)];
          if (question?.type === 'metaphysical' && typeof value === 'number') {
            acc[`question_${qId}`] = value;
          }
          return acc;
        }, {});

        // Validate the required data
        if (!dominantType || !metaphysicalScores || Object.keys(metaphysicalScores).length === 0) {
          throw new Error('Missing required quiz data');
        }

        // Add retry logic with exponential backoff
        let retries = 3;
        let success = false;
        let lastError;
        let delay = 1000; // Start with 1 second delay

        while (retries > 0 && !success) {
          try {
            const response = await axios.patch("/api/user/quiz", {
              type: dominantType,
              metaphysicalScores,
              quizResults: typeCounts
            }, {
              headers: {
                'Content-Type': 'application/json'
              },
              timeout: 15000, // 15 second timeout
              withCredentials: true // Important: include credentials
            });

            if (response.status === 200) {
              success = true;
              setShowResults(true);
              toast({
                title: "Quiz Complete!",
                description: "Your spiritual profile has been saved.",
              });
            }
          } catch (error: any) {
            lastError = error;
            retries--;
            if (retries > 0) {
              await new Promise(resolve => setTimeout(resolve, delay));
              delay *= 2; // Exponential backoff
            }
          }
        }

        if (!success) {
          throw lastError || new Error('Failed to save quiz results after multiple attempts');
        }

      } catch (error: any) {
        console.error("Failed to save quiz results:", error);
        toast({
          title: "Error Saving Results",
          description: error.message || "Failed to save your quiz results. Please try again.",
          variant: "destructive",
        });
        // Reset submission state but keep the answers
        setIsSubmitting(false);
        return;
      } finally {
        setIsSubmitting(false);
      }
    } else {
      // Move to next question
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (isSubmitting) return;

    const currentAnswer = answers[currentQuestion];
    if (currentAnswer === undefined) {
      toast({
        title: "Please answer the question",
        description: "Select an option or provide a rating before continuing.",
        variant: "destructive",
      });
      return;
    }

    // For rating questions, directly call handleAnswer
    if (quizQuestions[currentQuestion].isRating) {
      handleAnswer();
    } else {
      // For multiple choice questions, pass the current answer as the type
      handleAnswer(currentAnswer as string);
    }
  };

  const restartQuiz = () => {
    if (isSubmitting) return;
    setCurrentQuestion(0);
    setAnswers({});
    setResults([]);
    setShowResults(false);
  };

  const currentQuestionData = quizQuestions[currentQuestion];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-background via-background/95 to-primary/10 p-4 relative overflow-hidden">
      <h1 className="text-4xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70 relative z-10">
        Discover Your Spiritual Match
      </h1>

      <AnimatePresence mode="wait">
        {!showResults ? (
          <motion.div
            key="quiz"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-2xl relative z-10"
          >
            <Card className="backdrop-blur-xl bg-background/80 border-primary/20 shadow-xl">
              <CardContent className="p-6">
                <motion.div
                  key={currentQuestion}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-semibold mb-6 text-white">
                    {currentQuestionData.question}
                  </h2>

                  {currentQuestionData.isRating ? (
                    <div className="space-y-8">
                      <Slider
                        defaultValue={[answers[currentQuestion] as number || 5]}
                        max={10}
                        min={1}
                        step={1}
                        onValueChange={(value) => handleRatingChange(value[0])}
                        className="touch-none"
                      />
                      <div className="flex justify-between text-sm text-white/60">
                        <span>{currentQuestionData.ratingLabels[1]}</span>
                        <span>{currentQuestionData.ratingLabels[5]}</span>
                        <span>{currentQuestionData.ratingLabels[10]}</span>
                      </div>
                      <Button
                        className="mt-6 w-full bg-primary hover:bg-primary/80"
                        onClick={handleNext}
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          "Processing..."
                        ) : (
                          currentQuestion < quizQuestions.length - 1 ? "Next" : "Complete"
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {currentQuestionData.options?.map((option, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <Button
                            variant="outline"
                            className="w-full text-left p-4 hover:bg-primary/10 border-primary/20 touch-manipulation"
                            onClick={() => handleAnswer(option.type)}
                            disabled={isSubmitting}
                          >
                            {option.text}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  <div className="mt-4 flex gap-1">
                    {Array.from({ length: quizQuestions.length }).map((_, i) => (
                      <motion.div
                        key={i}
                        className={`h-1 w-8 rounded-full ${i <= currentQuestion ? 'bg-primary' : 'bg-primary/20'}`}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                      />
                    ))}
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="w-full max-w-2xl relative z-10"
          >
            <Card className="backdrop-blur-xl bg-background/80 border-primary/20 shadow-xl">
              <CardContent className="p-6">
                <h2 className="text-2xl font-semibold mb-6 text-white text-center">
                  Your Spiritual Profile
                </h2>
                <div className="w-full h-[400px] flex justify-center">
                  <RadialBarChart
                    width={500}
                    height={300}
                    innerRadius="10%"
                    outerRadius="80%"
                    data={results}
                    startAngle={180}
                    endAngle={0}
                  >
                    <RadialBar
                      background
                      dataKey="score"
                      cornerRadius={15}
                      label={{ fill: '#666', position: 'inside' }}
                    />
                    <Legend />
                    <Tooltip />
                  </RadialBarChart>
                </div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <Button 
                    className="mt-6 w-full bg-primary hover:bg-primary/80 transition-all duration-300"
                    onClick={restartQuiz}
                    disabled={isSubmitting}
                  >
                    Take Quiz Again
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}