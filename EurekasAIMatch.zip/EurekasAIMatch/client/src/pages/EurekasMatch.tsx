import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import axios from "axios";

export default function EurekasMatch() {
  const [availableProfiles, setAvailableProfiles] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [match, setMatch] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const currentUser = availableProfiles[currentIndex];
  const hasMoreProfiles = currentIndex < availableProfiles.length;

  // WebSocket connection for real-time match notifications
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'match') {
        toast({
          title: "New Match!",
          description: `You matched with ${data.match.name}!`,
        });
      }
    };

    return () => socket.close();
  }, []);

  // Show no profiles message only when profiles are loaded and none are available
  useEffect(() => {
    if (!isLoading && availableProfiles.length === 0) {
      toast({
        title: "No Profiles Available",
        description: "Check back later for new matches!",
      });
    }
  }, [isLoading, availableProfiles.length]);

  // Fetch profiles
  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        const response = await axios.get("/api/users");
        setAvailableProfiles(response.data);
      } catch (error) {
        console.error("Error fetching profiles:", error);
        toast({
          title: "Error",
          description: "Failed to load profiles. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchProfiles();
  }, []);

  // Handle swipe action
  const handleSwipe = async (direction) => {
    if (!currentUser) return;

    try {
      const response = await axios.post("/api/match", {
        targetUserId: currentUser.id,
        action: direction
      });

      setMatch(response.data.match);
      setCurrentIndex(prev => prev + 1);

      // Show message when no more profiles after this swipe
      if (currentIndex === availableProfiles.length - 1) {
        toast({
          title: "No More Profiles",
          description: "You've seen all available profiles. Check back later for new matches!",
        });
      }
    } catch (error) {
      console.error("Error handling swipe:", error);
      toast({
        title: "Error",
        description: "Failed to process your selection. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!hasMoreProfiles) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
        <img
          src="/logo.png"
          alt="EurekasMatch"
          className="w-24 h-24 mb-4"
        />
        <Card className="relative w-full max-w-md backdrop-blur-xl bg-background/60 border-primary/20 shadow-[0_0_15px_rgba(236,72,153,0.3)] rounded-[20px] p-8">
          <CardContent className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-white">No More Profiles</h2>
            <p className="text-white/80 mb-6">You've seen all available profiles. Take the personality quiz to find better matches!</p>
            <Button
              variant="default"
              className="w-full bg-primary hover:bg-primary/80 transition-all duration-300"
              onClick={() => setLocation("/quiz")}
            >
              Take Personality Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 p-4">
      <img
        src="/logo.png"
        alt="EurekasMatch"
        className="w-24 h-24 mb-4"
      />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        <div className="absolute -inset-1 bg-gradient-to-r from-primary/30 via-primary/10 to-primary/30 rounded-[22px] blur-lg" />
        <Card className="relative w-full h-[600px] backdrop-blur-xl bg-background/60 border-primary/20 shadow-[0_0_15px_rgba(236,72,153,0.3)] rounded-[20px] overflow-hidden">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full flex flex-col items-center justify-center p-6"
          >
            {currentUser && (
              <>
                <motion.div
                  className="relative mb-6"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-full blur-md" />
                  <img
                    src={currentUser.image}
                    alt={currentUser.name}
                    className="relative w-48 h-48 rounded-full object-cover border-2 border-primary/50"
                  />
                </motion.div>

                <CardContent className="text-center z-10">
                  <h2 className="text-2xl font-bold mb-2 text-white">{currentUser.name}, {currentUser.age}</h2>
                  <p className="text-white/80 mb-4">{currentUser.bio}</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30">
                      {currentUser.type}
                    </span>
                    {currentUser.spiritualColor && (
                      <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30 capitalize">
                        {currentUser.spiritualColor} Aura
                      </span>
                    )}
                    {currentUser.genderIdentity && (
                      <span className="inline-block bg-primary/20 text-primary px-4 py-1.5 rounded-full text-sm backdrop-blur-sm border border-primary/30 capitalize">
                        {currentUser.genderIdentity}
                      </span>
                    )}
                  </div>
                </CardContent>

                <div className="flex justify-between w-full mt-8 gap-4">
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => handleSwipe("left")}
                    className="w-full border-primary/20 hover:bg-primary/20 backdrop-blur-sm transition-all duration-300"
                  >
                    Pass
                  </Button>
                  <Button
                    variant="default"
                    size="lg"
                    onClick={() => handleSwipe("right")}
                    className="w-full bg-primary hover:bg-primary/80 transition-all duration-300"
                  >
                    Match
                  </Button>
                </div>
              </>
            )}
          </motion.div>
        </Card>
      </motion.div>
    </div>
  );
}