import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { generateAvatar } from "@/lib/avatar-generator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formError, setFormError] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [userLocation, setUserLocation] = useState("");
  const [genderIdentity, setGenderIdentity] = useState<"Stud" | "Femme" | null>(null);
  const { loginMutation, registerMutation, user } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const validateForm = () => {
    setFormError("");

    if (!username.trim()) {
      setFormError("Username is required");
      return false;
    }

    if (!password.trim()) {
      setFormError("Password is required");
      return false;
    }

    if (password.length < 6) {
      setFormError("Password must be at least 6 characters");
      return false;
    }

    if (!isLogin) {
      if (!name.trim()) {
        setFormError("Name is required");
        return false;
      }

      if (!age) {
        setFormError("Age is required");
        return false;
      }

      const ageNum = parseInt(age);
      if (isNaN(ageNum) || ageNum < 18 || ageNum > 120) {
        setFormError("Please enter a valid age (18-120)");
        return false;
      }

      if (!userLocation.trim()) {
        setFormError("Location is required");
        return false;
      }

      if (!genderIdentity) {
        setFormError("Please select your gender identity");
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (isLogin) {
        await loginMutation.mutate({ username: username.trim(), password });
      } else {
        if (!genderIdentity) return;
        const ageNum = parseInt(age);
        await registerMutation.mutate({
          username: username.trim(),
          password,
          name: name.trim(),
          age: ageNum,
          location: userLocation.trim(),
          genderIdentity,
          bio: "",
          image: generateAvatar(),
          type: "",
          subscriptionStatus: "free",
          spiritualColor: "",
          email: "",
          phoneNumber: "",
          physicalAddress: "",
          quizResults: {},
          metaphysicalScores: {},
          stripeCustomerId: "",
          quizTimestamp: null,
          subscriptionExpiresAt: null
        });
      }
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "An unexpected error occurred");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/10 flex">
      {/* Left side - Form */}
      <div className="w-full md:w-1/2 p-4 flex items-center justify-center">
        <Card className="w-full max-w-md backdrop-blur-xl bg-background/60 border-primary/20">
          <CardContent className="p-6">
            <div className="flex justify-center mb-6">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              >
                <img src="/static/eureka-match-logo.png" alt="EurekasMatch" className="w-16 h-16" />
              </motion.div>
            </div>
            <h1 className="text-2xl font-bold text-center mb-6 text-white">
              {isLogin ? "Welcome Back" : "Join EurekasMatch"}
            </h1>
            {formError && (
              <div className="mb-4 p-2 text-sm text-red-500 bg-red-500/10 rounded">
                {formError}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-background/50 border-primary/20"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-background/50 border-primary/20"
              />
              {isLogin && (
                <div className="text-sm text-right">
                  <Link href="/reset-password" className="text-primary hover:text-primary/80">
                    Forgot Password?
                  </Link>
                </div>
              )}
              {!isLogin && (
                <>
                  <Input
                    placeholder="Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <Input
                    type="number"
                    placeholder="Age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <Input
                    placeholder="Location"
                    value={userLocation}
                    onChange={(e) => setUserLocation(e.target.value)}
                    className="bg-background/50 border-primary/20"
                  />
                  <Select
                    value={genderIdentity || undefined}
                    onValueChange={(value: "Stud" | "Femme") => setGenderIdentity(value)}
                  >
                    <SelectTrigger className="bg-background/50 border-primary/20">
                      <SelectValue placeholder="Select Gender Identity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Stud">Stud</SelectItem>
                      <SelectItem value="Femme">Femme</SelectItem>
                    </SelectContent>
                  </Select>
                </>
              )}
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/80"
                disabled={loginMutation.isPending || registerMutation.isPending}
              >
                {isLogin ? "Login" : "Register"}
              </Button>
            </form>
            <p className="text-center mt-4 text-white/60">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-2 text-primary hover:text-primary/80"
              >
                {isLogin ? "Register" : "Login"}
              </button>
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Right side - Hero */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-primary/20 to-primary/5 items-center justify-center p-12">
        <div className="max-w-lg text-center space-y-6">
          <h2 className="text-4xl font-bold mb-6 text-white">
            Discover Your Soul's Perfect Match
          </h2>
          <p className="text-lg text-white/80 mb-4">
            Welcome to EurekasMatch – where modern dating meets spiritual wisdom. We go beyond
            superficial swipes to connect kindred spirits through our unique blend of emotional
            intelligence, aura matching, and metaphysical compatibility.
          </p>
          <div className="space-y-4 text-white/70">
            <p className="italic">
              "Two souls don't find each other by simple accident." - Jorge Luis Borges
            </p>
            <p className="text-sm">
              In a world of fleeting connections, we believe in the power of authentic spiritual bonds.
              Our AI-powered matching system considers your unique energy, personality archetype, and
              spiritual wavelength to find connections that resonate on a deeper level.
            </p>
            <p className="text-sm">
              Whether you're a Mystic Healer, Mindful Explorer, or Spiritual Guide, your perfect match
              awaits – someone who truly sees and appreciates your inner radiance.
            </p>
            <p className="text-sm mt-4 text-primary/90">
              Join our community of conscious daters and experience dating that honors both your heart
              and soul. ✨
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}