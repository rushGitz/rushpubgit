import { nanoid } from 'nanoid';

const animals = ['🐱', '🐶', '🐰', '🐼', '🦊', '🐨', '🐯', '🦁', '🐸', '🐹', '🦉', '🦝', '🐻', '🐷'];
const colors = [
  '#FFB5E8', // pastel pink
  '#B5B9FF', // pastel blue
  '#B5FFB9', // pastel green
  '#FFB8B5', // pastel red
  '#FFF3B5', // pastel yellow
  '#E7B5FF', // pastel purple
];

export function generateAvatar(): string {
  const animal = animals[Math.floor(Math.random() * animals.length)];
  const color = colors[Math.floor(Math.random() * colors.length)];
  const id = nanoid(6);

  // Create a data URL for a simple SVG with the animal emoji on a colored background
  const svg = `
    <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="${color}"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="100px">
        ${animal}
      </text>
    </svg>
  `;

  // Convert to base64 using TextEncoder and Uint8Array
  const encoder = new TextEncoder();
  const bytes = encoder.encode(svg);
  const base64 = btoa(String.fromCharCode(...new Uint8Array(bytes)));

  return `data:image/svg+xml;base64,${base64}`;
}