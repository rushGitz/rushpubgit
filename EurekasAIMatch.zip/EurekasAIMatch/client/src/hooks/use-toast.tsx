import { toast as sonnerToast } from "sonner";

export function useToast() {
  return {
    toast: ({ title, description, variant = "default", duration = 5000 }) => {
      sonnerToast[variant === "destructive" ? "error" : "success"](title, {
        description,
        duration, // Default 5 seconds auto-dismiss
        dismissible: true,
      });
    },
  };
}