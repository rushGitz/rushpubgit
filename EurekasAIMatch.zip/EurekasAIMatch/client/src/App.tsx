import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { NavBar } from "@/components/NavBar";
import NotFound from "@/pages/not-found";
import EurekasMatch from "@/pages/EurekasMatch";
import QuizVisual from "@/pages/QuizVisual";
import Dashboard from "@/pages/Dashboard";
import Profile from "@/pages/Profile";
import AuthPage from "@/pages/auth-page";
import AIMatchmaker from "@/pages/AIMatchmaker";
import PersonalityInsights from "@/pages/PersonalityInsights";
import PersonalityCompatibility from "@/pages/PersonalityCompatibility";
import ResetPassword from "@/pages/reset-password";
import Preferences from "@/pages/Preferences";
import DateNightCalendar from "@/pages/DateNightCalendar";
import { ProtectedRoute } from "@/lib/protected-route";

function Router() {
  return (
    <div className="pt-16">
      <NavBar />
      <Switch>
        <ProtectedRoute path="/" component={EurekasMatch} />
        <ProtectedRoute path="/quiz" component={QuizVisual} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/profile" component={Profile} />
        <ProtectedRoute path="/preferences" component={Preferences} />
        <ProtectedRoute path="/ai-matchmaker" component={AIMatchmaker} />
        <ProtectedRoute path="/insights" component={PersonalityInsights} />
        <ProtectedRoute path="/personality-compatibility" component={PersonalityCompatibility} />
        <ProtectedRoute path="/datenightcalendar" component={DateNightCalendar} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/reset-password" component={ResetPassword} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;