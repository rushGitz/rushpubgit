import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { FaUserCircle, FaBars } from "react-icons/fa";
import { useAuth } from "@/hooks/use-auth";
import { motion, AnimatePresence } from "framer-motion";

export function NavBar() {
  const { user, logoutMutation } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Helper function to close menu
  const handleNavigate = () => {
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 backdrop-blur-xl bg-background/60 border-b border-primary/20 shadow-[0_0_15px_rgba(236,72,153,0.2)] z-50">
      <div className="max-w-screen-xl mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" onClick={handleNavigate}>
            <Button variant="link" className="flex items-center space-x-2 text-2xl font-bold group p-0">
              <img 
                src="/logo.png"
                alt="EurekasMatch"
                className="w-8 h-8 transition-transform group-hover:scale-110"
              />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70 group-hover:to-primary transition-all duration-300">
                Eurekas<span className="text-primary">Match</span>
              </span>
            </Button>
          </Link>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-primary/10 rounded-lg transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <FaBars className="h-6 w-6 text-primary" />
          </button>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <>
                <Link href="/">
                  <Button variant="ghost" className="hover:bg-primary/20 transition-all duration-300">
                    Match
                  </Button>
                </Link>
                <Link href="/quiz">
                  <Button variant="ghost" className="hover:bg-primary/20 transition-all duration-300">
                    Personality Quiz
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="ghost" className="hover:bg-primary/20 transition-all duration-300">
                    Dashboard
                  </Button>
                </Link>
                <div className="h-6 w-px bg-primary/20" />
                <Link href="/profile">
                  <Button variant="ghost" className="hover:bg-primary/20 transition-all duration-300 flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={user.image} alt={user.name || "User avatar"} />
                      <AvatarFallback>
                        <FaUserCircle className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    Profile
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="border-primary/20 hover:bg-primary/20"
                  onClick={() => logoutMutation.mutate()}
                >
                  Logout
                </Button>
              </>
            ) : (
              <Link href="/auth">
                <Button className="bg-primary hover:bg-primary/80 transition-all duration-300">
                  Login / Register
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Mobile Menu Panel */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden pt-4"
            >
              <div className="flex flex-col gap-2">
                {user ? (
                  <>
                    <Link href="/" onClick={handleNavigate}>
                      <Button variant="ghost" className="w-full justify-start hover:bg-primary/20">
                        Match
                      </Button>
                    </Link>
                    <Link href="/quiz" onClick={handleNavigate}>
                      <Button variant="ghost" className="w-full justify-start hover:bg-primary/20">
                        Personality Quiz
                      </Button>
                    </Link>
                    <Link href="/dashboard" onClick={handleNavigate}>
                      <Button variant="ghost" className="w-full justify-start hover:bg-primary/20">
                        Dashboard
                      </Button>
                    </Link>
                    <div className="h-px w-full bg-primary/20 my-2" />
                    <Link href="/profile" onClick={handleNavigate}>
                      <Button variant="ghost" className="w-full justify-start hover:bg-primary/20 flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={user.image} alt={user.name || "User avatar"} />
                          <AvatarFallback>
                            <FaUserCircle className="h-4 w-4" />
                          </AvatarFallback>
                        </Avatar>
                        Profile
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      className="w-full justify-start border-primary/20 hover:bg-primary/20"
                      onClick={() => {
                        logoutMutation.mutate();
                        handleNavigate();
                      }}
                    >
                      Logout
                    </Button>
                  </>
                ) : (
                  <Link href="/auth" onClick={handleNavigate}>
                    <Button className="w-full bg-primary hover:bg-primary/80">
                      Login / Register
                    </Button>
                  </Link>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}