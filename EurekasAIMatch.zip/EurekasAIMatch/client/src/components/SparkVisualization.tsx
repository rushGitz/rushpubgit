import { motion } from "framer-motion";

interface SparkVisualizationProps {
  compatibility: number; // Value between 0 and 1
}

export function SparkVisualization({ compatibility }: SparkVisualizationProps) {
  // Calculate the number of symbols based on compatibility
  // For matches under 50%, show fewer symbols
  const symbolCount = compatibility < 0.5 
    ? Math.max(1, Math.floor(compatibility * 5)) 
    : Math.max(2, Math.floor(compatibility * 10));

  // Adjust animation duration and delay based on compatibility
  const getAnimationConfig = (index: number) => {
    const isLowMatch = compatibility < 0.5;
    return {
      duration: isLowMatch ? 1.5 : 2 + Math.random(),
      repeatDelay: isLowMatch ? 3 + Math.random() * 2 : Math.random() * 2,
      scale: isLowMatch ? [0, 0.8, 0] : [0, 1.2, 0],
    };
  };

  return (
    <div className="relative h-12 w-full overflow-hidden">
      {Array.from({ length: symbolCount }).map((_, i) => {
        const animConfig = getAnimationConfig(i);
        return (
          <motion.div
            key={i}
            className="absolute text-lg"
            initial={{
              x: "0%",
              y: "100%",
              opacity: 0,
              scale: 0,
            }}
            animate={{
              x: [
                `${Math.random() * 100}%`,
                `${Math.random() * 100}%`,
                `${Math.random() * 100}%`,
              ],
              y: ["100%", "0%", "-100%"],
              opacity: [0, 1, 0],
              scale: animConfig.scale,
            }}
            transition={{
              duration: animConfig.duration,
              repeat: Infinity,
              repeatDelay: animConfig.repeatDelay,
              ease: "easeInOut",
            }}
          >
            <div 
              className="flex items-center justify-center text-primary"
              style={{
                textShadow: "0 0 10px var(--primary), 0 0 20px var(--primary)",
                fontSize: `${1 + Math.random() * 0.5}em`,
                opacity: compatibility < 0.5 ? 0.7 : 1, // Reduce opacity for low matches
              }}
            >
              {i % 2 === 0 ? "❤️" : "🧠"}
            </div>
          </motion.div>
        )
      })}
    </div>
  );
}