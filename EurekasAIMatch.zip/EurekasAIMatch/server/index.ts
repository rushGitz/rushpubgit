import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { setupAuth } from "./auth";
import session from 'express-session';
import { storage } from "./storage";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();

// Trust proxy in production
if (app.get("env") === "production") {
  app.set("trust proxy", 1);
}

// Add JSON parsing middleware with error handling
// Skip JSON parsing for Stripe webhook routes
app.use((req, res, next) => {
  if (req.path === '/api/webhook' || req.path.startsWith('/api/stripe-webhook')) {
    next();
  } else {
    express.json({
      verify: (req, res, buf) => {
        try {
          JSON.parse(buf.toString());
        } catch (e) {
          console.error('JSON Parse Error:', e);
          res.status(400).json({ 
            message: 'Invalid JSON payload',
            details: process.env.NODE_ENV === 'development' ? e.message : undefined
          });
          throw new Error('Invalid JSON');
        }
      }
    })(req, res, next);
  }
});

app.use(express.urlencoded({ extended: false }));

// Configure static file serving with proper MIME types
app.use('/static', express.static(path.resolve(__dirname, '../static'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.png')) {
      res.setHeader('Content-Type', 'image/png');
    }
  }
}));

// Global error handler - ensure we always return JSON
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Error:', err);
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ 
    message,
    error: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

// Add request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Configure session middleware with secure settings
    const sessionMiddleware = session({
      secret: process.env.REPL_ID!,
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore,
      cookie: {
        secure: app.get("env") === "production",
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        path: '/'
      },
      name: 'eurekasMatch.sid' // Custom session name
    });

    // Apply session middleware before passport
    app.use(sessionMiddleware);

    // Set up authentication after session
    setupAuth(app);

    // Register routes and get server instance
    const server = registerRoutes(app, sessionMiddleware);

    // In production, serve static files from both dist/public and client/public
    if (app.get("env") === "production") {
      app.use(express.static(path.resolve(__dirname, "public")));
      app.use(express.static(path.resolve(__dirname, "../client/public")));
      app.use("*", (_req, res) => {
        res.sendFile(path.resolve(__dirname, "public/index.html"));
      });
    } else {
      await setupVite(app, server);
    }

    // ALWAYS serve the app on port 5000
    const PORT = 5000;
    server.listen(PORT, "0.0.0.0", () => {
      log(`Server started on port ${PORT} in ${app.get("env")} mode`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
})();