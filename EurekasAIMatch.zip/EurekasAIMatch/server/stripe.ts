import Stripe from 'stripe';
import { storage } from './storage';
import { db } from './db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';

// Initialize Stripe with proper configuration
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
  appInfo: {
    name: 'EurekasMatch',
    version: '1.0.0'
  },
  typescript: true,
});

// Price ID for the monthly subscription - $9.99
const SUBSCRIPTION_PRICE_ID = process.env.STRIPE_PRICE_ID || 'price_H5ggYwtDq4fbrJ'; // Fallback to test price

export async function createSubscription(userId: number, paymentMethodId: string) {
  try {
    // Get or create Stripe customer
    const user = await storage.getUser(userId);
    if (!user) throw new Error('User not found');
    if (!user.email) throw new Error('User email is required for subscription');

    let stripeCustomerId = user.stripeCustomerId;

    // Create or update customer
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        payment_method: paymentMethodId,
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      });
      stripeCustomerId = customer.id;
      await storage.updateStripeCustomerId(userId, stripeCustomerId);
    } else {
      // Update existing customer's payment method
      await stripe.paymentMethods.attach(paymentMethodId, {
        customer: stripeCustomerId,
      });
      await stripe.customers.update(stripeCustomerId, {
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      });
    }

    // Create subscription with support for different payment methods
    const subscription = await stripe.subscriptions.create({
      customer: stripeCustomerId,
      items: [{ price: SUBSCRIPTION_PRICE_ID }],
      payment_behavior: 'default_incomplete',
      payment_settings: {
        payment_method_types: ['card', 'apple_pay', 'google_pay'],
        save_default_payment_method: 'on_subscription',
      },
      expand: ['latest_invoice.payment_intent'],
    });

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;

    // Update user's subscription status
    await storage.updateSubscriptionStatus(
      userId,
      subscription.status,
      new Date(subscription.current_period_end * 1000)
    );

    return {
      subscriptionId: subscription.id,
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error) {
    console.error('[Stripe Error] Error creating subscription:', error);
    throw error;
  }
}

export async function handleSubscriptionWebhook(event: Stripe.Event) {
  try {
    const subscription = event.data.object as Stripe.Subscription;
    const customerId = subscription.customer as string;

    // Find user by Stripe customer ID
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.stripeCustomerId, customerId));

    if (!user) {
      console.error('[Stripe Webhook] User not found for Stripe customer:', customerId);
      return;
    }

    switch (event.type) {
      case 'customer.subscription.updated':
      case 'customer.subscription.created':
        await storage.updateSubscriptionStatus(
          user.id,
          subscription.status,
          new Date(subscription.current_period_end * 1000)
        );
        break;

      case 'customer.subscription.deleted':
        await storage.updateSubscriptionStatus(user.id, 'canceled');
        break;
    }
  } catch (error) {
    console.error('[Stripe Webhook] Error processing webhook:', error);
    throw error;
  }
}