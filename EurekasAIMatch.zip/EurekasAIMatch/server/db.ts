import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// Initialize pool
let pool: Pool | null = null;
let dbInstance: ReturnType<typeof drizzle> | null = null;

// Create and initialize the pool
async function initializePool() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set. Did you forget to provision a database?");
  }

  try {
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    // Test the connection
    const client = await pool.connect();
    client.release();
    console.log('Successfully connected to database');

    // Initialize Drizzle with the pool
    dbInstance = drizzle(pool, { schema });

    // Add connection error handling
    pool.on('error', async (err) => {
      console.error('Unexpected database error:', err);
      // Attempt to reconnect
      try {
        const newPool = new Pool({ connectionString: process.env.DATABASE_URL! });
        const testClient = await newPool.connect();
        testClient.release();

        if (pool) {
          await pool.end();
        }
        pool = newPool;
        dbInstance = drizzle(pool, { schema });
        console.log('Successfully reconnected to database');
      } catch (error) {
        console.error('Failed to reconnect to database:', error);
      }
    });

    return dbInstance;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Initialize the database connection
const dbPromise = initializePool();

// Export an object with async query methods
export const database = {
  async query() {
    const instance = await dbPromise;
    if (!instance) {
      throw new Error('Database not initialized');
    }
    return instance;
  },

  // Helper method to get the current db instance
  async getInstance() {
    return dbPromise;
  },

  // Export pool for session store
  get pool() {
    if (!pool) throw new Error('Database pool not initialized');
    return pool;
  }
};

// For compatibility with existing code
export { pool };
export const db = database;