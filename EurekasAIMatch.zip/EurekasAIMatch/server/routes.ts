import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocket, WebSocketServer } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import type { Request } from "express";
import type { IncomingMessage } from "http";
import { insertUserPreferencesSchema } from "@shared/schema";
import type { SessionMiddleware } from 'express-session';
import { stripe, createSubscription, handleSubscriptionWebhook } from "./stripe";
import express from "express";

// Add environment check helper
const isProduction = process.env.NODE_ENV === 'production';

// Define schemas for quiz validation
const metaphysicalScoresSchema = z.record(z.string(), z.number());
const quizResultsSchema = z.record(z.string(), z.union([z.number(), z.string()]));

// Define session types
interface WebSocketWithSession extends WebSocket {
  userId?: number;
}

interface SessionWithPassport extends IncomingMessage {
  session?: {
    passport?: {
      user?: number;
    };
  };
}

export function registerRoutes(app: Express, sessionMiddleware: SessionMiddleware): Server {
  const httpServer = createServer(app);

  // Set up WebSocket server with specific path and session handling
  const wss = new WebSocketServer({
    noServer: true // Important: Use noServer: true to handle upgrade manually
  });

  // Store active connections with their user IDs
  const connectedClients = new Map<number, WebSocketWithSession>();

  // Handle upgrade manually
  httpServer.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url!, `http://${request.headers.host}`).pathname;

    if (pathname === '/ws') {
      console.log('WebSocket upgrade request received');

      // Apply session middleware
      sessionMiddleware(request as Request, {} as any, () => {
        const req = request as unknown as SessionWithPassport;
        console.log('Session data:', {
          hasSession: !!req.session,
          hasPassport: !!req.session?.passport,
          userId: req.session?.passport?.user,
          cookies: request.headers.cookie
        });

        if (!req.session?.passport?.user) {
          console.log('Unauthorized WebSocket connection attempt - No user in session');
          socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
          socket.destroy();
          return;
        }

        console.log('Authorized WebSocket connection for user:', req.session.passport.user);
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      });
    }
  });

  // Set up auth routes first
  setupAuth(app);

  // Rest of your routes...
  app.get('/api/matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const matches = await storage.getMatches(req.user.id);
    res.json(matches);
  });

  app.get('/api/pending-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    try {
      // Only get pending matches that aren't already matched
      const pendingMatches = await storage.getPendingMatches(req.user.id);
      const matches = await storage.getMatches(req.user.id);

      // Filter out any pending matches that are now full matches
      const matchedIds = new Set(matches.map(m => m.id));
      const filteredPending = pendingMatches.filter(p => !matchedIds.has(p.id));

      res.json(filteredPending);
    } catch (error) {
      console.error('Error fetching pending matches:', error);
      res.status(500).json({
        message: "Failed to fetch pending matches",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get('/api/passes', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const passes = await storage.getPasses(req.user.id);
    res.json(passes);
  });

  app.get('/api/messages/:userId', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const otherUserId = parseInt(req.params.userId);
    const messages = await storage.getMessages(req.user.id, otherUserId);
    res.json(messages);
  });

  app.post('/api/messages', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { receiverId, content } = req.body;

    const message = await storage.createMessage({
      senderId: req.user.id,
      receiverId,
      content
    });

    // Send message only to the sender and receiver
    const receiverWs = connectedClients.get(receiverId);
    const senderWs = connectedClients.get(req.user.id);

    const messageData = JSON.stringify({
      type: 'chat',
      senderId: req.user.id,
      receiverId,
      message
    });

    // Send to receiver if they're connected
    if (receiverWs?.readyState === WebSocket.OPEN) {
      receiverWs.send(messageData);
    }

    // Send to sender to confirm delivery
    if (senderWs?.readyState === WebSocket.OPEN) {
      senderWs.send(messageData);
    }

    res.json(message);
  });

  app.patch('/api/user/quiz', async (req, res) => {
    if (!req.user) {
      console.error('Unauthorized quiz update attempt');
      return res.status(401).json({
        message: "Please log in to save quiz results",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      console.log('Received quiz update request for user:', req.user.id);
      console.log('Quiz data:', req.body);
      const { type, metaphysicalScores, quizResults } = req.body;

      // Validate required fields
      if (!type || !metaphysicalScores || !quizResults) {
        console.error('Missing required quiz fields:', { type, metaphysicalScores, quizResults });
        return res.status(400).json({
          message: "Missing required quiz data",
          code: "INVALID_QUIZ_DATA"
        });
      }

      // Validate metaphysical scores
      const parsedScores = metaphysicalScoresSchema.safeParse(metaphysicalScores);
      if (!parsedScores.success) {
        console.error('Invalid metaphysical scores format:', metaphysicalScores);
        return res.status(400).json({
          message: "Invalid metaphysical scores format",
          details: parsedScores.error.errors,
          code: "INVALID_SCORES"
        });
      }

      // Validate quiz results
      const parsedResults = quizResultsSchema.safeParse(quizResults);
      if (!parsedResults.success) {
        console.error('Invalid quiz results format:', quizResults);
        return res.status(400).json({
          message: "Invalid quiz results format",
          details: parsedResults.error.errors,
          code: "INVALID_RESULTS"
        });
      }

      // Update user with quiz results
      const updatedUser = await storage.updateUserWithQuizResults(req.user.id, {
        type,
        metaphysicalScores: parsedScores.data,
        quizResults: parsedResults.data,
        quizTimestamp: new Date()
      });

      if (!updatedUser) {
        console.error('User not found or update failed:', req.user.id);
        return res.status(404).json({
          message: "User not found or update failed",
          code: "UPDATE_FAILED"
        });
      }

      console.log('Successfully updated user quiz results:', updatedUser.id);

      // Return the updated user without sensitive information
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user quiz results:', error);
      res.status(500).json({
        message: "Failed to update quiz results",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "SERVER_ERROR"
      });
    }
  });

  app.get('/api/user', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove sensitive information before sending
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });

  app.get('/api/compatible-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const threshold = req.query.threshold ? parseFloat(req.query.threshold as string) : 0.7;
      const compatibleUsers = await storage.findCompatibleUsers(req.user.id, threshold);
      res.json(compatibleUsers);
    } catch (error) {
      console.error('Error finding compatible matches:', error);
      res.status(500).json({ message: "Failed to find compatible matches" });
    }
  });

  app.get('/api/users', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const unseenUsers = await storage.getUnseenUsers(req.user.id);
    res.json(unseenUsers);
  });

  app.post('/api/match', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { targetUserId, action } = req.body;

    try {
      // Validate input
      if (!targetUserId || !action) {
        return res.status(400).json({
          message: "Missing required fields",
          code: "INVALID_INPUT"
        });
      }

      // Record the user's selection
      await storage.recordUserSelection({
        userId: req.user.id,
        targetUserId,
        liked: action === 'right'
      });

      if (action === 'right') {
        // Check for mutual match
        const hasMatch = await storage.checkForMutualMatch(req.user.id, targetUserId);

        if (hasMatch) {
          // Create a match record
          const match = await storage.createMatch({
            user1Id: req.user.id,
            user2Id: targetUserId,
            matchedAt: new Date()
          });

          // Get matched user details
          const matchedUser = await storage.getUser(targetUserId);
          if (!matchedUser) {
            throw new Error('Matched user not found');
          }

          // Notify both users via WebSocket
          const matchNotification = JSON.stringify({
            type: 'match',
            match: {
              id: matchedUser.id,
              name: matchedUser.name,
              image: matchedUser.image,
              location: matchedUser.location
            }
          });

          // Send to both users if connected
          const receiverWs = connectedClients.get(targetUserId);
          const senderWs = connectedClients.get(req.user.id);

          if (receiverWs?.readyState === WebSocket.OPEN) {
            receiverWs.send(matchNotification);
          }

          if (senderWs?.readyState === WebSocket.OPEN) {
            senderWs.send(matchNotification);
          }

          return res.json({ match: matchedUser });
        } else {
          // Create pending match
          await storage.createPendingMatch({
            userId: req.user.id,
            targetUserId,
            createdAt: new Date()
          });
          return res.json({ match: null });
        }
      } else {
        // Record pass
        await storage.createPass({
          userId: req.user.id,
          targetUserId,
          createdAt: new Date()
        });
        return res.json({ match: null });
      }
    } catch (error) {
      console.error('Error in match processing:', error);
      res.status(500).json({
        message: "Failed to process match action",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "MATCH_ERROR"
      });
    }
  });

  app.post('/api/super-matches', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { quizResults } = req.body;

    try {
      // Get all unseen users
      const unseenUsers = await storage.getUnseenUsers(req.user.id);

      // Find best matches for each gender identity
      const studMatches = unseenUsers
        .filter(u => u.genderIdentity === 'Stud')
        .map(user => {
          const userResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          if (!userResults || !quizResults) return null;

          // Calculate compatibility score
          const compatibilityScore = Object.entries(quizResults).reduce((score, [key, value]) => {
            return score + (userResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(quizResults).length;

          return { ...user, compatibility: compatibilityScore };
        })
        .filter(match => match !== null)
        .sort((a, b) => b!.compatibility - a!.compatibility);

      const femmeMatches = unseenUsers
        .filter(u => u.genderIdentity === 'Femme')
        .map(user => {
          const userResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          if (!userResults || !quizResults) return null;

          const compatibilityScore = Object.entries(quizResults).reduce((score, [key, value]) => {
            return score + (userResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(quizResults).length;

          return { ...user, compatibility: compatibilityScore };
        })
        .filter(match => match !== null)
        .sort((a, b) => b!.compatibility - a!.compatibility);

      // Get the top match from each category
      const matches = [
        studMatches[0],
        femmeMatches[0]
      ].filter(match => match !== undefined);

      res.json({ matches });
    } catch (error) {
      console.error('Error finding super matches:', error);
      res.status(500).json({ message: "Failed to find super matches" });
    }
  });

  app.post('/api/ai-match', async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const { quizResults } = req.body;

    try {
      console.log('Received AI match request with quiz results:', quizResults);

      if (!quizResults) {
        return res.status(400).json({
          message: "Quiz results are required",
          code: "MISSING_QUIZ_RESULTS"
        });
      }

      // Get only unseen users for AI matching
      const unseenUsers = await storage.getUnseenUsers(req.user.id);
      console.log(`Found ${unseenUsers.length} unseen users`);

      const compatibleUsers = unseenUsers.filter(user => {
        try {
          // Handle both string and object quiz results
          const userQuizResults = typeof user.quizResults === 'string'
            ? JSON.parse(user.quizResults)
            : user.quizResults;

          const currentUserResults = typeof quizResults === 'string'
            ? JSON.parse(quizResults)
            : quizResults;

          if (!userQuizResults || !currentUserResults) {
            console.log('Missing quiz results for comparison:', {
              userHasResults: !!userQuizResults,
              currentUserHasResults: !!currentUserResults
            });
            return false;
          }

          // Calculate compatibility score
          const compatibilityScore = Object.entries(currentUserResults).reduce((score, [key, value]) => {
            return score + (userQuizResults[key] === value ? 1 : 0);
          }, 0) / Object.keys(currentUserResults).length;

          // Consider users with at least 30% compatibility
          return compatibilityScore >= 0.3;
        } catch (error) {
          console.error('Error comparing quiz results:', error);
          return false;
        }
      });

      console.log(`Found ${compatibleUsers.length} compatible users`);

      if (compatibleUsers.length > 0) {
        // Select a random match from the compatible users
        const match = compatibleUsers[Math.floor(Math.random() * compatibleUsers.length)];
        console.log('Selected match:', match.id);
        res.json({ match });
      } else {
        console.log('No compatible matches found');
        res.json({
          match: null,
          message: "No compatible matches found at this time. Try again later!"
        });
      }
    } catch (error) {
      console.error('Error in AI matching:', error);
      res.status(500).json({
        message: "Failed to process AI matching",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "AI_MATCH_ERROR"
      });
    }
  });


  app.patch('/api/user/profile', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const { image, name, location, genderIdentity, email, phoneNumber, physicalAddress } = req.body;

      // Update user's profile information
      const updatedUser = await storage.updateUserProfile(req.user.id, {
        image,
        name,
        location,
        genderIdentity,
        email,
        phoneNumber,
        physicalAddress
      });

      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Notify connected clients about the user update
      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'user_update',
            userId: req.user.id,
            update: { image, name, location, genderIdentity, email, phoneNumber, physicalAddress }
          }));
        }
      });

      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get('/api/preferences', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const preferences = await storage.getUserPreferences(req.user.id);
      res.json(preferences);
    } catch (error) {
      console.error('Error fetching preferences:', error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.post('/api/preferences', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const parsed = insertUserPreferencesSchema.safeParse({
        ...req.body,
        userId: req.user.id
      });

      if (!parsed.success) {
        return res.status(400).json({
          message: "Invalid preferences data",
          errors: parsed.error.errors
        });
      }

      const preferences = await storage.upsertUserPreferences(parsed.data);
      res.json(preferences);
    } catch (error) {
      console.error('Error saving preferences:', error);
      res.status(500).json({ message: "Failed to save preferences" });
    }
  });

  // Subscription endpoints
  app.post("/api/subscription", async (req, res) => {
    if (!req.user) {
      console.error("[API Error] Unauthorized subscription attempt");
      return res.status(401).json({
        message: "Please log in to upgrade to Premium",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { paymentMethodId } = req.body;
      if (!paymentMethodId) {
        return res.status(400).json({
          message: "We couldn't process your payment. Please try again.",
          code: "PAYMENT_METHOD_REQUIRED"
        });
      }

      const subscription = await createSubscription(req.user.id, paymentMethodId);
      res.json(subscription);
    } catch (error) {
      console.error("[API Error] Error creating subscription:", error);
      const errorMessage = isProduction
        ? "We couldn't complete your subscription. Please try again or contact support if the issue persists."
        : error instanceof Error ? error.message : "Unexpected error occurred";

      res.status(500).json({
        message: "Subscription Setup Failed",
        details: errorMessage,
        code: "SUBSCRIPTION_FAILED"
      });
    }
  });

  app.post("/api/subscription/create-payment-intent", async (req, res) => {
    if (!req.user) {
      console.error("[API Error] Unauthorized payment intent creation attempt");
      return res.status(401).json({
        message: "Please log in to upgrade to Premium",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({
          message: "We couldn't find your account. Please try logging in again.",
          code: "USER_NOT_FOUND"
        });
      }

      if (!user.email) {
        return res.status(400).json({
          message: "Please add an email to your profile before upgrading to Premium",
          code: "EMAIL_REQUIRED"
        });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: 999, // $9.99 in cents
        currency: 'usd',
        payment_method_types: ['card'],
        metadata: {
          userId: user.id.toString(),
          environment: process.env.NODE_ENV || 'development'
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("[API Error] Error creating payment intent:", error);
      const errorMessage = isProduction
        ? "We couldn't set up the payment process. Please try again or contact support if the issue persists."
        : error instanceof Error ? error.message : "Unexpected error occurred";

      res.status(500).json({
        message: "Payment Setup Failed",
        details: errorMessage,
        code: "PAYMENT_INTENT_FAILED"
      });
    }
  });

  // Stripe webhook endpoint for subscription events
  app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
    const sig = req.headers["stripe-signature"];
    if (!sig) {
      console.error("[Webhook Error] No Stripe signature found");
      return res.sendStatus(400);
    }

    try {
      if (!process.env.STRIPE_WEBHOOK_SECRET) {
        throw new Error("STRIPE_WEBHOOK_SECRET is not configured");
      }

      const event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      await handleSubscriptionWebhook(event);
      res.json({ received: true });
    } catch (error) {
      console.error("[Webhook Error] Error processing webhook:", error);
      const errorMessage = isProduction
        ? "Invalid webhook signature"
        : error instanceof Error ? error.message : "Unknown error";

      res.status(400).json({
        message: "Webhook error",
        details: errorMessage,
      });
    }
  });

  app.get('/api/compatibility/:userId', async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const targetUserId = parseInt(req.params.userId);
      const compatibility = await storage.calculateCompatibilityScore(req.user.id, targetUserId);
      res.json(compatibility);
    } catch (error) {
      console.error('Error calculating compatibility:', error);
      res.status(500).json({ message: "Failed to calculate compatibility" });
    }
  });

  // Add date nights endpoints
  app.post("/api/date-nights", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to create a date night",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const { guestId, scheduledFor } = req.body;

      // Create the date night
      const dateNight = await storage.createDateNight({
        hostId: req.user.id,
        guestId,
        scheduledFor: new Date(scheduledFor),
      });

      // Get host information for the message
      const host = await storage.getUser(req.user.id);
      if (!host) {
        throw new Error("Host not found");
      }

      // Create an exciting invitation message
      const date = new Date(scheduledFor);
      const formattedDate = date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      const invitationMessage = {
        type: 'date_invitation',
        senderId: req.user.id,
        receiverId: guestId,
        dateNightId: dateNight.id,
        content: `✨ Special Invitation ✨\n\n${host.name} would love to go on a date with you on ${formattedDate}! 🌟\n\nReady to create some magic together? Accept this invitation to start your journey! 💫`,
        scheduledFor: scheduledFor
      };

      // Send WebSocket notification to the guest if they're online
      const guestWs = connectedClients.get(guestId);
      if (guestWs?.readyState === WebSocket.OPEN) {
        guestWs.send(JSON.stringify(invitationMessage));
      }

      // Also save this as a chat message
      await storage.createMessage({
        senderId: req.user.id,
        receiverId: guestId,
        content: invitationMessage.content
      });

      res.json(dateNight);
    } catch (error) {
      console.error('Error creating date night:', error);
      res.status(500).json({
        message: "Failed to create date night",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "DATE_NIGHT_CREATION_FAILED"
      });
    }
  });

  app.patch("/api/date-nights/:id", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to update date night status",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const dateNightId = parseInt(req.params.id);
      const { status } = req.body;

      if (!['accepted', 'declined'].includes(status)) {
        return res.status(400).json({
          message: "Invalid status. Must be 'accepted' or 'declined'",
          code: "INVALID_STATUS"
        });
      }

      const updatedDateNight = await storage.updateDateNightStatus(dateNightId, status);
      res.json(updatedDateNight);
    } catch (error) {
      console.error('Error updating date night status:', error);
      res.status(500).json({
        message: "Failed to update date night status",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "STATUS_UPDATE_FAILED"
      });
    }
  });

  app.get("/api/date-nights", async (req, res) => {
    if (!req.user) {
      return res.status(401).json({
        message: "Please log in to view date nights",
        code: "AUTH_REQUIRED"
      });
    }

    try {
      const dateNights = await storage.getDateNights(req.user.id);
      res.json(dateNights);
    } catch (error) {
      console.error('Error fetching date nights:', error);
      res.status(500).json({
        message: "Failed to fetch date nights",
        details: error instanceof Error ? error.message : "Unknown error",
        code: "FETCH_FAILED"
      });
    }
  });

  wss.on('connection', (ws: WebSocketWithSession, request: IncomingMessage) => {
    console.log('New WebSocket connection established');

    const req = request as unknown as SessionWithPassport;
    const userId = req.session?.passport?.user;

    if (!userId) {
      console.log('No user ID found in session, closing connection');
      ws.close(1008, 'No user ID found');
      return;
    }

    console.log('Successfully authenticated WebSocket connection for user:', userId);
    ws.userId = userId;
    connectedClients.set(userId, ws);

    // Send initial connection success message
    ws.send(JSON.stringify({
      type: 'connection_status',
      status: 'connected',
      userId: userId
    }));

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);

        // Broadcast message to relevant clients
        for (const [clientId, clientWs] of connectedClients.entries()) {
          if (clientWs.readyState === WebSocket.OPEN &&
            clientId !== userId && // Don't send to sender
            (clientId === data.receiverId || clientId === data.senderId)) {
            clientWs.send(JSON.stringify({
              type: 'chat',
              senderId: userId,
              receiverId: data.receiverId,
              message: data
            }));
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message'
        }));
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected:', userId);
      connectedClients.delete(userId);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error for user', userId, ':', error);
      ws.close(1011, 'Internal server error');
    });
  });

  return httpServer;
}